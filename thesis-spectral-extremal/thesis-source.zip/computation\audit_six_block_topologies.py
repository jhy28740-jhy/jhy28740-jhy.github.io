"""Explore all looped six-block graphon topologies up to isomorphism.

There are 156 unlabelled simple graphs on six vertices.  Adding a loop to
each vertex gives every looped 0-1 six-block template with clique diagonal.
For each topology this script numerically optimizes the block weights and
reports the strongest candidates.  It is exploratory evidence only: random
restarts and floating-point optimization are not an exhaustive interval
certificate and do not prove a six-atomic or global graphon bound.
"""

from __future__ import annotations

import argparse
import math

import networkx as nx
import numpy as np


C_STAR = (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0


def six_vertex_graphs() -> list[nx.Graph]:
    """Return the 156 unlabelled simple graphs on exactly six vertices."""

    return [graph for graph in nx.graph_atlas_g() if len(graph) == 6]


def template(graph: nx.Graph) -> np.ndarray:
    adjacency = nx.to_numpy_array(graph, nodelist=range(6), dtype=float)
    return adjacency + np.eye(6)


def value_gradient(
    h: np.ndarray, logits: np.ndarray
) -> tuple[float, np.ndarray, np.ndarray, int]:
    shifted = logits - np.max(logits)
    weights = np.exp(shifted)
    weights /= np.sum(weights)
    root = np.sqrt(weights)
    matrix = (root[:, None] * h) * root[None, :]
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    positive_indices = np.flatnonzero(eigenvalues > 1e-10)
    selected = np.zeros(6, dtype=bool)
    selected[positive_indices[-3:]] = True
    value = float(np.sum(eigenvalues[selected]))
    projector = eigenvectors[:, selected] @ eigenvectors[:, selected].T
    grad_weights = ((h * projector) @ root) / root
    grad_logits = weights * (grad_weights - weights @ grad_weights)
    return value, grad_logits, weights, len(positive_indices)


def optimize(
    h: np.ndarray, logits: np.ndarray, iterations: int
) -> tuple[float, np.ndarray, int]:
    value, gradient, weights, positive_inertia = value_gradient(h, logits)
    step = 0.5
    for _ in range(iterations):
        norm2 = float(gradient @ gradient)
        if norm2 < 1e-20:
            break
        trial_step = step
        for _ in range(24):
            trial_logits = logits + trial_step * gradient
            trial = value_gradient(h, trial_logits)
            trial_value, trial_gradient, trial_weights, trial_inertia = trial
            if trial_value >= value + 1e-4 * trial_step * norm2:
                logits = trial_logits
                value = trial_value
                gradient = trial_gradient
                weights = trial_weights
                positive_inertia = trial_inertia
                step = min(2.0, 1.2 * trial_step)
                break
            trial_step *= 0.5
        else:
            break
    return value, weights, positive_inertia


def graph_code(graph: nx.Graph) -> str:
    edges = sorted((u + 1, v + 1) for u, v in graph.edges())
    return " ".join(f"{u}{v}" for u, v in edges)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--restarts", type=int, default=40)
    parser.add_argument("--iterations", type=int, default=1800)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--show", type=int, default=30)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    records: list[tuple[float, int, nx.Graph, np.ndarray, int]] = []
    for atlas_index, graph in enumerate(six_vertex_graphs()):
        h = template(graph)
        best_value = -np.inf
        best_weights = np.empty(6)
        best_inertia = 0
        initial_points = [np.zeros(6)]
        initial_points.extend(rng.normal(size=6) for _ in range(args.restarts - 1))
        for logits in initial_points:
            value, weights, positive_inertia = optimize(h, logits, args.iterations)
            if value > best_value:
                best_value = value
                best_weights = weights
                best_inertia = positive_inertia
        records.append((best_value, atlas_index, graph, best_weights, best_inertia))

    records.sort(reverse=True, key=lambda item: item[0])
    print("Numerical six-topology audit only; no exhaustive interval proof.")
    print(f"templates={len(records)} c_star={C_STAR:.12f}")
    for value, atlas_index, graph, weights, positive_inertia in records[: args.show]:
        positive_weights = int(np.count_nonzero(weights > 1e-7))
        print(
            f"value={value:.12f} gap={C_STAR-value:+.3e} "
            f"atlas6={atlas_index:03d} edges={graph.number_of_edges():02d} "
            f"inertia+={positive_inertia} support={positive_weights} "
            f"edge_list=[{graph_code(graph)}] "
            f"weights={np.array2string(weights, precision=9, suppress_small=True)}"
        )


if __name__ == "__main__":
    main()
