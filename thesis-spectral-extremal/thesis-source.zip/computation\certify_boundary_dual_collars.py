"""Build exact shifted-dual certificates for 68 six-block coordinate collars.

The floating-point optimization in this file is only a certificate search.
Every published conclusion is checked afterwards with ``Fraction`` arithmetic:
positive definiteness, the exact inverse, nonnegative diagonal shifts, and all
extreme points of the collar ``d_face <= 1/100``.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

from certify_six_block_low_inertia import (
    N,
    edge_list,
    exact_inertia,
    fraction_text,
    inverse_fraction,
    matrix_from_mask,
)
from certify_six_block_shifted_dual import pack, shifted_values, unpack
from explore_boundary_dual_collars import collar_coefficients, smooth_objective


DELTA = Fraction(1, 100)
C_STAR_LOWER = Fraction(5767, 4500)
COEFFICIENT_TARGET = 4 * C_STAR_LOWER - 2
CERTIFIED_FACES = {
    0x03BC: tuple(range(N)),
    0x03BD: tuple(range(N)),
    0x03BE: (0, 1, 2, 4, 5),
    0x06DF: tuple(range(N)),
    0x077C: tuple(range(N)),
    0x077D: tuple(range(N)),
    0x07DE: (0, 1, 3, 4, 5),
    0x07FE: (0, 1, 3, 4, 5),
    0x0FDF: (1, 2, 3, 4, 5),
    0x1BBC: tuple(range(N)),
    0x1BBD: tuple(range(N)),
    0x1BFE: tuple(range(N)),
}
OUTPUT_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_boundary_dual_collar_certificates.json"
)


def numerical_candidate(
    mask: int, face: int, starts: int
) -> tuple[np.ndarray, np.ndarray, float]:
    template = np.asarray(matrix_from_mask(mask, float))
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    initial = [
        (absolute + 0.03 * np.eye(N), np.zeros(N)),
        (absolute + 0.20 * np.eye(N), 0.10 * np.ones(N)),
        (np.eye(N), np.zeros(N)),
    ][:starts]
    extremes = collar_coefficients(face, float(DELTA))
    bounds = []
    for i in range(N):
        for j in range(i + 1):
            bounds.append((-5.0, 5.0) if i == j else (-8.0, 8.0))
    bounds.extend([(0.0, 6.0)] * N)

    best_matrix = np.eye(N)
    best_gamma = np.zeros(N)
    best_value = math.inf
    for matrix, gamma in initial:
        parameters = pack(matrix, gamma)
        for sharpness in (30.0, 150.0, 800.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, extremes, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 1600, "ftol": 1e-13, "gtol": 1e-10},
            )
            parameters = result.x
        matrix, _, gamma = unpack(parameters)
        if np.min(np.linalg.eigvalsh(matrix)) <= 1e-9:
            continue
        values, _ = shifted_values(matrix, gamma, template)
        value = float(np.max(extremes @ values))
        if np.isfinite(value) and value < best_value:
            best_matrix = matrix
            best_gamma = gamma
            best_value = value
    if not np.isfinite(best_value):
        raise RuntimeError(f"no numerical candidate for {mask:04x}, face {face + 1}")
    return best_matrix, best_gamma, best_value


def exact_coefficients(
    matrix: list[list[Fraction]],
    gamma: list[Fraction],
    template: list[list[Fraction]],
) -> list[Fraction]:
    inverse = inverse_fraction(matrix)
    values = []
    for i in range(N):
        column = [
            template[j][i] - (gamma[i] if j == i else 0)
            for j in range(N)
        ]
        quadratic = sum(
            column[j] * inverse[j][k] * column[k]
            for j in range(N)
            for k in range(N)
        )
        values.append(2 * gamma[i] + matrix[i][i] + quadratic)
    return values


def collar_maximum(values: list[Fraction], face: int) -> Fraction:
    candidates = []
    for i in range(N):
        if i == face:
            continue
        candidates.append(values[i])
        candidates.append((1 - DELTA) * values[i] + DELTA * values[face])
    return max(candidates)


def rationalize(
    numerical_matrix: np.ndarray,
    numerical_gamma: np.ndarray,
    template: list[list[Fraction]],
    face: int,
) -> tuple[list[list[Fraction]], list[Fraction], list[Fraction], Fraction]:
    for digits in (5, 6, 7, 8, 9, 10):
        scale = 10**digits
        base_matrix = [
            [
                Fraction(int(round(numerical_matrix[i, j] * scale)), scale)
                for j in range(N)
            ]
            for i in range(N)
        ]
        base_gamma = [
            Fraction(max(0, int(round(value * scale))), scale)
            for value in numerical_gamma
        ]
        for bump_units in (0, 1, 2, 5, 10, 20, 50, 100):
            matrix = [row[:] for row in base_matrix]
            for i in range(N):
                matrix[i][i] += Fraction(bump_units, scale)
            if exact_inertia(matrix) != (N, 0, 0):
                continue
            values = exact_coefficients(matrix, base_gamma, template)
            maximum = collar_maximum(values, face)
            if maximum < COEFFICIENT_TARGET:
                return matrix, base_gamma, values, maximum
    raise RuntimeError(f"failed to rationalize face {face + 1}")


def build_record(task: tuple[int, int, int]) -> dict:
    mask, face, starts = task
    template = matrix_from_mask(mask, Fraction)
    matrix_float, gamma_float, numerical_maximum = numerical_candidate(
        mask, face, starts
    )
    matrix, gamma, values, maximum = rationalize(
        matrix_float, gamma_float, template, face
    )
    return {
        "mask": f"{mask:04x}",
        "edges": edge_list(mask).split(),
        "face": face + 1,
        "matrix": [[fraction_text(value) for value in row] for row in matrix],
        "gamma": [fraction_text(value) for value in gamma],
        "dual_coefficients": [fraction_text(value) for value in values],
        "maximum_collar_coefficient": fraction_text(maximum),
        "certified_bound": fraction_text(Fraction(1, 2) + maximum / 4),
        "numerical_bound": 0.5 + 0.25 * numerical_maximum,
    }


def write_certificates(records: list[dict]) -> str:
    payload = {
        "format_version": 1,
        "statement": (
            "For every listed template-face pair and every probability vector "
            "whose listed coordinate is at most 1/100, the first-three "
            "spectral sum is strictly below 5767/4500 < c_star."
        ),
        "dimension": N,
        "delta": fraction_text(DELTA),
        "c_star_strict_lower_bound": fraction_text(C_STAR_LOWER),
        "coefficient_strict_upper_target": fraction_text(COEFFICIENT_TARGET),
        "certified_faces": {
            f"{mask:04x}": [face + 1 for face in faces]
            for mask, faces in CERTIFIED_FACES.items()
        },
        "certificate_count": len(records),
        "records": sorted(records, key=lambda item: (item["mask"], item["face"])),
    }
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("ascii")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_bytes(encoded)
    return hashlib.sha256(encoded).hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--starts", type=int, choices=(1, 2, 3), default=3)
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()

    # Exact radical brackets used to prove 5767/4500 < c_star.
    assert 559**2 < 5 * 250**2
    assert 1479**2 < 35 * 250**2
    assert (
        Fraction(9, 1) + Fraction(559, 250) + 2 * Fraction(1479, 250)
    ) / 18 == C_STAR_LOWER

    tasks = [
        (mask, face, args.starts)
        for mask, faces in CERTIFIED_FACES.items()
        for face in faces
    ]
    if args.workers == 1:
        records = list(map(build_record, tasks))
    else:
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=args.workers
        ) as executor:
            records = list(executor.map(build_record, tasks))

    digest = write_certificates(records)
    print(f"template_count={len(CERTIFIED_FACES)}")
    print(f"certificate_count={len(records)}")
    print(f"delta={fraction_text(DELTA)}")
    print(f"sha256={digest}")
    print(f"certificate_file={OUTPUT_PATH}")


if __name__ == "__main__":
    main()
