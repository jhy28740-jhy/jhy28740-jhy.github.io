"""Generate thesis figures and reproducible numerical evidence."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
FIGURE_DIR = ROOT / "figures"
EVIDENCE_PATH = ROOT / "computation" / "numerical_evidence.txt"

SQRT5 = np.sqrt(5.0)
ALPHA_STAR = (91.0 - 25.0 * np.sqrt(7.0)) / 126.0
C_STAR = (9.0 + SQRT5 + 2.0 * np.sqrt(35.0)) / 18.0


def cycle_objective(alpha: np.ndarray | float, r: int) -> np.ndarray | float:
    """Balanced core-plus-cycle graphon objective for cycle length r."""
    alpha_array = np.asarray(alpha, dtype=float)
    beta = (1.0 - alpha_array) / r
    gamma = 1.0 + 2.0 * np.cos(2.0 * np.pi / r)
    discriminant = (alpha_array - 3.0 * beta) ** 2 + 4.0 * alpha_array * (1.0 - alpha_array)
    value = (alpha_array + 3.0 * beta + np.sqrt(discriminant)) / 2.0
    value += 2.0 * gamma * beta
    return float(value) if np.ndim(value) == 0 else value


def cycle_family_maxima() -> list[tuple[int, float, float]]:
    """Numerically locate the unique balanced optimum for r=4,...,12."""
    grid = np.linspace(0.0, 1.0, 200_001)
    result = []
    for r in range(4, 13):
        values = cycle_objective(grid, r)
        index = int(np.argmax(values))
        result.append((r, float(grid[index]), float(values[index])))
    return result


def save_cycle_family_comparison() -> list[tuple[int, float, float]]:
    rows = cycle_family_maxima()
    cycles = np.array([row[0] for row in rows])
    alphas = np.array([row[1] for row in rows])
    values = np.array([row[2] for row in rows])
    fig, ax = plt.subplots(figsize=(7.2, 4.4), constrained_layout=True)
    ax.plot(cycles, values, marker="o", color="#1d3557", linewidth=2.2)
    ax.axvline(5, color="#e76f51", linestyle="--", linewidth=1.4, label=r"$C_5$")
    ax.scatter([5], [values[1]], s=72, color="#e76f51", zorder=3)
    ax.set_xlabel("cycle length r")
    ax.set_ylabel("maximal normalized spectral sum")
    ax.set_xticks(cycles)
    ax.grid(color="#d7dde2", linewidth=0.7, alpha=0.8)
    ax.legend(frameon=False, loc="upper right")
    fig.savefig(FIGURE_DIR / "cycle_family_comparison.pdf", bbox_inches="tight")
    plt.close(fig)
    return rows


def objective(alpha: np.ndarray | float) -> np.ndarray | float:
    discriminant = -36.0 * np.asarray(alpha) ** 2 + 52.0 * np.asarray(alpha) + 9.0
    value = (
        (2.0 * np.asarray(alpha) + 3.0 + np.sqrt(discriminant)) / 10.0
        + (1.0 + SQRT5) * (1.0 - np.asarray(alpha)) / 5.0
    )
    return float(value) if np.ndim(value) == 0 else value


def block_template() -> np.ndarray:
    template = np.eye(6)
    template[0, 1:] = 1.0
    template[1:, 0] = 1.0
    for i in range(5):
        u = i + 1
        v = (i + 1) % 5 + 1
        template[u, v] = template[v, u] = 1.0
    return template


TEMPLATE = block_template()


def spectral_sum(measures: np.ndarray) -> float:
    matrix = np.sqrt(np.outer(measures, measures)) * TEMPLATE
    return float(np.linalg.eigvalsh(matrix)[-3:].sum())


def best_finite_order_value(n: int) -> tuple[int, float]:
    feasible = np.arange(n % 5, n - 4, 5, dtype=int)
    feasible = feasible[feasible >= 1]
    values = n * objective(feasible / n) - 3.0
    index = int(np.argmax(values))
    return int(feasible[index]), float(values[index])


def save_six_block_diagram() -> None:
    fig, ax = plt.subplots(figsize=(6.8, 5.4), constrained_layout=True)
    angles = np.pi / 2.0 + 2.0 * np.pi * np.arange(5) / 5.0
    outer = np.column_stack((np.cos(angles), np.sin(angles)))
    center = np.array([0.0, 0.0])

    for i in range(5):
        j = (i + 1) % 5
        ax.plot(
            [outer[i, 0], outer[j, 0]],
            [outer[i, 1], outer[j, 1]],
            color="#3f4a54",
            linewidth=2.2,
            zorder=1,
        )
        ax.plot(
            [center[0], outer[i, 0]],
            [center[1], outer[i, 1]],
            color="#7a858f",
            linewidth=1.7,
            zorder=1,
        )

    ax.scatter(
        outer[:, 0],
        outer[:, 1],
        s=1850,
        color="#2a9d8f",
        edgecolor="#173f3a",
        linewidth=1.8,
        zorder=2,
    )
    ax.scatter(
        [0.0],
        [0.0],
        s=2300,
        color="#e76f51",
        edgecolor="#6b2f24",
        linewidth=1.8,
        zorder=3,
    )

    for i, (x, y) in enumerate(outer, start=1):
        ax.text(x, y, rf"$B_{i}$", ha="center", va="center", fontsize=13, color="white")
    ax.text(0.0, 0.0, r"$C$", ha="center", va="center", fontsize=15, color="white")

    ax.set_xlim(-1.32, 1.32)
    ax.set_ylim(-1.22, 1.25)
    ax.set_aspect("equal")
    ax.axis("off")
    fig.savefig(FIGURE_DIR / "six_block_structure.pdf", bbox_inches="tight")
    plt.close(fig)


def save_objective_curve() -> None:
    alpha = np.linspace(0.0, 1.0, 1001)
    values = objective(alpha)
    delta = alpha - ALPHA_STAR
    lower_coefficient = 27.0 / (25.0 * np.sqrt(10.0))
    upper_coefficient = 50.0 / 27.0
    lower_envelope = C_STAR - upper_coefficient * delta**2
    upper_envelope = C_STAR - lower_coefficient * delta**2

    fig, ax = plt.subplots(figsize=(7.2, 4.6), constrained_layout=True)
    ax.fill_between(
        alpha,
        lower_envelope,
        upper_envelope,
        color="#8ecae6",
        alpha=0.28,
        label="quadratic stability band",
    )
    ax.plot(alpha, values, color="#1d3557", linewidth=2.4, label=r"$F(\alpha)$")
    ax.axvline(ALPHA_STAR, color="#e76f51", linestyle="--", linewidth=1.6)
    ax.scatter([ALPHA_STAR], [C_STAR], s=58, color="#e76f51", edgecolor="white", zorder=4)
    ax.annotate(
        rf"$\alpha_*={ALPHA_STAR:.4f}$" + "\n" + rf"$F(\alpha_*)={C_STAR:.4f}$",
        xy=(ALPHA_STAR, C_STAR),
        xytext=(0.39, 1.18),
        arrowprops={"arrowstyle": "->", "color": "#6b2f24"},
        fontsize=10,
    )
    ax.set_xlabel(r"core proportion $\alpha$")
    ax.set_ylabel(r"spectral sum $F(\alpha)$")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.98, 1.31)
    ax.grid(color="#d7dde2", linewidth=0.7, alpha=0.8)
    ax.legend(frameon=False, loc="lower left")
    fig.savefig(FIGURE_DIR / "objective_curve.pdf", bbox_inches="tight")
    plt.close(fig)


def save_finite_order_convergence() -> None:
    orders = np.arange(18, 301)
    choices = np.array([best_finite_order_value(int(n)) for n in orders])
    core_sizes = choices[:, 0]
    s3_values = choices[:, 1]
    ratios = s3_values / orders
    scaled_gap = orders * (C_STAR - ratios)

    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0), constrained_layout=True)
    left, right = axes
    left.scatter(orders, ratios, s=12, color="#2a9d8f", alpha=0.78, edgecolors="none")
    left.axhline(C_STAR, color="#e76f51", linewidth=1.7, label=r"$c_*$")
    left.set_xlabel(r"order $n$")
    left.set_ylabel(r"best balanced-family ratio $S_3/n$")
    left.grid(color="#d7dde2", linewidth=0.7, alpha=0.8)
    left.legend(frameon=False, loc="lower right")

    right.scatter(orders, scaled_gap, s=12, color="#1d3557", alpha=0.78, edgecolors="none")
    right.axhline(3.0, color="#e76f51", linewidth=1.7, label="limit 3")
    right.plot(
        orders,
        3.0 + 625.0 / (54.0 * orders),
        color="#f4a261",
        linestyle="--",
        linewidth=1.5,
        label="proved upper envelope",
    )
    right.set_xlabel(r"order $n$")
    right.set_ylabel(r"scaled gap $n(c_*-S_3/n)$")
    right.grid(color="#d7dde2", linewidth=0.7, alpha=0.8)
    right.legend(frameon=False, loc="upper right")
    fig.savefig(FIGURE_DIR / "finite_order_convergence.pdf", bbox_inches="tight")
    plt.close(fig)

    return orders, core_sizes, ratios, scaled_gap


def numerical_hessian(step: float = 1.0e-4) -> np.ndarray:
    base = np.array([ALPHA_STAR] + [(1.0 - ALPHA_STAR) / 5.0] * 5)
    spanning = np.column_stack([np.eye(6)[:, i] - np.eye(6)[:, 5] for i in range(5)])
    basis, _ = np.linalg.qr(spanning)
    hessian = np.zeros((5, 5))
    f0 = spectral_sum(base)

    for i in range(5):
        direction = basis[:, i]
        hessian[i, i] = (
            spectral_sum(base + step * direction)
            - 2.0 * f0
            + spectral_sum(base - step * direction)
        ) / step**2
        for j in range(i + 1, 5):
            other = basis[:, j]
            mixed = (
                spectral_sum(base + step * direction + step * other)
                - spectral_sum(base + step * direction - step * other)
                - spectral_sum(base - step * direction + step * other)
                + spectral_sum(base - step * direction - step * other)
            ) / (4.0 * step**2)
            hessian[i, j] = hessian[j, i] = mixed
    return hessian


def random_dirichlet_search(samples: int = 600_000, seed: int = 20260831) -> tuple[float, np.ndarray]:
    rng = np.random.default_rng(seed)
    best_value = -np.inf
    best_measures = np.zeros(6)
    batch_size = 20_000
    remaining = samples

    while remaining:
        size = min(batch_size, remaining)
        measures = rng.dirichlet(np.ones(6), size=size)
        roots = np.sqrt(measures)
        matrices = roots[:, :, None] * roots[:, None, :] * TEMPLATE[None, :, :]
        values = np.linalg.eigvalsh(matrices)[:, -3:].sum(axis=1)
        index = int(np.argmax(values))
        if values[index] > best_value:
            best_value = float(values[index])
            best_measures = measures[index].copy()
        remaining -= size
    return best_value, best_measures


def write_evidence(orders: np.ndarray, core_sizes: np.ndarray, ratios: np.ndarray) -> None:
    hessian_steps = (1.0e-3, 1.0e-4, 1.0e-5)
    hessian_results = {
        step: np.linalg.eigvalsh(numerical_hessian(step)) for step in hessian_steps
    }
    random_best, random_measures = random_dirichlet_search()
    cycle_rows = cycle_family_maxima()
    finite_bound_residual = ratios - (
        C_STAR - 3.0 / orders - 625.0 / (54.0 * orders**2)
    )

    lines = [
        "Reproducible numerical evidence for the spectral-extremal thesis",
        "=================================================================",
        "",
        f"alpha_star = {ALPHA_STAR:.15f}",
        f"c_star = {C_STAR:.15f}",
        "",
        "Finite-order check, n = 18,...,300:",
        f"  minimum lower-bound residual = {finite_bound_residual.min():.12e}",
        f"  closest core ratio error = {np.min(np.abs(core_sizes / orders - ALPHA_STAR)):.12e}",
        "",
        "Central-difference Hessian on the five-dimensional measure simplex:",
    ]
    for step, eigenvalues in hessian_results.items():
        lines.extend(
            [
                f"  step = {step:.0e}",
                "    eigenvalues = " + ", ".join(f"{value:.10f}" for value in eigenvalues),
                "    all negative = " + str(bool(np.all(eigenvalues < 0.0))),
            ]
        )
    lines.extend(
        [
            "",
            "The 1e-5 calculation begins to show double-precision roundoff;",
            "all three step sizes preserve the negative Hessian signature.",
            "",
            "Seeded Dirichlet(1,...,1) search over 600000 measure vectors:",
            f"  best spectral sum = {random_best:.15f}",
            f"  gap to c_star = {C_STAR - random_best:.12e}",
            "  best measures = " + ", ".join(f"{value:.10f}" for value in random_measures),
            "",
            "These checks are computational evidence only; they do not prove global",
            "optimality over all measure vectors or over all graphons.",
            "",
            "Balanced core-plus-cycle comparison (grid step 5e-6):",
            "  r   alpha_r        c_r",
        ]
    )
    lines.extend(f"  {r:2d}  {alpha:.10f}  {value:.12f}" for r, alpha, value in cycle_rows)
    lines.extend(
        [
            "  The comparison supports the exact cycle-length theorem; the theorem",
            "  itself uses the analytic pointwise comparison in Chapter 5.",
        ]
    )
    EVIDENCE_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
        }
    )
    save_six_block_diagram()
    save_objective_curve()
    save_cycle_family_comparison()
    orders, core_sizes, ratios, _ = save_finite_order_convergence()
    write_evidence(orders, core_sizes, ratios)
    print(f"wrote figures to {FIGURE_DIR}")
    print(f"wrote evidence to {EVIDENCE_PATH}")


if __name__ == "__main__":
    main()
