"""Exact arithmetic checks for the unresolved-template boundary collar.

The proof in Chapter 5 uses only the inequalities

    sqrt(5) > 559/250,  sqrt(35) > 2958/500,  sqrt(6) < 49/20,
    c_star - c_4 > 127/4500 > 1/36,  sqrt(1/1300) < 1/36.

This script checks those radical comparisons with integers.  It does not
enumerate templates and it does not certify any interior point.
"""

from __future__ import annotations

from fractions import Fraction


def main() -> None:
    # Strict rational brackets for the radicals used in the collar proof.
    assert 559**2 < 5 * 250**2
    assert 2958**2 < 35 * 500**2
    assert 49**2 > 6 * 20**2

    # A lower bound for c_star - c_4 after putting both constants over 90.
    numerator_lower = (
        5 * Fraction(559, 250)
        + 10 * Fraction(2958, 500)
        - 24 * Fraction(49, 20)
        - 9
    )
    # The strict radical brackets make the corresponding analytic inequality
    # strict; the rational lower expression itself is exactly 127/4500.
    assert numerator_lower / 90 >= Fraction(127, 4500)
    assert Fraction(127, 4500) > Fraction(1, 36)

    # For delta <= 1/1300, sqrt(delta) < 1/36.
    assert 36**2 < 1300
    print("exact radical comparisons for the boundary collar passed")


if __name__ == "__main__":
    main()
