"""Exact arithmetic checks for the unresolved-template boundary collar.

The proof in Chapter 5 uses only the inequalities

    sqrt(5) > 2.236,  sqrt(35) > 5.916,  sqrt(6) < 2.45,
    c_star - c_4 > 1/40,  sqrt(6)/100 < 1/40.

This script checks those radical comparisons with integers.  It does not
enumerate templates and it does not certify any interior point.
"""

from __future__ import annotations

from fractions import Fraction


def main() -> None:
    # Strict rational brackets for the radicals used in the collar proof.
    assert 2236**2 < 5 * 1000**2
    assert 5916**2 < 35 * 1000**2
    assert 245**2 > 6 * 100**2

    # A lower bound for c_star - c_4 after putting both constants over 90.
    numerator_lower = (
        5 * Fraction(2236, 1000)
        + 10 * Fraction(5916, 1000)
        - 24 * Fraction(245, 100)
        - 9
    )
    assert numerator_lower / 90 > Fraction(1, 40)

    # For delta <= 10^{-4}, sqrt(6 delta) <= sqrt(6)/100.
    assert Fraction(245, 100) / 100 < Fraction(1, 40)
    print("exact radical comparisons for the boundary collar passed")


if __name__ == "__main__":
    main()
