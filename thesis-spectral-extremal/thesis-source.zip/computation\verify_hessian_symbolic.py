"""Exact symbolic certificate for the Chapter 5 KKT point and Hessian.

All calculations take place in Q(sqrt(5), sqrt(7))[q]/(q^2-alpha*beta),
where q=sqrt(alpha*beta).  No floating-point evaluation is used.
"""

from __future__ import annotations

import sympy as sp


SQRT5 = sp.sqrt(5)
SQRT7 = sp.sqrt(7)
SQRT35 = SQRT5 * SQRT7
QROOT = sp.symbols("q")

ALPHA = (91 - 25 * SQRT7) / 126
BETA = (1 - ALPHA) / 5
MEASURES = [ALPHA] + [BETA] * 5


def trace(matrix: sp.Matrix) -> sp.Expr:
    return sum(matrix[i, i] for i in range(matrix.rows))


def reduce_q(expression: sp.Expr) -> sp.Expr:
    """Reduce exactly modulo q^2-alpha*beta."""
    numerator, denominator = sp.fraction(sp.cancel(expression))
    if denominator.has(QROOT):
        raise AssertionError("unexpected q in a denominator")
    modulus = sp.Poly(QROOT**2 - ALPHA * BETA, QROOT)
    remainder = sp.rem(sp.Poly(sp.expand(numerator), QROOT), modulus).as_expr()
    return sp.collect(sp.cancel(remainder / denominator), QROOT)


def assert_zero(expression: sp.Expr) -> None:
    reduced = reduce_q(expression)
    coefficients = sp.Poly(reduced, QROOT).all_coeffs()
    if any(sp.radsimp(sp.simplify(value)) != 0 for value in coefficients):
        raise AssertionError(f"nonzero exact residual: {reduced}")


def build_template_matrix() -> sp.Matrix:
    template = sp.zeros(6)
    for i in range(6):
        template[i, i] = 1
    for i in range(1, 6):
        template[0, i] = template[i, 0] = 1
    for i in range(5):
        j = i + 1
        k = 1 + (i + 1) % 5
        template[j, k] = template[k, j] = 1
    return template


def build_balanced_quotient(template: sp.Matrix) -> sp.Matrix:
    quotient = sp.zeros(6)
    for i in range(6):
        for j in range(6):
            if template[i, j] == 0:
                continue
            if i == j == 0:
                quotient[i, j] = ALPHA
            elif i > 0 and j > 0:
                quotient[i, j] = BETA
            else:
                quotient[i, j] = QROOT
    return quotient


def build_projectors(quotient: sp.Matrix) -> tuple[
    tuple[sp.Expr, sp.Matrix],
    tuple[sp.Expr, sp.Matrix],
    tuple[sp.Expr, sp.Matrix],
    tuple[sp.Expr, sp.Matrix],
]:
    constant_projector = sp.zeros(6)
    constant_projector[0, 0] = 1
    for i in range(1, 6):
        for j in range(1, 6):
            constant_projector[i, j] = sp.Rational(1, 5)

    delta = SQRT35 / 7
    lambda_plus = (ALPHA + 3 * BETA + delta) / 2
    lambda_minus = (ALPHA + 3 * BETA - delta) / 2
    block = constant_projector * quotient * constant_projector
    projector_plus = (block - lambda_minus * constant_projector) / delta
    projector_minus = (lambda_plus * constant_projector - block) / delta

    eta = (1 + SQRT5) * BETA / 2
    nu = (1 - SQRT5) * BETA / 2
    projector_eta = sp.zeros(6)
    projector_nu = sp.zeros(6)
    for i in range(5):
        for j in range(5):
            difference = (i - j) % 5
            if difference == 0:
                eta_entry = nu_entry = sp.Rational(2, 5)
            elif difference in (1, 4):
                eta_entry = (SQRT5 - 1) / 10
                nu_entry = -(SQRT5 + 1) / 10
            else:
                eta_entry = -(SQRT5 + 1) / 10
                nu_entry = (SQRT5 - 1) / 10
            projector_eta[i + 1, j + 1] = eta_entry
            projector_nu[i + 1, j + 1] = nu_entry

    return (
        (lambda_plus, projector_plus),
        (eta, projector_eta),
        (lambda_minus, projector_minus),
        (nu, projector_nu),
    )


def second_variation(
    direction: list[sp.Expr | int],
    quotient: sp.Matrix,
    projectors: tuple[
        tuple[sp.Expr, sp.Matrix],
        tuple[sp.Expr, sp.Matrix],
        tuple[sp.Expr, sp.Matrix],
        tuple[sp.Expr, sp.Matrix],
    ],
) -> sp.Expr:
    first = sp.zeros(6)
    second = sp.zeros(6)
    for i in range(6):
        for j in range(6):
            first[i, j] = quotient[i, j] * (
                direction[i] / MEASURES[i] + direction[j] / MEASURES[j]
            ) / 2
            second[i, j] = -quotient[i, j] * (
                direction[i] / MEASURES[i] - direction[j] / MEASURES[j]
            ) ** 2 / 4

    positive = projectors[:2]
    negative = projectors[2:]
    value = trace((positive[0][1] + positive[1][1]) * second)
    for lambda_value, projector_lambda in positive:
        for mu_value, projector_mu in negative:
            value += 2 * trace(
                projector_mu * first * projector_lambda * first
            ) / (lambda_value - mu_value)
    return reduce_q(value)


def main() -> None:
    template = build_template_matrix()
    quotient = build_balanced_quotient(template)
    projectors = build_projectors(quotient)

    positive_part = (
        projectors[0][0] * projectors[0][1]
        + projectors[1][0] * projectors[1][1]
    )
    c_star = (9 + SQRT5 + 2 * SQRT35) / 18
    gradients = [
        reduce_q(positive_part[i, i] / MEASURES[i]) for i in range(6)
    ]
    for value in gradients:
        assert_zero(value - c_star)
    print("balanced KKT gradient: six exact residuals = 0")

    cosine_1 = [
        1,
        (SQRT5 - 1) / 4,
        -(SQRT5 + 1) / 4,
        -(SQRT5 + 1) / 4,
        (SQRT5 - 1) / 4,
    ]
    cosine_2 = [
        1,
        -(SQRT5 + 1) / 4,
        (SQRT5 - 1) / 4,
        (SQRT5 - 1) / 4,
        -(SQRT5 + 1) / 4,
    ]
    directions = (
        [5, -1, -1, -1, -1, -1],
        [0] + cosine_1,
        [0] + cosine_2,
    )
    squared_norms = (30, sp.Rational(5, 2), sp.Rational(5, 2))
    claimed = (
        -14 * SQRT35 / 75,
        -sp.Rational(287, 95)
        + (-311 * SQRT35 + 455 * SQRT5 + 595 * SQRT7) / 475,
        sp.Rational(287, 95)
        + (-311 * SQRT35 - 595 * SQRT7 + 455 * SQRT5) / 475,
    )

    for index, (direction, norm_squared, expected) in enumerate(
        zip(directions, squared_norms, claimed)
    ):
        computed = reduce_q(
            second_variation(direction, quotient, projectors) / norm_squared
        )
        assert_zero(computed - expected)
        print(f"theta_{index}: exact residual = 0")

    print(
        f"sympy={sp.__version__}; Chapter 5 KKT and Hessian identities verified"
    )


if __name__ == "__main__":
    main()
