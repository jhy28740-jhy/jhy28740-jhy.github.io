"""High-precision diagnostic for the six-atom Grassmann Hessian.

The calculation uses the exact Fourier chart but evaluates it with mpmath.
It is numerical evidence, not the strict interval certificate needed for a
theorem.
"""

from __future__ import annotations

import mpmath as mp


def hadamard(left: mp.matrix, right: mp.matrix) -> mp.matrix:
    result = mp.zeros(left.rows, left.cols)
    for row in range(left.rows):
        for column in range(left.cols):
            result[row, column] = left[row, column] * right[row, column]
    return result


def main() -> None:
    mp.mp.dps = 100
    sqrt = mp.sqrt
    alpha = (91 - 25 * sqrt(7)) / 126
    beta = (1 - alpha) / 5
    off = sqrt(5 * alpha * beta)
    lower = 3 * beta
    discriminant = sqrt((alpha - lower) ** 2 + 4 * off**2)
    u_squared = (1 + (alpha - lower) / discriminant) / 2
    u, v = sqrt(u_squared), sqrt(1 - u_squared)

    q = mp.zeros(6, 3)
    q_perp = mp.zeros(6, 3)
    q[0, 0], q_perp[0, 0] = u, -v
    for index in range(5):
        angle = 2 * mp.pi * index / 5
        q[index + 1, 0] = v / sqrt(5)
        q[index + 1, 1] = sqrt(mp.mpf(2) / 5) * mp.cos(angle)
        q[index + 1, 2] = sqrt(mp.mpf(2) / 5) * mp.sin(angle)
        q_perp[index + 1, 0] = u / sqrt(5)
        q_perp[index + 1, 1] = (
            sqrt(mp.mpf(2) / 5) * mp.cos(2 * angle)
        )
        q_perp[index + 1, 2] = (
            sqrt(mp.mpf(2) / 5) * mp.sin(2 * angle)
        )

    sign_mask = mp.zeros(6)
    for index in range(6):
        sign_mask[index, index] = 1
    for index in range(1, 6):
        sign_mask[0, index] = sign_mask[index, 0] = 1
    for index in range(5):
        sign_mask[index + 1, (index - 1) % 5 + 1] = 1
        sign_mask[index + 1, (index + 1) % 5 + 1] = 1

    active_matrix = hadamard(sign_mask, q * q.T)
    c_star = (9 + sqrt(5) + 2 * sqrt(35)) / 18
    perron = mp.matrix([sqrt(alpha)] + [sqrt(beta)] * 5)
    reduced_resolvent = (
        (c_star * mp.eye(6) - active_matrix + perron * perron.T) ** -1
        - perron * perron.T
    )

    basis = []
    for row in range(3):
        for column in range(3):
            element = mp.zeros(3)
            element[row, column] = 1
            basis.append(element)

    first_derivatives = []
    for element in basis:
        first_projection = (
            q_perp * element * q.T + q * element.T * q_perp.T
        )
        first_derivatives.append(hadamard(sign_mask, first_projection))

    hessian = mp.zeros(9)
    for row, left in enumerate(basis):
        for column, right in enumerate(basis[: row + 1]):
            mixed_projection = (
                q_perp * (left * right.T + right * left.T) * q_perp.T
                - q * (left.T * right + right.T * left) * q.T
            )
            mixed_active = hadamard(sign_mask, mixed_projection)
            value = (
                (perron.T * mixed_active * perron)[0]
                + 2
                * (
                    perron.T
                    * first_derivatives[row]
                    * reduced_resolvent
                    * first_derivatives[column]
                    * perron
                )[0]
            )
            hessian[row, column] = hessian[column, row] = value

    eigenvalues, _ = mp.eigsy(hessian)
    print("eigenvalues")
    for value in eigenvalues:
        print(mp.nstr(value, 50))

    print("nonzero lower-triangular entries")
    for row in range(9):
        for column in range(row + 1):
            if abs(hessian[row, column]) > mp.mpf("1e-80"):
                print(row, column, mp.nstr(hessian[row, column], 80))

    print("negative-Hessian diagonal-dominance margins")
    for row in range(9):
        diagonal = -hessian[row, row]
        off_diagonal = sum(
            abs(hessian[row, column])
            for column in range(9)
            if column != row
        )
        print(row, mp.nstr(diagonal - off_diagonal, 50))


if __name__ == "__main__":
    main()
