"""Explore all looped five-block graphon topologies.

The 10 off-diagonal entries give 1024 labelled topologies.  For each topology
we optimize the block weights numerically.  This is a finite exploratory audit,
not a rigorous interval certificate and not a proof of the five-atom bound.
"""

from __future__ import annotations

import argparse
import itertools

import numpy as np


EDGES = list(itertools.combinations(range(5), 2))


def topology(mask: int) -> np.ndarray:
    h = np.eye(5)
    for bit, (i, j) in enumerate(EDGES):
        if mask & (1 << bit):
            h[i, j] = h[j, i] = 1.0
    return h


def value_gradient(h: np.ndarray, logits: np.ndarray) -> tuple[float, np.ndarray, np.ndarray]:
    shifted = logits - np.max(logits)
    weights = np.exp(shifted)
    weights /= np.sum(weights)
    root = np.sqrt(weights)
    matrix = (root[:, None] * h) * root[None, :]
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    positive_indices = np.flatnonzero(eigenvalues > 1e-10)
    selected = np.zeros(5, dtype=bool)
    selected[positive_indices[-3:]] = True
    value = float(np.sum(eigenvalues[selected]))
    projector = eigenvectors[:, selected] @ eigenvectors[:, selected].T
    grad_weights = ((h * projector) @ root) / root
    grad_logits = weights * (grad_weights - weights @ grad_weights)
    return value, grad_logits, weights


def optimize(h: np.ndarray, logits: np.ndarray, iterations: int) -> tuple[float, np.ndarray]:
    value, gradient, weights = value_gradient(h, logits)
    step = 0.5
    for _ in range(iterations):
        norm2 = float(gradient @ gradient)
        if norm2 < 1e-20:
            break
        trial_step = step
        for _ in range(24):
            trial_logits = logits + trial_step * gradient
            trial_value, trial_gradient, trial_weights = value_gradient(h, trial_logits)
            if trial_value >= value + 1e-4 * trial_step * norm2:
                logits = trial_logits
                value, gradient, weights = trial_value, trial_gradient, trial_weights
                step = min(2.0, 1.2 * trial_step)
                break
            trial_step *= 0.5
        else:
            break
    return value, weights


def edge_list(mask: int) -> str:
    return " ".join(f"{i + 1}{j + 1}" for bit, (i, j) in enumerate(EDGES) if mask & (1 << bit))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--restarts", type=int, default=6)
    parser.add_argument("--iterations", type=int, default=800)
    parser.add_argument("--seed", type=int, default=20260908)
    parser.add_argument("--show", type=int, default=20)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    records: list[tuple[float, int, np.ndarray]] = []
    template_bounds: list[tuple[float, int]] = []
    for mask in range(1 << len(EDGES)):
        h = topology(mask)
        eigenvalues, eigenvectors = np.linalg.eigh(h)
        positive = eigenvectors[:, eigenvalues > 1e-10]
        h_positive = (positive * eigenvalues[eigenvalues > 1e-10]) @ positive.T
        template_bounds.append((float(np.max(np.diag(h_positive))), mask))
        best_value = -np.inf
        best_weights = np.empty(5)
        initial_points = [np.zeros(5)]
        initial_points.extend(rng.normal(size=5) for _ in range(args.restarts - 1))
        for logits in initial_points:
            value, weights = optimize(h, logits, args.iterations)
            if value > best_value:
                best_value, best_weights = value, weights
        records.append((best_value, mask, best_weights))

    records.sort(reverse=True, key=lambda item: item[0])
    print("Numerical topology audit only; no exhaustive interval proof.")
    for value, mask, weights in records[: args.show]:
        print(
            f"value={value:.12f} mask={mask:04x} edges=[{edge_list(mask)}] "
            f"weights={np.array2string(weights, precision=8, suppress_small=True)}"
        )

    template_bounds.sort(reverse=True)
    print("Largest spectral-positive-part diagonal bounds:")
    for bound, mask in template_bounds[: args.show]:
        print(f"bound={bound:.12f} mask={mask:04x} edges=[{edge_list(mask)}]")


if __name__ == "__main__":
    main()
