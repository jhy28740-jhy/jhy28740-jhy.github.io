"""Outward-rounded interval certificate for the Grassmann Hessian.

The script verifies the candidate sign cell, encloses the reduced resolvent,
and certifies strict diagonal dominance of the negative nine-dimensional
Hessian. Every assertion is made against an interval endpoint; midpoint
values are used only for compact human-readable output.
"""

from __future__ import annotations

from math import floor

import mpmath as mp


iv = mp.iv


def hadamard(mask: list[list[int]], matrix: iv.matrix) -> iv.matrix:
    result = iv.matrix(matrix.rows, matrix.cols)
    for row in range(matrix.rows):
        for column in range(matrix.cols):
            result[row, column] = mask[row][column] * matrix[row, column]
    return result


def certified_decimal_lower(value: iv.mpf, places: int = 12) -> str:
    """Return a decimal that is asserted to lie below the interval."""
    scale = 10**places
    numerator = floor(float(value.a) * scale) - 1
    candidate = f"{numerator / scale:.{places}f}"
    assert value.a > iv.mpf(candidate)
    return candidate


def main() -> None:
    iv.dps = 80
    sqrt = iv.sqrt
    one = iv.mpf(1)
    two = iv.mpf(2)

    sqrt5 = sqrt(5)
    sqrt7 = sqrt(7)
    sqrt35 = sqrt(35)
    alpha = (91 - 25 * sqrt7) / 126
    beta = (one - alpha) / 5
    off = sqrt(5 * alpha * beta)
    lower = 3 * beta
    discriminant = sqrt((alpha - lower) ** 2 + 4 * off**2)
    u_squared = (one + (alpha - lower) / discriminant) / 2
    u, v = sqrt(u_squared), sqrt(one - u_squared)
    c_star = (9 + sqrt5 + 2 * sqrt35) / 18

    cos72 = (sqrt5 - one) / 4
    cos144 = -(sqrt5 + one) / 4
    sin72 = sqrt(10 + 2 * sqrt5) / 4
    sin144 = sqrt(10 - 2 * sqrt5) / 4
    cosines = [one, cos72, cos144, cos144, cos72]
    sines = [iv.mpf(0), sin72, sin144, -sin144, -sin72]

    q = iv.matrix(6, 3)
    q_perp = iv.matrix(6, 3)
    q[0, 0], q_perp[0, 0] = u, -v
    radial_scale = sqrt(iv.mpf(2) / 5)
    for index in range(5):
        q[index + 1, 0] = v / sqrt5
        q[index + 1, 1] = radial_scale * cosines[index]
        q[index + 1, 2] = radial_scale * sines[index]
        double_index = (2 * index) % 5
        q_perp[index + 1, 0] = u / sqrt5
        q_perp[index + 1, 1] = radial_scale * cosines[double_index]
        q_perp[index + 1, 2] = radial_scale * sines[double_index]

    sign_mask = [[0 for _ in range(6)] for _ in range(6)]
    for index in range(6):
        sign_mask[index][index] = 1
    for index in range(1, 6):
        sign_mask[0][index] = sign_mask[index][0] = 1
    for index in range(5):
        left, right = index + 1, (index + 1) % 5 + 1
        sign_mask[left][right] = sign_mask[right][left] = 1

    projection = q * q.T
    positive_lowers = []
    negative_magnitude_lowers = []
    for row in range(6):
        for column in range(6):
            entry = projection[row, column]
            if sign_mask[row][column]:
                assert entry.a > 0
                positive_lowers.append(entry)
            else:
                assert entry.b < 0
                negative_magnitude_lowers.append(-entry)

    active_matrix = hadamard(sign_mask, projection)
    perron = iv.matrix([sqrt(alpha)] + [sqrt(beta)] * 5)
    shifted = c_star * iv.eye(6) - active_matrix + perron * perron.T
    reduced_resolvent = shifted**-1 - perron * perron.T

    basis = []
    for row in range(3):
        for column in range(3):
            element = iv.matrix(3, 3)
            element[row, column] = one
            basis.append(element)

    first_derivatives = []
    for element in basis:
        first_projection = (
            q_perp * element * q.T + q * element.T * q_perp.T
        )
        first_derivatives.append(hadamard(sign_mask, first_projection))

    hessian = iv.matrix(9, 9)
    for row, left in enumerate(basis):
        for column, right in enumerate(basis[: row + 1]):
            mixed_projection = (
                q_perp * (left * right.T + right * left.T) * q_perp.T
                - q * (left.T * right + right.T * left) * q.T
            )
            mixed_active = hadamard(sign_mask, mixed_projection)
            value = (
                (perron.T * mixed_active * perron)[0]
                + 2
                * (
                    perron.T
                    * first_derivatives[row]
                    * reduced_resolvent
                    * first_derivatives[column]
                    * perron
                )[0]
            )
            hessian[row, column] = hessian[column, row] = value

    margins = []
    for row in range(9):
        diagonal = -hessian[row, row]
        assert diagonal.a > 0
        off_diagonal = iv.mpf(0)
        for column in range(9):
            if column != row:
                off_diagonal += abs(hessian[row, column])
        margin = diagonal - off_diagonal
        assert margin.a > 0
        margins.append(margin)

    print("candidate sign cell certified")
    print(
        "minimum positive entry lower bound = "
        f"{certified_decimal_lower(min(positive_lowers, key=lambda x: float(x.a)))}"
    )
    print(
        "minimum negative-entry magnitude lower bound = "
        f"{certified_decimal_lower(min(negative_magnitude_lowers, key=lambda x: float(x.a)))}"
    )
    print("negative Hessian is strictly diagonally dominant")
    for index, margin in enumerate(margins):
        print(
            f"row {index}: certified margin > "
            f"{certified_decimal_lower(margin)}"
        )
    minimum_margin = min(margins, key=lambda x: float(x.a))
    print(
        "minimum certified margin > "
        f"{certified_decimal_lower(minimum_margin)}"
    )


if __name__ == "__main__":
    main()
