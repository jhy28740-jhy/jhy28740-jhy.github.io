"""Rational interval certificate for the six-atomic candidate.

The script verifies the four strict vertex orbits in the ellipsoid containment
used by the candidate supporting-certificate lemma.  Interval endpoints are
Fractions and every square root is enclosed by integer square-root bounds, so
the printed inequalities do not rely on floating-point rounding.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from math import isqrt


DIGITS = 30
SCALE = 10**DIGITS


@dataclass(frozen=True)
class Interval:
    lo: Fraction
    hi: Fraction

    @staticmethod
    def point(value: int | Fraction) -> "Interval":
        value = Fraction(value)
        return Interval(value, value)

    def __add__(self, other: "Interval") -> "Interval":
        return Interval(self.lo + other.lo, self.hi + other.hi)

    def __neg__(self) -> "Interval":
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other: "Interval") -> "Interval":
        return self + (-other)

    def __mul__(self, other: "Interval") -> "Interval":
        products = (
            self.lo * other.lo,
            self.lo * other.hi,
            self.hi * other.lo,
            self.hi * other.hi,
        )
        return Interval(min(products), max(products))

    def __truediv__(self, other: "Interval") -> "Interval":
        if other.lo <= 0 <= other.hi:
            raise ZeroDivisionError("interval denominator contains zero")
        reciprocal = Interval(1 / other.hi, 1 / other.lo)
        return self * reciprocal

    def sqrt(self) -> "Interval":
        if self.lo < 0:
            raise ValueError("negative interval")

        def floor_scaled_sqrt(value: Fraction) -> int:
            return isqrt(value.numerator * SCALE * SCALE // value.denominator)

        lower_numerator = floor_scaled_sqrt(self.lo)
        upper_numerator = floor_scaled_sqrt(self.hi) + 1
        lower = Fraction(lower_numerator, SCALE)
        upper = Fraction(upper_numerator, SCALE)
        assert lower * lower <= self.lo
        assert upper * upper >= self.hi
        return Interval(lower, upper)

    def decimal(self) -> tuple[float, float]:
        return float(self.lo), float(self.hi)


ZERO = Interval.point(0)
ONE = Interval.point(1)
TWO = Interval.point(2)
THREE = Interval.point(3)
FIVE = Interval.point(5)


def main() -> None:
    sqrt5 = Interval.point(5).sqrt()
    sqrt7 = Interval.point(7).sqrt()
    sqrt35 = Interval.point(35).sqrt()
    phi = (ONE + sqrt5) / TWO
    alpha = (Interval.point(91) - Interval.point(25) * sqrt7) / Interval.point(126)
    beta = (ONE - alpha) / FIVE
    discriminant = (alpha - THREE * beta) * (alpha - THREE * beta)
    discriminant += Interval.point(20) * alpha * beta
    rho = (alpha + THREE * beta + discriminant.sqrt()) / TWO
    eta = beta * phi
    c_star = (Interval.point(9) + sqrt5 + TWO * sqrt35) / Interval.point(18)

    ratio = (rho - alpha) / (FIVE * alpha * beta).sqrt()
    u = (ONE + ratio * ratio).sqrt()
    u = ONE / u
    v = ratio * u
    core_parallel = alpha.sqrt() * u
    outer_parallel = v * (beta / FIVE).sqrt()

    resultant_sq = {
        0: ZERO,
        1: ONE,
        2: (THREE + sqrt5) / TWO,
        3: (THREE + sqrt5) / TWO,
        4: ONE,
        5: ZERO,
    }

    required_gaps = {
        0: Fraction(1, 1),
        1: Fraction(4, 5),
        2: Fraction(1, 5),
        4: Fraction(1, 10),
    }
    print("Strict vertex orbits (core included):")
    for size in (0, 1, 2, 4):
        parallel = core_parallel + Interval.point(size) * outer_parallel
        value = parallel * parallel / rho
        value += (TWO * beta / FIVE) * resultant_sq[size] / eta
        gap = c_star - value
        assert gap.lo > required_gaps[size]
        print(
            f"k={size}: q in {value.decimal()}, gap in {gap.decimal()}, "
            f"certified gap > {required_gaps[size]}"
        )

    print("The k=3 and k=5 orbits are exact contacts by the eigenvalue equations.")
    print("Orbits without the core are strictly smaller because core_parallel > 0.")


if __name__ == "__main__":
    main()
