"""Enumerate clique-C5 blow-ups through their 6-by-6 symmetric quotient.

This script searches only the family H(a; b1,...,b5).  It is not an
enumeration of all simple graphs.  All five peripheral block sizes are
positive integers, and tuples are identified up to the dihedral symmetries of
C5 when reporting maximizers.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import math
from pathlib import Path

import numpy as np


def compositions(total: int, parts: int = 5):
    """Yield ordered positive compositions of total into ``parts`` parts."""
    for cuts in itertools.combinations(range(1, total), parts - 1):
        points = (0,) + cuts + (total,)
        yield tuple(points[i + 1] - points[i] for i in range(parts))


def dihedral_orbit(blocks: tuple[int, ...]) -> set[tuple[int, ...]]:
    rotations = {
        blocks[shift:] + blocks[:shift] for shift in range(len(blocks))
    }
    reversed_blocks = tuple(reversed(blocks))
    rotations.update(
        reversed_blocks[shift:] + reversed_blocks[:shift]
        for shift in range(len(blocks))
    )
    return rotations


def canonical_blocks(blocks: tuple[int, ...]) -> tuple[int, ...]:
    return min(dihedral_orbit(blocks))


def quotient_matrix(a: int, blocks: tuple[int, ...]) -> np.ndarray:
    """Return the symmetric normalized quotient for clique peripheral blocks."""
    if a < 1 or len(blocks) != 5 or min(blocks) < 1:
        raise ValueError("a and all five block sizes must be positive")

    sizes = (a,) + tuple(blocks)
    quotient = np.zeros((6, 6), dtype=float)
    for i, size in enumerate(sizes):
        quotient[i, i] = size - 1

    for i, block_size in enumerate(blocks, start=1):
        value = math.sqrt(a * block_size)
        quotient[0, i] = quotient[i, 0] = value

    for i in range(5):
        j = (i + 1) % 5
        value = math.sqrt(blocks[i] * blocks[j])
        quotient[i + 1, j + 1] = quotient[j + 1, i + 1] = value
    return quotient


def full_spectrum(a: int, blocks: tuple[int, ...]) -> np.ndarray:
    quotient_values = np.linalg.eigvalsh(quotient_matrix(a, blocks))
    minus_one_multiplicity = a + sum(blocks) - 6
    values = np.concatenate(
        (quotient_values, -np.ones(minus_one_multiplicity, dtype=float))
    )
    return np.sort(values)[::-1]


def s3(a: int, blocks: tuple[int, ...]) -> float:
    return float(full_spectrum(a, blocks)[:3].sum())


def edge_count(a: int, blocks: tuple[int, ...]) -> int:
    core = a * (a - 1) // 2
    core_periphery = a * sum(blocks)
    inside_blocks = sum(size * (size - 1) // 2 for size in blocks)
    cycle_edges = sum(blocks[i] * blocks[(i + 1) % 5] for i in range(5))
    return core + core_periphery + inside_blocks + cycle_edges


def balanced_formula(a: int, b: int) -> float:
    rho = (
        a
        + 3 * b
        - 2
        + math.sqrt((a - 3 * b) ** 2 + 20 * a * b)
    ) / 2
    return rho + (1 + math.sqrt(5)) * b - 2


def verify_key_cases() -> None:
    assert math.isclose(s3(1, (1, 1, 1, 1, 1)), math.sqrt(6) + math.sqrt(5))
    exact_7 = (1 + math.sqrt(41) + 2 * math.sqrt(5)) / 2
    assert math.isclose(s3(2, (1, 1, 1, 1, 1)), exact_7)

    value_8 = s3(2, (2, 1, 1, 1, 1))
    assert math.isclose(value_8, 7.1626389314, rel_tol=0, abs_tol=1e-9)
    assert edge_count(2, (2, 1, 1, 1, 1)) == 21

    value_9 = s3(2, (2, 2, 1, 1, 1))
    assert math.isclose(value_9, 8.4260294336, rel_tol=0, abs_tol=1e-9)
    assert edge_count(2, (2, 2, 1, 1, 1)) == 27

    for a in range(1, 5):
        for b in range(1, 5):
            assert math.isclose(
                s3(a, (b, b, b, b, b)),
                balanced_formula(a, b),
                rel_tol=0,
                abs_tol=1e-9,
            )


def search(a: int, peripheral_total: int) -> dict[str, object]:
    best_value = -math.inf
    best: dict[tuple[int, ...], tuple[int, ...]] = {}
    tolerance = 1e-10
    searched = 0

    for blocks in compositions(peripheral_total):
        searched += 1
        value = s3(a, blocks)
        representative = canonical_blocks(blocks)
        if value > best_value + tolerance:
            best_value = value
            best = {representative: blocks}
        elif abs(value - best_value) <= tolerance:
            best.setdefault(representative, blocks)

    representatives = sorted(best)
    first = representatives[0]
    return {
        "a": a,
        "peripheral_total": peripheral_total,
        "n": a + peripheral_total,
        "compositions_searched": searched,
        "best_s3": best_value,
        "best_s3_over_n": best_value / (a + peripheral_total),
        "best_representatives": ";".join(
            ",".join(map(str, blocks)) for blocks in representatives
        ),
        "dihedral_classes_tied": len(representatives),
        "max_block_gap": max(first) - min(first),
        "edges_first_representative": edge_count(a, first),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cores", nargs="+", type=int, default=[1, 2, 3, 5, 10])
    parser.add_argument("--min-peripheral", type=int, default=5)
    parser.add_argument("--max-peripheral", type=int, default=20)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("enumeration_results.csv"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.min_peripheral < 5 or args.max_peripheral < args.min_peripheral:
        raise ValueError("peripheral totals must satisfy 5 <= min <= max")

    verify_key_cases()
    rows = [
        search(a, total)
        for a in args.cores
        for total in range(args.min_peripheral, args.max_peripheral + 1)
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as output_file:
        writer = csv.DictWriter(output_file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    print("key-case verification: PASS")
    print(f"rows written: {len(rows)}")
    print(f"output: {args.output.resolve()}")


if __name__ == "__main__":
    main()
