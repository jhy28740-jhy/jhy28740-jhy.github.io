"""Search finite atomic competitors for the isotropic inner-product problem.

This is numerical evidence only.  For Q in St(N, 3), write
H(Q) = (Q Q^T)_+ entrywise.  Optimizing the atom weights for fixed Q gives
lambda_max(H); the Perron eigenvector s yields weights w_i=s_i^2 and atoms
x_i=Q_i/s_i.  Hence every iterate satisfies sum_i w_i x_i x_i^T=I_3.
"""

from __future__ import annotations

import argparse
import math

import numpy as np


C_STAR = (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0


def polar_retract(matrix: np.ndarray) -> np.ndarray:
    u, _, vt = np.linalg.svd(matrix, full_matrices=False)
    return u @ vt


def value_gradient(q: np.ndarray) -> tuple[float, np.ndarray, np.ndarray]:
    gram = q @ q.T
    positive = np.maximum(gram, 0.0)
    eigenvalues, eigenvectors = np.linalg.eigh(positive)
    s = np.abs(eigenvectors[:, -1])
    s /= np.linalg.norm(s)
    value = float(eigenvalues[-1])

    active = (gram > 0.0).astype(float)
    weighted_active = (s[:, None] * active) * s[None, :]
    ambient = 2.0 * weighted_active @ q
    tangent = ambient - q @ ((q.T @ ambient + ambient.T @ q) / 2.0)
    return value, tangent, s


def optimize(q: np.ndarray, iterations: int) -> tuple[float, np.ndarray, np.ndarray]:
    q = polar_retract(q)
    value, gradient, weights_root = value_gradient(q)
    step = 0.2

    for _ in range(iterations):
        norm = float(np.linalg.norm(gradient))
        if norm < 1e-10:
            break
        accepted = False
        trial_step = step
        for _ in range(20):
            trial = polar_retract(q + trial_step * gradient)
            trial_value, trial_gradient, trial_weights_root = value_gradient(trial)
            if trial_value >= value + 1e-4 * trial_step * norm * norm:
                q = trial
                value = trial_value
                gradient = trial_gradient
                weights_root = trial_weights_root
                step = min(0.5, 1.2 * trial_step)
                accepted = True
                break
            trial_step *= 0.5
        if not accepted:
            break
    return value, q, weights_root**2


def run(atom_count: int, restarts: int, iterations: int, seed: int) -> None:
    rng = np.random.default_rng(seed + atom_count)
    best_value = -math.inf
    best_q = np.empty((atom_count, 3))
    best_weights = np.empty(atom_count)

    for _ in range(restarts):
        q0 = rng.normal(size=(atom_count, 3))
        value, q, weights = optimize(q0, iterations)
        if value > best_value:
            best_value, best_q, best_weights = value, q, weights

    keep = best_weights > 1e-8
    atoms = best_q[keep] / np.sqrt(best_weights[keep, None])
    covariance = np.einsum("i,ij,ik->jk", best_weights[keep], atoms, atoms)
    print(
        f"N={atom_count:2d} value={best_value:.12f} "
        f"gap={C_STAR-best_value:+.3e} support={int(keep.sum())} "
        f"cov_error={np.max(np.abs(covariance-np.eye(3))):.2e}"
    )
    print("  weights:", np.array2string(np.sort(best_weights[keep])[::-1], precision=8))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-atoms", type=int, default=4)
    parser.add_argument("--max-atoms", type=int, default=12)
    parser.add_argument("--restarts", type=int, default=50)
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260902)
    args = parser.parse_args()

    print(f"c_star={C_STAR:.12f}")
    for atom_count in range(args.min_atoms, args.max_atoms + 1):
        run(atom_count, args.restarts, args.iterations, args.seed)


if __name__ == "__main__":
    main()
