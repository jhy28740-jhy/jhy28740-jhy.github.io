"""Exact Bernstein certificate for the global ``3dfe`` six-block bound.

The mathematical reduction in Chapter 5 shows that it is enough to prove
``P(32/25-a-b,a,b)>0`` on

    0 <= b <= a,  a+b <= 1/2.

The affine map ``a=y/2+z/4, b=z/4`` identifies this triangle with the
standard simplex ``x+y+z=1``.  This checker forms the homogeneous cubic in
exact rational arithmetic, converts it to triangular Bernstein form, raises
the Bernstein degree from three to eight, and checks every coefficient.
No floating-point value is used by the certificate.
"""

from __future__ import annotations

import math
from fractions import Fraction

import sympy as sp


def triangular_bernstein_coefficients(
    polynomial: sp.Poly, degree: int
) -> dict[tuple[int, int, int], Fraction]:
    coefficients: dict[tuple[int, int, int], Fraction] = {}
    for i in range(degree + 1):
        for j in range(degree + 1 - i):
            k = degree - i - j
            coefficient = sp.Rational(polynomial.coeff_monomial((i, j, k)))
            multinomial = math.factorial(degree) // (
                math.factorial(i) * math.factorial(j) * math.factorial(k)
            )
            coefficients[(i, j, k)] = Fraction(
                int(coefficient.p), int(coefficient.q) * multinomial
            )
    return coefficients


def elevate_degree(
    coefficients: dict[tuple[int, int, int], Fraction], degree: int
) -> dict[tuple[int, int, int], Fraction]:
    raised: dict[tuple[int, int, int], Fraction] = {}
    new_degree = degree + 1
    for i in range(new_degree + 1):
        for j in range(new_degree + 1 - i):
            k = new_degree - i - j
            value = Fraction(0)
            if i:
                value += Fraction(i, new_degree) * coefficients[(i - 1, j, k)]
            if j:
                value += Fraction(j, new_degree) * coefficients[(i, j - 1, k)]
            if k:
                value += Fraction(k, new_degree) * coefficients[(i, j, k - 1)]
            raised[(i, j, k)] = value
    return raised


def main() -> None:
    capital_a, capital_b, capital_l = sp.symbols("A B L")
    majorant = (
        2 * capital_a / (capital_l + capital_a)
        + 2 * capital_b / (capital_l + capital_b)
        + (1 - 2 * capital_a - 2 * capital_b)
        * capital_l
        / (capital_l**2 - capital_a**2)
    )
    root_polynomial = (
        capital_l**3
        + (capital_b - 1) * capital_l**2
        + (capital_a**2 + 2 * capital_b**2 - capital_b) * capital_l
        + 3 * capital_a**2 * capital_b
    )
    denominator = (capital_l**2 - capital_a**2) * (capital_l + capital_b)
    assert sp.factor((majorant - 1) * denominator + root_polynomial) == 0

    x, y, z = sp.symbols("x y z")
    simplex_sum = x + y + z
    a = y / 2 + z / 4
    b = z / 4
    ell = sp.Rational(32, 25) * simplex_sum - a - b

    # Homogenized form of
    # P(L)=L^3+(b-1)L^2+(a^2+2b^2-b)L+3a^2b.
    polynomial = sp.Poly(
        sp.expand(
            ell**3
            + (b - simplex_sum) * ell**2
            + (a**2 + 2 * b**2 - b * simplex_sum) * ell
            + 3 * a**2 * b
        ),
        x,
        y,
        z,
    )
    assert polynomial.total_degree() == 3

    degree = 3
    coefficients = triangular_bernstein_coefficients(polynomial, degree)
    while degree < 8:
        coefficients = elevate_degree(coefficients, degree)
        degree += 1

    minimum_index, minimum = min(coefficients.items(), key=lambda item: item[1])
    assert len(coefficients) == 45
    assert minimum == Fraction(38581, 28000000)
    assert all(value > 0 for value in coefficients.values())

    # Strict radical comparison: c_* > 5767/4500 > 32/25.
    assert 559**2 < 5 * 250**2
    assert 1479**2 < 35 * 250**2
    lower_c_star = Fraction(9, 18) + Fraction(559, 250 * 18) + Fraction(
        2 * 1479, 250 * 18
    )
    assert lower_c_star == Fraction(5767, 4500)
    assert lower_c_star > Fraction(32, 25)

    print("3dfe global Bernstein certificate passed")
    print(f"degree={degree} coefficient_count={len(coefficients)}")
    print(f"minimum_coefficient={minimum} index={minimum_index}")
    print(f"32/25 < {lower_c_star} < c_star")


if __name__ == "__main__":
    main()
