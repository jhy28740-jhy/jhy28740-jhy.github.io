"""Numerically audit the 13 six-block templates not covered by shifted dual certificates.

This script is exploratory only.  It uses deterministic random restarts to
locate likely maxima and reports boundary behavior, inertia, and spectral
gaps.  A separate exact Bernstein certificate now resolves ``3dfe``, so only
the other twelve templates remain open.  This historical thirteen-row audit
never upgrades any template to a proved case by itself.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from audit_six_block_topologies import C_STAR, optimize
from certify_six_block_low_inertia import edge_list, matrix_from_mask


MASKS = [
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
    0x3DFE,
]
OUTPUT_PATH = Path(__file__).resolve().parent / "kkt_audit_results.txt"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--restarts", type=int, default=100)
    parser.add_argument("--iterations", type=int, default=2500)
    parser.add_argument("--seed", type=int, default=20260903)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    print("Exploratory audit only; no exhaustive or interval proof.")
    print(f"templates={len(MASKS)} c_star={C_STAR:.12f}")
    output_lines = [
        "Exploratory audit only; no exhaustive or interval proof.",
        f"templates={len(MASKS)} c_star={C_STAR:.12f}",
    ]
    for mask in MASKS:
        template = np.array(matrix_from_mask(mask, float))
        starts = [np.zeros(6)]
        starts.extend(rng.normal(size=6) for _ in range(args.restarts - 1))
        best_value = -np.inf
        best_weights = np.zeros(6)
        for logits in starts:
            value, weights, _ = optimize(template, logits, args.iterations)
            if value > best_value:
                best_value = value
                best_weights = weights
        root = np.sqrt(best_weights)
        quotient = (root[:, None] * template) * root[None, :]
        eigenvalues = np.linalg.eigvalsh(quotient)
        # For a simple third positive eigenvalue, the KKT gradient is
        # (B_+)_{ii}/d_i.  The residual below is exploratory: it is not used
        # as a certificate, and near-zero weights are intentionally reported.
        positive = np.flatnonzero(eigenvalues > 1e-10)
        if len(positive) >= 3:
            selected = positive[-3:]
            vectors = np.linalg.eigh(quotient)[1][:, selected]
            projector = vectors @ vectors.T
            gradient = ((template * projector) @ root) / root
            kkt_residual = float(np.max(gradient) - np.min(gradient))
        else:
            kkt_residual = float("nan")
        spectral_gap = (
            float(eigenvalues[-3] - eigenvalues[-4])
            if len(eigenvalues) >= 4
            else float("nan")
        )
        summary = (
            f"mask={mask:04x} value={best_value:.12f} "
            f"gap={C_STAR-best_value:+.3e} min_weight={best_weights.min():.3e} "
            f"lambda4={eigenvalues[-4]:.9f} "
            f"gap34={spectral_gap:.3e} kkt_residual={kkt_residual:.3e} "
            f"edges=[{edge_list(mask)}]"
        )
        print(summary)
        output_lines.append(summary)
        weights_line = (
            "  weights="
            + np.array2string(best_weights, precision=10, suppress_small=True)
        )
        eigenvalues_line = (
            "  eigenvalues="
            + np.array2string(eigenvalues, precision=10, suppress_small=True)
        )
        print(weights_line)
        print(eigenvalues_line)
        output_lines.extend((weights_line, eigenvalues_line))
    OUTPUT_PATH.write_text("\n".join(output_lines) + "\n", encoding="utf-8")
    print(f"results_file={OUTPUT_PATH}")


if __name__ == "__main__":
    main()
