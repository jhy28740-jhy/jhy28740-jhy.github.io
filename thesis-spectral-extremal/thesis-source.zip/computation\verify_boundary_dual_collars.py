"""Standalone exact verifier for 68 wide boundary-collar certificates."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from fractions import Fraction
from pathlib import Path


N = 6
EDGES = list(itertools.combinations(range(N), 2))
FIVE_EDGES = list(itertools.combinations(range(5), 2))
DELTA = Fraction(1, 100)
C_STAR_LOWER = Fraction(5767, 4500)
COEFFICIENT_TARGET = 4 * C_STAR_LOWER - 2
EXPECTED_FACES = {
    0x03BC: tuple(range(N)),
    0x03BD: tuple(range(N)),
    0x03BE: (0, 1, 2, 4, 5),
    0x06DF: tuple(range(N)),
    0x077C: tuple(range(N)),
    0x077D: tuple(range(N)),
    0x07DE: (0, 1, 3, 4, 5),
    0x07FE: (0, 1, 3, 4, 5),
    0x0FDF: (1, 2, 3, 4, 5),
    0x1BBC: tuple(range(N)),
    0x1BBD: tuple(range(N)),
    0x1BFE: tuple(range(N)),
}
EXCEPTIONAL_FACES = {
    (0x03BE, 3),
    (0x07DE, 2),
    (0x07FE, 2),
    (0x0FDF, 0),
}
DEFAULT_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_boundary_dual_collar_certificates.json"
)


def parse_fraction(text: str) -> Fraction:
    numerator, denominator = text.split("/")
    return Fraction(int(numerator), int(denominator))


def matrix_from_mask(mask: int) -> list[list[Fraction]]:
    matrix = [
        [Fraction(i == j) for j in range(N)]
        for i in range(N)
    ]
    for bit, (i, j) in enumerate(EDGES):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = Fraction(1)
    return matrix


def swap_symmetric(matrix: list[list[Fraction]], i: int, j: int) -> None:
    matrix[i], matrix[j] = matrix[j], matrix[i]
    for row in matrix:
        row[i], row[j] = row[j], row[i]


def positive_definite(matrix: list[list[Fraction]]) -> bool:
    work = [row[:] for row in matrix]
    while work:
        pivot_index = next((i for i in range(len(work)) if work[i][i]), None)
        if pivot_index is None:
            return False
        swap_symmetric(work, 0, pivot_index)
        pivot = work[0][0]
        if pivot <= 0:
            return False
        work = [
            [
                work[i][j] - work[i][0] * work[0][j] / pivot
                for j in range(1, len(work))
            ]
            for i in range(1, len(work))
        ]
    return True


def exact_inertia(matrix: list[list[Fraction]]) -> tuple[int, int, int]:
    work = [row[:] for row in matrix]
    positive = negative = zero = 0
    while work:
        size = len(work)
        diagonal_pivot = next((i for i in range(size) if work[i][i]), None)
        if diagonal_pivot is not None:
            swap_symmetric(work, 0, diagonal_pivot)
            pivot = work[0][0]
            positive += int(pivot > 0)
            negative += int(pivot < 0)
            work = [
                [
                    work[i][j] - work[i][0] * work[0][j] / pivot
                    for j in range(1, size)
                ]
                for i in range(1, size)
            ]
            continue
        off_diagonal = next(
            (
                (i, j)
                for i in range(size)
                for j in range(i + 1, size)
                if work[i][j]
            ),
            None,
        )
        if off_diagonal is None:
            zero += size
            break
        i, j = off_diagonal
        swap_symmetric(work, 0, i)
        if j == 0:
            j = i
        swap_symmetric(work, 1, j)
        pivot = work[0][1]
        positive += 1
        negative += 1
        work = [
            [
                work[row][column]
                - (
                    work[row][0] * work[1][column]
                    + work[row][1] * work[0][column]
                )
                / pivot
                for column in range(2, size)
            ]
            for row in range(2, size)
        ]
    return positive, negative, zero


def induced_five_mask(mask: int, face: int) -> int:
    template = matrix_from_mask(mask)
    retained = [i for i in range(N) if i != face]
    result = 0
    for bit, (i, j) in enumerate(FIVE_EDGES):
        if template[retained[i]][retained[j]]:
            result |= 1 << bit
    return result


def permute_five_mask(mask: int, permutation: tuple[int, ...]) -> int:
    edge_to_bit = {edge: bit for bit, edge in enumerate(FIVE_EDGES)}
    result = 0
    for bit, (i, j) in enumerate(FIVE_EDGES):
        if mask & (1 << bit):
            edge = tuple(sorted((permutation[i], permutation[j])))
            result |= 1 << edge_to_bit[edge]
    return result


def canonical_five_mask(mask: int) -> int:
    return min(
        permute_five_mask(mask, permutation)
        for permutation in itertools.permutations(range(5))
    )


def five_matrix(mask: int) -> list[list[Fraction]]:
    matrix = [
        [Fraction(i == j) for j in range(5)]
        for i in range(5)
    ]
    for bit, (i, j) in enumerate(FIVE_EDGES):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = Fraction(1)
    return matrix


def inverse(matrix: list[list[Fraction]]) -> list[list[Fraction]]:
    size = len(matrix)
    augmented = [
        matrix[i][:] + [Fraction(i == j) for j in range(size)]
        for i in range(size)
    ]
    for column in range(size):
        pivot = next(row for row in range(column, size) if augmented[row][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [entry / scale for entry in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][j] - factor * augmented[column][j]
                for j in range(2 * size)
            ]
    return [row[size:] for row in augmented]


def exact_coefficients(
    matrix: list[list[Fraction]],
    gamma: list[Fraction],
    template: list[list[Fraction]],
) -> list[Fraction]:
    matrix_inverse = inverse(matrix)
    values = []
    for i in range(N):
        column = [
            template[j][i] - (gamma[i] if j == i else 0)
            for j in range(N)
        ]
        quadratic = sum(
            column[j] * matrix_inverse[j][k] * column[k]
            for j in range(N)
            for k in range(N)
        )
        values.append(2 * gamma[i] + matrix[i][i] + quadratic)
    return values


def verify_record(record: dict) -> tuple[int, int, Fraction]:
    mask = int(record["mask"], 16)
    face = int(record["face"]) - 1
    assert mask in EXPECTED_FACES and face in EXPECTED_FACES[mask]
    assert 0 <= face < N
    matrix = [[parse_fraction(value) for value in row] for row in record["matrix"]]
    gamma = [parse_fraction(value) for value in record["gamma"]]
    assert len(matrix) == N and all(len(row) == N for row in matrix)
    assert all(matrix[i][j] == matrix[j][i] for i in range(N) for j in range(N))
    assert len(gamma) == N and all(value >= 0 for value in gamma)
    assert positive_definite(matrix)

    values = exact_coefficients(matrix, gamma, matrix_from_mask(mask))
    stored_values = [parse_fraction(value) for value in record["dual_coefficients"]]
    assert values == stored_values
    candidates = []
    for i in range(N):
        if i == face:
            continue
        candidates.append(values[i])
        candidates.append((1 - DELTA) * values[i] + DELTA * values[face])
    maximum = max(candidates)
    assert maximum == parse_fraction(record["maximum_collar_coefficient"])
    assert Fraction(1, 2) + maximum / 4 == parse_fraction(record["certified_bound"])
    assert maximum < COEFFICIENT_TARGET
    return mask, face, Fraction(1, 2) + maximum / 4


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", nargs="?", type=Path, default=DEFAULT_PATH)
    args = parser.parse_args()
    raw = args.certificate.read_bytes()
    payload = json.loads(raw)
    assert payload["format_version"] == 1
    assert payload["dimension"] == N
    assert parse_fraction(payload["delta"]) == DELTA
    assert parse_fraction(payload["c_star_strict_lower_bound"]) == C_STAR_LOWER
    assert (
        parse_fraction(payload["coefficient_strict_upper_target"])
        == COEFFICIENT_TARGET
    )
    certified_faces = {
        int(mask, 16): tuple(face - 1 for face in faces)
        for mask, faces in payload["certified_faces"].items()
    }
    assert certified_faces == EXPECTED_FACES
    expected_count = sum(len(faces) for faces in EXPECTED_FACES.values())
    assert payload["certificate_count"] == expected_count

    verified = [verify_record(record) for record in payload["records"]]
    pairs = {(mask, face) for mask, face, _ in verified}
    expected_pairs = {
        (mask, face)
        for mask, faces in EXPECTED_FACES.items()
        for face in faces
    }
    assert pairs == expected_pairs and len(verified) == len(expected_pairs)
    for mask, face in EXCEPTIONAL_FACES:
        induced = induced_five_mask(mask, face)
        assert canonical_five_mask(induced) == 0x07E
        assert exact_inertia(five_matrix(induced)) == (4, 1, 0)
    worst = max(bound for _, _, bound in verified)

    # These strict integer comparisons imply 5767/4500 < c_star.
    assert 559**2 < 5 * 250**2
    assert 1479**2 < 35 * 250**2
    print("all exact boundary-collar certificates passed")
    print(f"certificate_count={len(verified)}")
    print(f"worst_exact_bound={worst.numerator}/{worst.denominator}")
    print(f"sha256={hashlib.sha256(raw).hexdigest().upper()}")


if __name__ == "__main__":
    main()
