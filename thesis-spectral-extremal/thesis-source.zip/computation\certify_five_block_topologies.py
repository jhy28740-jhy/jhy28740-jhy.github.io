"""Exact dual certificates for all five-block clique-diagonal templates.

The floating-point stage only searches for rational certificates.  Every
accepted certificate is then checked with Fraction arithmetic: positive
definiteness, the exact inverse, and the algebraic comparison with

    4*c_4 - 2 = (6 + 16*sqrt(6))/15.

Together with the moment/inertia bound in Theorem 5.17 and the analytic
K_1 join C_4 calculation, a successful run certifies the sharp universal
five-block bound c_4.  No floating-point comparison is used as proof.
"""

from __future__ import annotations

import itertools
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp


N = 5
EDGES = list(itertools.combinations(range(N), 2))
PERMUTATIONS = list(itertools.permutations(range(N)))
C4 = (9.0 + 4.0 * math.sqrt(6.0)) / 15.0
OUTPUT_PATH = Path(__file__).resolve().parent / "certificates" / "five_block_dual_certificates.json"


def permute_mask(mask: int, permutation: tuple[int, ...]) -> int:
    edge_to_bit = {edge: bit for bit, edge in enumerate(EDGES)}
    result = 0
    for bit, (i, j) in enumerate(EDGES):
        if not mask & (1 << bit):
            continue
        edge = tuple(sorted((permutation[i], permutation[j])))
        result |= 1 << edge_to_bit[edge]
    return result


def canonical_mask(mask: int) -> int:
    return min(permute_mask(mask, permutation) for permutation in PERMUTATIONS)


def canonical_masks() -> list[int]:
    masks = {canonical_mask(mask) for mask in range(1 << len(EDGES))}
    assert len(masks) == 34
    return sorted(masks)


def matrix_from_mask(mask: int, cls: type = float) -> list[list]:
    matrix = [[cls(i == j) for j in range(N)] for i in range(N)]
    for bit, (i, j) in enumerate(EDGES):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = cls(1)
    return matrix


def swap_symmetric(matrix: list[list[Fraction]], i: int, j: int) -> None:
    matrix[i], matrix[j] = matrix[j], matrix[i]
    for row in matrix:
        row[i], row[j] = row[j], row[i]


def exact_inertia(matrix: list[list[Fraction]]) -> tuple[int, int, int]:
    """Compute inertia by exact symmetric congruence elimination."""

    work = [row[:] for row in matrix]
    positive = negative = zero = 0
    while work:
        size = len(work)
        diagonal_pivot = next((i for i in range(size) if work[i][i]), None)
        if diagonal_pivot is not None:
            swap_symmetric(work, 0, diagonal_pivot)
            pivot = work[0][0]
            if pivot > 0:
                positive += 1
            else:
                negative += 1
            work = [
                [work[i][j] - work[i][0] * work[0][j] / pivot for j in range(1, size)]
                for i in range(1, size)
            ]
            continue

        off_diagonal = next(
            ((i, j) for i in range(size) for j in range(i + 1, size) if work[i][j]),
            None,
        )
        if off_diagonal is None:
            zero += size
            break

        i, j = off_diagonal
        swap_symmetric(work, 0, i)
        if j == 0:
            j = i
        swap_symmetric(work, 1, j)
        pivot = work[0][1]
        positive += 1
        negative += 1
        inverse_block = [[Fraction(0), 1 / pivot], [1 / pivot, Fraction(0)]]
        remainder: list[list[Fraction]] = []
        for row_index in range(2, size):
            row: list[Fraction] = []
            for column_index in range(2, size):
                correction = sum(
                    work[row_index][a]
                    * inverse_block[a][b]
                    * work[b][column_index]
                    for a in range(2)
                    for b in range(2)
                )
                row.append(work[row_index][column_index] - correction)
            remainder.append(row)
        work = remainder
    return positive, negative, zero


def unpack(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lower = np.zeros((N, N))
    cursor = 0
    for i in range(N):
        for j in range(i + 1):
            value = parameters[cursor]
            lower[i, j] = math.exp(value) if i == j else value
            cursor += 1
    return lower @ lower.T, lower


def pack_cholesky(matrix: np.ndarray) -> np.ndarray:
    lower = np.linalg.cholesky(matrix)
    values = []
    for i in range(N):
        for j in range(i + 1):
            values.append(math.log(lower[i, i]) if i == j else lower[i, j])
    return np.array(values)


def dual_values(matrix: np.ndarray, template: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    inverse_template_columns = np.linalg.solve(matrix, template)
    values = np.diag(matrix) + np.sum(template * inverse_template_columns, axis=0)
    return values, inverse_template_columns


def smooth_objective(
    parameters: np.ndarray, template: np.ndarray, sharpness: float
) -> tuple[float, np.ndarray]:
    matrix, lower = unpack(parameters)
    values, inverse_template_columns = dual_values(matrix, template)
    scaled = sharpness * values
    weights = np.exp(scaled - logsumexp(scaled))
    gradient_matrix = np.diag(weights)
    for i in range(N):
        vector = inverse_template_columns[:, i]
        gradient_matrix -= weights[i] * np.outer(vector, vector)
    gradient_lower = 2.0 * gradient_matrix @ lower
    gradient = []
    for i in range(N):
        for j in range(i + 1):
            entry = gradient_lower[i, j]
            gradient.append(entry * lower[i, i] if i == j else entry)
    return float(logsumexp(scaled) / sharpness), np.array(gradient)


def numerical_certificate(template: np.ndarray) -> np.ndarray:
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    starts = [absolute + shift * np.eye(N) for shift in (0.02, 0.1, 0.5)]
    starts.append(np.eye(N))
    best_matrix = np.eye(N)
    best_value = math.inf
    bounds = []
    for i in range(N):
        for j in range(i + 1):
            bounds.append((-5.0, 5.0) if i == j else (-8.0, 8.0))
    for start in starts:
        parameters = pack_cholesky(start)
        for sharpness in (20.0, 100.0, 500.0, 2500.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 3000, "ftol": 1e-14, "gtol": 1e-11},
            )
            parameters = result.x
        matrix, _ = unpack(parameters)
        value = float(np.max(dual_values(matrix, template)[0]))
        if value < best_value:
            best_value = value
            best_matrix = matrix
    return best_matrix


def inverse_fraction(matrix: list[list[Fraction]]) -> list[list[Fraction]]:
    size = len(matrix)
    augmented = [
        matrix[i][:] + [Fraction(i == j) for j in range(size)] for i in range(size)
    ]
    for column in range(size):
        pivot = next(row for row in range(column, size) if augmented[row][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [entry / scale for entry in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][j] - factor * augmented[column][j]
                for j in range(2 * size)
            ]
    return [row[size:] for row in augmented]


def is_positive_definite(matrix: list[list[Fraction]]) -> bool:
    return exact_inertia(matrix) == (N, 0, 0)


def below_target(value: Fraction) -> bool:
    """Check value < (6 + 16*sqrt(6))/15 without floating point."""

    left = 15 * value - 6
    return left <= 0 or left * left < 16 * 16 * 6


def rational_certificate(
    numerical: np.ndarray, template: list[list[Fraction]]
) -> tuple[list[list[Fraction]], list[Fraction]]:
    for digits in (5, 6, 7, 8, 9, 10):
        scale = 10**digits
        base = [
            [Fraction(int(round(numerical[i, j] * scale)), scale) for j in range(N)]
            for i in range(N)
        ]
        for bump_units in (0, 1, 2, 5, 10, 20, 50, 100):
            matrix = [row[:] for row in base]
            for i in range(N):
                matrix[i][i] += Fraction(bump_units, scale)
            if not is_positive_definite(matrix):
                continue
            inverse = inverse_fraction(matrix)
            values = []
            for i in range(N):
                column = [template[j][i] for j in range(N)]
                quadratic = sum(
                    column[j] * inverse[j][k] * column[k]
                    for j in range(N)
                    for k in range(N)
                )
                values.append(matrix[i][i] + quadratic)
            if all(below_target(value) for value in values):
                return matrix, values
    raise RuntimeError("failed to rationalize a strict dual certificate")


def edge_list(mask: int) -> str:
    return " ".join(
        f"{i + 1}{j + 1}" for bit, (i, j) in enumerate(EDGES) if mask & (1 << bit)
    )


def fraction_text(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def write_certificates(records: list[dict]) -> str:
    payload = {
        "format_version": 1,
        "statement": "All non-K1-join-C4 five-vertex templates of positive inertia three satisfy the strict matrix-fidelity dual bound.",
        "dimension": N,
        "unlabelled_template_count": 34,
        "positive_inertia_three_count": 17,
        "analytic_exception": "K1 join C4",
        "certificate_count": len(records),
        "records": records,
    }
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("ascii")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_bytes(encoded)
    return hashlib.sha256(encoded).hexdigest().upper()


def main() -> None:
    candidate_edges = {
        (0, 1),
        (0, 2),
        (0, 3),
        (0, 4),
        (1, 2),
        (2, 3),
        (3, 4),
        (1, 4),
    }
    candidate_mask = sum(1 << EDGES.index(edge) for edge in candidate_edges)
    candidate_mask = canonical_mask(candidate_mask)

    masks = canonical_masks()
    inertia_three = []
    certified = []
    for mask in masks:
        template_fraction = matrix_from_mask(mask, Fraction)
        inertia = exact_inertia(template_fraction)
        if inertia[0] != 3:
            continue
        inertia_three.append(mask)
        if mask == candidate_mask:
            continue
        template_float = np.array(matrix_from_mask(mask, float))
        numerical = numerical_certificate(template_float)
        rational, values = rational_certificate(numerical, template_fraction)
        maximum = max(values)
        assert is_positive_definite(rational)
        assert below_target(maximum)
        certified.append(
            {
                "mask": f"{mask:03x}",
                "edges": edge_list(mask).split(),
                "inertia": list(exact_inertia(template_fraction)),
                "matrix": [[fraction_text(value) for value in row] for row in rational],
                "dual_values": [fraction_text(value) for value in values],
                "maximum_dual_value": fraction_text(maximum),
            }
        )
        print(
            f"mask={mask:03x} edges=[{edge_list(mask)}] "
            f"max_dual={float(maximum):.12f} exact={maximum}"
        )

    assert len(masks) == 34
    assert len(inertia_three) == 17
    assert len(certified) == 16
    digest = write_certificates(certified)
    print(
        "EXACT CERTIFICATE PASSED: 34 unlabelled templates, "
        "17 positive-inertia-three templates, 16 strict rational dual "
        "certificates, and one analytic K1 join C4 equality template."
    )
    print(f"certificate_file={OUTPUT_PATH} sha256={digest}")


if __name__ == "__main__":
    main()
