"""Build the exact two-branch certificates for the four exceptional collars.

Twenty existing face certificates remain valid when their collar width is
enlarged from 1/100 to 1/60.  Four additional zero-shift fidelity certificates
bound the total positive spectrum on the exceptional 1/100 collars.  The
standalone verifier, rather than this floating-point search, is authoritative.
"""

from __future__ import annotations

import hashlib
import json
from fractions import Fraction
from pathlib import Path

from certify_boundary_dual_collars import (
    N,
    exact_coefficients,
    numerical_candidate,
)
from certify_six_block_low_inertia import (
    exact_inertia,
    fraction_text,
    matrix_from_mask,
)


EXCEPTION_FACES = {
    0x03BE: 3,
    0x07DE: 2,
    0x07FE: 2,
    0x0FDF: 0,
}
AUXILIARY_DELTA = Fraction(1, 60)
EXCEPTION_DELTA = Fraction(1, 100)
C_STAR_LOWER = Fraction(5767, 4500)
AUXILIARY_COEFFICIENT_TARGET = 4 * C_STAR_LOWER - 2
POSITIVE_SUM_TARGET = C_STAR_LOWER + AUXILIARY_DELTA
POSITIVE_SUM_COEFFICIENT_TARGET = 4 * POSITIVE_SUM_TARGET - 2
SOURCE_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_boundary_dual_collar_certificates.json"
)
OUTPUT_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_exception_boundary_collar_certificates.json"
)


def parse_fraction(text: str) -> Fraction:
    numerator, denominator = text.split("/")
    return Fraction(int(numerator), int(denominator))


def collar_maximum(
    values: list[Fraction], face: int, delta: Fraction
) -> Fraction:
    candidates = []
    for index in range(N):
        if index == face:
            continue
        candidates.append(values[index])
        candidates.append(
            (1 - delta) * values[index] + delta * values[face]
        )
    return max(candidates)


def expanded_auxiliary_records() -> tuple[list[dict], str]:
    source_bytes = SOURCE_PATH.read_bytes()
    source_hash = hashlib.sha256(source_bytes).hexdigest().upper()
    payload = json.loads(source_bytes)
    selected = []
    for record in payload["records"]:
        mask = int(record["mask"], 16)
        face = int(record["face"]) - 1
        if mask not in EXCEPTION_FACES or face == EXCEPTION_FACES[mask]:
            continue
        values = [parse_fraction(value) for value in record["dual_coefficients"]]
        maximum = collar_maximum(values, face, AUXILIARY_DELTA)
        assert maximum < AUXILIARY_COEFFICIENT_TARGET
        selected.append(
            {
                "mask": record["mask"],
                "face": face + 1,
                "matrix": record["matrix"],
                "gamma": record["gamma"],
                "dual_coefficients": record["dual_coefficients"],
                "maximum_collar_coefficient": fraction_text(maximum),
                "certified_bound": fraction_text(
                    Fraction(1, 2) + maximum / 4
                ),
            }
        )
    assert len(selected) == 20
    return sorted(selected, key=lambda item: (item["mask"], item["face"])), source_hash


def rationalize_zero_shift(
    numerical_matrix,
    template: list[list[Fraction]],
    face: int,
) -> tuple[list[list[Fraction]], list[Fraction], Fraction]:
    gamma = [Fraction(0) for _ in range(N)]
    for digits in (5, 6, 7, 8, 9, 10):
        scale = 10**digits
        base = [
            [
                Fraction(int(round(numerical_matrix[i, j] * scale)), scale)
                for j in range(N)
            ]
            for i in range(N)
        ]
        for bump_units in (0, 1, 2, 5, 10, 20, 50, 100):
            matrix = [row[:] for row in base]
            for index in range(N):
                matrix[index][index] += Fraction(bump_units, scale)
            if exact_inertia(matrix) != (N, 0, 0):
                continue
            values = exact_coefficients(matrix, gamma, template)
            maximum = collar_maximum(values, face, EXCEPTION_DELTA)
            if maximum < POSITIVE_SUM_COEFFICIENT_TARGET:
                return matrix, values, maximum
    raise RuntimeError(f"failed to rationalize exceptional face {face + 1}")


def positive_sum_records() -> list[dict]:
    records = []
    for mask, face in EXCEPTION_FACES.items():
        numerical_matrix, numerical_gamma, _ = numerical_candidate(mask, face, 3)
        assert max(abs(value) for value in numerical_gamma) < 1e-8
        template = matrix_from_mask(mask, Fraction)
        matrix, values, maximum = rationalize_zero_shift(
            numerical_matrix, template, face
        )
        records.append(
            {
                "mask": f"{mask:04x}",
                "face": face + 1,
                "matrix": [
                    [fraction_text(value) for value in row] for row in matrix
                ],
                "gamma": ["0/1"] * N,
                "dual_coefficients": [fraction_text(value) for value in values],
                "maximum_collar_coefficient": fraction_text(maximum),
                "certified_positive_sum_bound": fraction_text(
                    Fraction(1, 2) + maximum / 4
                ),
            }
        )
    assert len(records) == 4
    return sorted(records, key=lambda item: item["mask"])


def main() -> None:
    auxiliary, source_hash = expanded_auxiliary_records()
    positive_sum = positive_sum_records()
    payload = {
        "format_version": 1,
        "statement": (
            "A two-branch exact certificate excludes all four formerly "
            "exceptional collars d_k <= 1/100.  If another coordinate is at "
            "most 1/60, an expanded face certificate applies.  Otherwise "
            "interlacing and the 07e fourth positive eigenvalue subtract more "
            "than 1/60 from the certified total positive spectrum."
        ),
        "dimension": N,
        "exception_faces": {
            f"{mask:04x}": face + 1 for mask, face in EXCEPTION_FACES.items()
        },
        "auxiliary_delta": fraction_text(AUXILIARY_DELTA),
        "exception_delta": fraction_text(EXCEPTION_DELTA),
        "c_star_strict_lower_bound": fraction_text(C_STAR_LOWER),
        "auxiliary_coefficient_target": fraction_text(
            AUXILIARY_COEFFICIENT_TARGET
        ),
        "positive_sum_target": fraction_text(POSITIVE_SUM_TARGET),
        "positive_sum_coefficient_target": fraction_text(
            POSITIVE_SUM_COEFFICIENT_TARGET
        ),
        "source_certificate_sha256": source_hash,
        "auxiliary_certificate_count": len(auxiliary),
        "positive_sum_certificate_count": len(positive_sum),
        "auxiliary_records": auxiliary,
        "positive_sum_records": positive_sum,
    }
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode(
        "ascii"
    )
    OUTPUT_PATH.write_bytes(encoded)
    digest = hashlib.sha256(encoded).hexdigest().upper()
    print(f"auxiliary_certificate_count={len(auxiliary)}")
    print(f"positive_sum_certificate_count={len(positive_sum)}")
    print(f"sha256={digest}")
    print(f"certificate_file={OUTPUT_PATH}")


if __name__ == "__main__":
    main()
