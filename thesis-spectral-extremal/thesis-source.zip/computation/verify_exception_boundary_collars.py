"""Standalone Fraction verifier for the four exceptional 1/100 collars."""

from __future__ import annotations

import hashlib
import itertools
import json
from fractions import Fraction
from pathlib import Path


N = 6
EDGES = list(itertools.combinations(range(N), 2))
EXCEPTION_FACES = {
    0x03BE: 3,
    0x07DE: 2,
    0x07FE: 2,
    0x0FDF: 0,
}
AUXILIARY_DELTA = Fraction(1, 60)
EXCEPTION_DELTA = Fraction(1, 100)
C_STAR_LOWER = Fraction(5767, 4500)
AUXILIARY_COEFFICIENT_TARGET = Fraction(3517, 1125)
POSITIVE_SUM_TARGET = Fraction(2921, 2250)
POSITIVE_SUM_COEFFICIENT_TARGET = Fraction(3592, 1125)
SOURCE_SHA256 = "2D9577E2908974208FED54C2F35CEBC76B4BD940D5DAFB76B53FEEFC26BC873C"
CERTIFICATE_SHA256 = "F8C75D4106E3A32CC6B460EBE2B17D054CEF937B369C2F1D40D7714178659400"
CERTIFICATE_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_exception_boundary_collar_certificates.json"
)
SOURCE_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_boundary_dual_collar_certificates.json"
)


def parse_fraction(text: str) -> Fraction:
    numerator, denominator = text.split("/")
    return Fraction(int(numerator), int(denominator))


def matrix_from_mask(mask: int, size: int = N) -> list[list[Fraction]]:
    edges = list(itertools.combinations(range(size), 2))
    matrix = [
        [Fraction(i == j) for j in range(size)] for i in range(size)
    ]
    for bit, (i, j) in enumerate(edges):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = Fraction(1)
    return matrix


def swap_symmetric(matrix: list[list[Fraction]], i: int, j: int) -> None:
    matrix[i], matrix[j] = matrix[j], matrix[i]
    for row in matrix:
        row[i], row[j] = row[j], row[i]


def exact_inertia(matrix: list[list[Fraction]]) -> tuple[int, int, int]:
    work = [row[:] for row in matrix]
    positive = negative = zero = 0
    while work:
        size = len(work)
        diagonal = next((i for i in range(size) if work[i][i]), None)
        if diagonal is not None:
            swap_symmetric(work, 0, diagonal)
            pivot = work[0][0]
            positive += int(pivot > 0)
            negative += int(pivot < 0)
            work = [
                [
                    work[i][j] - work[i][0] * work[0][j] / pivot
                    for j in range(1, size)
                ]
                for i in range(1, size)
            ]
            continue
        off_diagonal = next(
            (
                (i, j)
                for i in range(size)
                for j in range(i + 1, size)
                if work[i][j]
            ),
            None,
        )
        if off_diagonal is None:
            zero += size
            break
        i, j = off_diagonal
        swap_symmetric(work, 0, i)
        swap_symmetric(work, 1, j)
        pivot = work[0][1]
        positive += 1
        negative += 1
        work = [
            [
                work[row][column]
                - (
                    work[row][0] * work[1][column]
                    + work[row][1] * work[0][column]
                )
                / pivot
                for column in range(2, size)
            ]
            for row in range(2, size)
        ]
    return positive, negative, zero


def inverse(matrix: list[list[Fraction]]) -> list[list[Fraction]]:
    size = len(matrix)
    augmented = [
        matrix[i][:] + [Fraction(i == j) for j in range(size)]
        for i in range(size)
    ]
    for column in range(size):
        pivot = next(row for row in range(column, size) if augmented[row][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [entry / scale for entry in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][j] - factor * augmented[column][j]
                for j in range(2 * size)
            ]
    result = [row[size:] for row in augmented]
    assert all(
        sum(matrix[i][k] * result[k][j] for k in range(size))
        == Fraction(i == j)
        for i in range(size)
        for j in range(size)
    )
    return result


def exact_coefficients(
    matrix: list[list[Fraction]],
    gamma: list[Fraction],
    template: list[list[Fraction]],
) -> list[Fraction]:
    matrix_inverse = inverse(matrix)
    values = []
    for i in range(N):
        column = [
            template[j][i] - (gamma[i] if j == i else 0)
            for j in range(N)
        ]
        quadratic = sum(
            column[j] * matrix_inverse[j][k] * column[k]
            for j in range(N)
            for k in range(N)
        )
        values.append(2 * gamma[i] + matrix[i][i] + quadratic)
    return values


def collar_maximum(
    values: list[Fraction], face: int, delta: Fraction
) -> Fraction:
    candidates = []
    for index in range(N):
        if index == face:
            continue
        candidates.append(values[index])
        candidates.append(
            (1 - delta) * values[index] + delta * values[face]
        )
    assert len(candidates) == 10
    return max(candidates)


def induced_matrix(
    template: list[list[Fraction]], deleted: int
) -> list[list[Fraction]]:
    indices = [index for index in range(N) if index != deleted]
    return [[template[i][j] for j in indices] for i in indices]


def isomorphic(left: list[list[Fraction]], right: list[list[Fraction]]) -> bool:
    size = len(left)
    return any(
        all(left[p[i]][p[j]] == right[i][j] for i in range(size) for j in range(size))
        for p in itertools.permutations(range(size))
    )


def verify_record(record: dict, delta: Fraction, target: Fraction) -> Fraction:
    mask = int(record["mask"], 16)
    face = int(record["face"]) - 1
    matrix = [[parse_fraction(value) for value in row] for row in record["matrix"]]
    gamma = [parse_fraction(value) for value in record["gamma"]]
    assert len(matrix) == N and all(len(row) == N for row in matrix)
    assert all(matrix[i][j] == matrix[j][i] for i in range(N) for j in range(N))
    assert exact_inertia(matrix) == (N, 0, 0)
    assert len(gamma) == N and all(value >= 0 for value in gamma)
    template = matrix_from_mask(mask)
    values = exact_coefficients(matrix, gamma, template)
    assert values == [
        parse_fraction(value) for value in record["dual_coefficients"]
    ]
    maximum = collar_maximum(values, face, delta)
    assert maximum == parse_fraction(record["maximum_collar_coefficient"])
    assert maximum < target
    return Fraction(1, 2) + maximum / 4


def main() -> None:
    source_hash = hashlib.sha256(SOURCE_PATH.read_bytes()).hexdigest().upper()
    assert source_hash == SOURCE_SHA256
    raw = CERTIFICATE_PATH.read_bytes()
    payload = json.loads(raw)
    assert payload["format_version"] == 1
    assert payload["dimension"] == N
    assert parse_fraction(payload["auxiliary_delta"]) == AUXILIARY_DELTA
    assert parse_fraction(payload["exception_delta"]) == EXCEPTION_DELTA
    assert parse_fraction(payload["c_star_strict_lower_bound"]) == C_STAR_LOWER
    assert (
        parse_fraction(payload["auxiliary_coefficient_target"])
        == AUXILIARY_COEFFICIENT_TARGET
    )
    assert parse_fraction(payload["positive_sum_target"]) == POSITIVE_SUM_TARGET
    assert (
        parse_fraction(payload["positive_sum_coefficient_target"])
        == POSITIVE_SUM_COEFFICIENT_TARGET
    )
    assert payload["source_certificate_sha256"] == SOURCE_SHA256
    expected_faces = {
        f"{mask:04x}": face + 1 for mask, face in EXCEPTION_FACES.items()
    }
    assert payload["exception_faces"] == expected_faces

    target_07e = matrix_from_mask(0x07E, size=5)
    # The off-diagonal graph of 07e is exactly K_{2,3}; hence its spectrum is
    # 1+sqrt(6), 1, 1, 1, 1-sqrt(6), with fourth positive eigenvalue 1.
    expected_07e = {
        (0, 2), (0, 3), (0, 4), (1, 2), (1, 3), (1, 4)
    }
    observed_07e = {
        (i, j)
        for i in range(5)
        for j in range(i + 1, 5)
        if target_07e[i][j]
    }
    assert observed_07e == expected_07e
    assert exact_inertia(target_07e) == (4, 1, 0)
    for mask, face in EXCEPTION_FACES.items():
        template = matrix_from_mask(mask)
        assert exact_inertia(template) == (4, 2, 0)
        assert isomorphic(induced_matrix(template, face), target_07e)

    auxiliary = payload["auxiliary_records"]
    assert payload["auxiliary_certificate_count"] == 20 == len(auxiliary)
    expected_auxiliary_pairs = {
        (mask, face)
        for mask, exception in EXCEPTION_FACES.items()
        for face in range(N)
        if face != exception
    }
    observed_auxiliary_pairs = {
        (int(record["mask"], 16), int(record["face"]) - 1)
        for record in auxiliary
    }
    assert observed_auxiliary_pairs == expected_auxiliary_pairs
    auxiliary_bounds = []
    for record in auxiliary:
        bound = verify_record(
            record, AUXILIARY_DELTA, AUXILIARY_COEFFICIENT_TARGET
        )
        assert bound == parse_fraction(record["certified_bound"])
        assert bound < C_STAR_LOWER
        auxiliary_bounds.append(bound)

    positive_sum = payload["positive_sum_records"]
    assert payload["positive_sum_certificate_count"] == 4 == len(positive_sum)
    observed_positive_pairs = {
        (int(record["mask"], 16), int(record["face"]) - 1)
        for record in positive_sum
    }
    assert observed_positive_pairs == set(EXCEPTION_FACES.items())
    positive_sum_bounds = []
    for record in positive_sum:
        assert all(parse_fraction(value) == 0 for value in record["gamma"])
        bound = verify_record(
            record, EXCEPTION_DELTA, POSITIVE_SUM_COEFFICIENT_TARGET
        )
        assert bound == parse_fraction(record["certified_positive_sum_bound"])
        assert bound < POSITIVE_SUM_TARGET
        positive_sum_bounds.append(bound)

    # Branch 1 gives K3 < C_STAR_LOWER.  In branch 2 all five retained
    # coordinates exceed 1/60.  Ostrowski's congruence bound and interlacing
    # give lambda_4(B)>1/60, while the zero-shift certificate gives the total
    # positive spectrum < C_STAR_LOWER+1/60.
    assert POSITIVE_SUM_TARGET - AUXILIARY_DELTA == C_STAR_LOWER
    assert 559**2 < 5 * 250**2
    assert 1479**2 < 35 * 250**2

    digest = hashlib.sha256(raw).hexdigest().upper()
    assert digest == CERTIFICATE_SHA256
    print("all exceptional boundary-collar certificates passed")
    print(f"auxiliary_certificate_count={len(auxiliary_bounds)}")
    print(f"positive_sum_certificate_count={len(positive_sum_bounds)}")
    print(f"worst_auxiliary_bound={max(auxiliary_bounds)}")
    print(f"worst_positive_sum_bound={max(positive_sum_bounds)}")
    print(f"source_sha256={source_hash}")
    print(f"sha256={digest}")


if __name__ == "__main__":
    main()
