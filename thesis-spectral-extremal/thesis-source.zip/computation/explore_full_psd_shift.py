"""Explore full positive-semidefinite shifts for unresolved six-block templates.

This is a numerical search only.  A PSD shift Gamma and X positive definite
give the same affine fidelity bound as the diagonal-shift lemma, with only
diag(Gamma) entering the final coefficients.  Any useful candidate must still
be rationalized and checked by a separate exact verifier.
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

from certify_six_block_low_inertia import matrix_from_mask
from explore_remaining_stationary import MASKS


N = 6


def unpack(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    lower_x = np.zeros((N, N))
    lower_g = np.zeros((N, N))
    cursor = 0
    for lower, positive_diagonal in ((lower_x, True), (lower_g, False)):
        for i in range(N):
            for j in range(i + 1):
                value = parameters[cursor]
                if i == j:
                    lower[i, j] = math.exp(value) if positive_diagonal else value
                else:
                    lower[i, j] = value
                cursor += 1
    return lower_x @ lower_x.T, lower_g @ lower_g.T, lower_x, lower_g


def pack(matrix_x: np.ndarray, matrix_g: np.ndarray) -> np.ndarray:
    lower_x = np.linalg.cholesky(matrix_x)
    lower_g = np.linalg.cholesky(matrix_g + 1e-8 * np.eye(N))
    values = []
    for lower, log_diagonal in ((lower_x, True), (lower_g, False)):
        for i in range(N):
            for j in range(i + 1):
                values.append(math.log(lower[i, i]) if log_diagonal and i == j else lower[i, j])
    return np.asarray(values)


def coefficients(matrix_x: np.ndarray, gamma: np.ndarray, template: np.ndarray) -> np.ndarray:
    shifted = template - gamma
    inverse_columns = np.linalg.solve(matrix_x, shifted)
    return 2.0 * np.diag(gamma) + np.diag(matrix_x) + np.sum(shifted * inverse_columns, axis=0)


def objective(
    parameters: np.ndarray, template: np.ndarray, sharpness: float
) -> tuple[float, np.ndarray]:
    matrix_x, gamma, lower_x, lower_g = unpack(parameters)
    shifted = template - gamma
    inverse_columns = np.linalg.solve(matrix_x, shifted)
    values = 2.0 * np.diag(gamma) + np.diag(matrix_x) + np.sum(
        shifted * inverse_columns, axis=0
    )
    scaled = sharpness * values
    weights = np.exp(scaled - logsumexp(scaled))

    gradient_x = np.diag(weights)
    gradient_g = 2.0 * np.diag(weights)
    for i in range(N):
        vector = inverse_columns[:, i]
        gradient_x -= weights[i] * np.outer(vector, vector)
        basis = np.zeros(N)
        basis[i] = 1.0
        gradient_g -= weights[i] * (
            np.outer(vector, basis) + np.outer(basis, vector)
        )

    gradient_lower_x = 2.0 * gradient_x @ lower_x
    gradient_lower_g = 2.0 * gradient_g @ lower_g
    gradient = []
    for lower, lower_gradient, log_diagonal in (
        (lower_x, gradient_lower_x, True),
        (lower_g, gradient_lower_g, False),
    ):
        for i in range(N):
            for j in range(i + 1):
                entry = lower_gradient[i, j]
                gradient.append(entry * lower[i, i] if log_diagonal and i == j else entry)
    return float(logsumexp(scaled) / sharpness), np.asarray(gradient)


def spectral_start(template: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    positive = np.flatnonzero(eigenvalues > 0.0)
    index = positive[0]
    vector = eigenvectors[:, index]
    gamma = eigenvalues[index] * np.outer(vector, vector)
    shifted = template - gamma
    values, vectors = np.linalg.eigh(shifted)
    absolute = (vectors * np.maximum(np.abs(values), 1e-4)) @ vectors.T
    return absolute + 1e-4 * np.eye(N), gamma


def zero_shift_start(template: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values, vectors = np.linalg.eigh(template)
    absolute = (vectors * np.maximum(np.abs(values), 1e-4)) @ vectors.T
    return absolute + 1e-4 * np.eye(N), np.zeros((N, N))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--maxiter", type=int, default=5000)
    args = parser.parse_args()
    target = 4.0 * (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0 - 2.0
    print(f"target={target:.12f}; exploratory floating-point search only")
    bounds = [(-7.0, 7.0)] * (N * (N + 1))
    for mask in MASKS:
        template = np.asarray(matrix_from_mask(mask, float))
        best = math.inf
        best_parameters = None
        for matrix_x, gamma in (zero_shift_start(template), spectral_start(template)):
            parameters = pack(matrix_x, gamma)
            for sharpness in (20.0, 100.0, 500.0, 2000.0):
                result = minimize(
                    objective,
                    parameters,
                    args=(template, sharpness),
                    jac=True,
                    method="L-BFGS-B",
                    bounds=bounds,
                    options={"maxiter": args.maxiter, "ftol": 1e-14, "gtol": 1e-10},
                )
                parameters = result.x
            matrix_x, gamma, _, _ = unpack(parameters)
            candidate = float(np.max(coefficients(matrix_x, gamma, template)))
            if candidate < best:
                best = candidate
                best_parameters = parameters.copy()
        assert best_parameters is not None
        print(
            f"mask={mask:04x} bound={0.5 + best / 4.0:.12f} "
            f"coefficient={best:.12f} margin={target-best:+.3e} success={result.success}"
        )


if __name__ == "__main__":
    main()
