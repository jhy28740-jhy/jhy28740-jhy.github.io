"""Adaptive numerical exploration of local Ky Fan--fidelity box certificates.

For a box l <= d <= u in the probability simplex and tau >= 0, set

    A = T - diag(tau / u).

Then B(d)-tau*I <= diag(sqrt(d))*A*diag(sqrt(d)), so the positive-part
trace and the fidelity variational formula give an affine upper bound for the
top-three spectral sum.  This script searches for a finite box cover.  It is
not a rigorous certificate: a later exporter must rationalize every box and a
separate exact verifier must check the cover and all matrix inequalities.
"""

from __future__ import annotations

import argparse
import heapq
import math
from dataclasses import dataclass, field

import numpy as np

from certify_six_block_low_inertia import matrix_from_mask
from explore_remaining_stationary import MASKS


C_STAR = (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0
CERTIFIED_TARGET = 2563.0 / 2000.0
N = 6


@dataclass(order=True)
class QueueItem:
    priority: float
    serial: int
    box: "Box" = field(compare=False)


@dataclass
class Box:
    lower: np.ndarray
    upper: np.ndarray
    depth: int = 0


def tighten(box: Box) -> Box | None:
    lower = box.lower.copy()
    upper = box.upper.copy()
    for _ in range(2 * N):
        old_lower = lower.copy()
        old_upper = upper.copy()
        for i in range(N):
            lower[i] = max(lower[i], 1.0 - (np.sum(upper) - upper[i]))
            upper[i] = min(upper[i], 1.0 - (np.sum(lower) - lower[i]))
        if np.sum(lower) > 1.0 + 1e-13 or np.sum(upper) < 1.0 - 1e-13:
            return None
        if max(np.max(abs(lower - old_lower)), np.max(abs(upper - old_upper))) < 1e-15:
            break
    return Box(lower, upper, box.depth)


def feasible_center(box: Box) -> np.ndarray:
    point = (box.lower + box.upper) / 2.0
    delta = 1.0 - float(np.sum(point))
    slack = box.upper - point if delta >= 0.0 else point - box.lower
    total = float(np.sum(slack))
    if total <= 0.0:
        return point
    point += math.copysign(1.0, delta) * abs(delta) * slack / total
    return point


def affine_max(coefficients: np.ndarray, box: Box) -> float:
    point = box.lower.copy()
    remaining = 1.0 - float(np.sum(point))
    for index in np.argsort(-coefficients):
        amount = min(remaining, box.upper[index] - point[index])
        point[index] += amount
        remaining -= amount
        if remaining <= 2e-14:
            break
    if abs(remaining) > 1e-10:
        raise RuntimeError("infeasible tightened box")
    return float(coefficients @ point)


def positive_sqrt(matrix: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh((matrix + matrix.T) / 2.0)
    if values[0] < -1e-8:
        raise RuntimeError(f"matrix lost PSD: {values[0]}")
    return (vectors * np.sqrt(np.maximum(values, 1e-14))) @ vectors.T


def certificate(template: np.ndarray, box: Box) -> tuple[float, float, np.ndarray]:
    center = feasible_center(box)
    root = np.sqrt(center)
    quotient = root[:, None] * template * root[None, :]
    eigenvalues = np.linalg.eigvalsh(quotient)
    tau = max(0.0, 0.5 * (eigenvalues[-3] + eigenvalues[-4]))
    shifted = template - np.diag(tau / box.upper)
    moment = shifted @ np.diag(center) @ shifted
    middle = root[:, None] * moment * root[None, :]
    matrix_x = (positive_sqrt(middle) / root[:, None]) / root[None, :]
    inverse_columns = np.linalg.solve(matrix_x, shifted)
    coefficients = (
        0.5 * (1.0 - tau / box.upper)
        + 0.25 * (np.diag(matrix_x) + np.sum(shifted * inverse_columns, axis=0))
    )
    return 3.0 * tau + affine_max(coefficients, box), tau, coefficients


def split(box: Box) -> tuple[Box, Box]:
    widths = box.upper - box.lower
    index = int(np.argmax(widths))
    midpoint = 0.5 * (box.lower[index] + box.upper[index])
    upper_left = box.upper.copy()
    upper_left[index] = midpoint
    lower_right = box.lower.copy()
    lower_right[index] = midpoint
    return (
        Box(box.lower.copy(), upper_left, box.depth + 1),
        Box(lower_right, box.upper.copy(), box.depth + 1),
    )


def cover(template: np.ndarray, max_boxes: int) -> tuple[int, int, float, Box | None]:
    initial = tighten(Box(np.full(N, 0.01), np.full(N, 0.95)))
    assert initial is not None
    queue: list[QueueItem] = []
    serial = 0
    initial_bound, _, _ = certificate(template, initial)
    heapq.heappush(queue, QueueItem(-initial_bound, serial, initial))
    certified = 0
    max_depth = 0
    worst_certified = -math.inf
    while queue and certified + len(queue) < max_boxes:
        item = heapq.heappop(queue)
        box = item.box
        bound, _, _ = certificate(template, box)
        if bound < CERTIFIED_TARGET - 2e-8:
            certified += 1
            max_depth = max(max_depth, box.depth)
            worst_certified = max(worst_certified, bound)
            continue
        for child in split(box):
            child = tighten(child)
            if child is None:
                continue
            child_bound, _, _ = certificate(template, child)
            serial += 1
            heapq.heappush(queue, QueueItem(-child_bound, serial, child))
    worst = None if not queue else queue[0].box
    return certified, len(queue), worst_certified, worst


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mask", type=lambda value: int(value, 16), default=MASKS[0])
    parser.add_argument("--max-boxes", type=int, default=100000)
    args = parser.parse_args()
    if args.mask not in MASKS:
        raise SystemExit("mask is not one of the twelve unresolved templates")
    template = np.asarray(matrix_from_mask(args.mask, float))
    certified, remaining, worst_bound, worst = cover(template, args.max_boxes)
    print(
        f"mask={args.mask:04x} certified={certified} remaining={remaining} "
        f"worst_certified={worst_bound:.12f} target={CERTIFIED_TARGET:.12f} "
        "exploratory_only=True"
    )
    if worst is not None:
        bound, tau, _ = certificate(template, worst)
        print(f"next_bound={bound:.12f} tau={tau:.12f} depth={worst.depth}")
        print("lower=" + np.array2string(worst.lower, precision=8))
        print("upper=" + np.array2string(worst.upper, precision=8))


if __name__ == "__main__":
    main()
