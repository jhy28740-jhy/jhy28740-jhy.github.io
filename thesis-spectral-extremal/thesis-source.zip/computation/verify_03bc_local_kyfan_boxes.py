"""Independently verify the exact local Ky Fan box certificate for 03bc."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from certify_six_block_low_inertia import matrix_from_mask


MASK = 0x03BC
N = 6
TARGET = Fraction(2563, 2000)
CERTIFICATE_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_03bc_local_kyfan_boxes.json"
)


@dataclass(frozen=True)
class Box:
    lower: tuple[Fraction, ...]
    upper: tuple[Fraction, ...]
    depth: int = 0


def tighten(box: Box) -> Box | None:
    lower = list(box.lower)
    upper = list(box.upper)
    for _ in range(2 * N):
        old = (tuple(lower), tuple(upper))
        for i in range(N):
            lower[i] = max(lower[i], 1 - (sum(upper) - upper[i]))
            upper[i] = min(upper[i], 1 - (sum(lower) - lower[i]))
        if sum(lower) > 1 or sum(upper) < 1:
            return None
        if old == (tuple(lower), tuple(upper)):
            break
    return Box(tuple(lower), tuple(upper), box.depth)


def split(box: Box, index: int) -> tuple[Box | None, Box | None]:
    assert 0 <= index < N
    midpoint = (box.lower[index] + box.upper[index]) / 2
    assert box.lower[index] < midpoint < box.upper[index]
    upper_left = list(box.upper)
    upper_left[index] = midpoint
    lower_right = list(box.lower)
    lower_right[index] = midpoint
    return (
        tighten(Box(box.lower, tuple(upper_left), box.depth + 1)),
        tighten(Box(tuple(lower_right), box.upper, box.depth + 1)),
    )


def affine_max(coefficients: list[Fraction], box: Box) -> Fraction:
    point = list(box.lower)
    remaining = 1 - sum(point)
    for index in sorted(range(N), key=lambda i: coefficients[i], reverse=True):
        amount = min(remaining, box.upper[index] - point[index])
        point[index] += amount
        remaining -= amount
        if remaining == 0:
            break
    assert remaining == 0
    return sum(coefficients[i] * point[i] for i in range(N))


def leaf_bound(
    template: list[list[Fraction]], box: Box, node: list
) -> Fraction:
    assert len(node) == 5 and node[0] == "c"
    scale = int(node[1])
    tau = Fraction(int(node[2]), scale)
    entries = [int(value) for value in node[3]]
    claimed = Fraction(node[4])
    assert scale in (10**6, 10**7, 10**8, 10**9)
    assert tau >= 0 and len(entries) == N * (N + 1) // 2

    lower = [[Fraction(0) for _ in range(N)] for _ in range(N)]
    cursor = 0
    for i in range(N):
        for j in range(i + 1):
            lower[i][j] = Fraction(entries[cursor], scale)
            cursor += 1
        assert lower[i][i] > 0

    shifted = [row[:] for row in template]
    for i in range(N):
        assert box.upper[i] > 0
        shifted[i][i] -= tau / box.upper[i]

    coefficients = []
    for column in range(N):
        right = [shifted[row][column] for row in range(N)]
        solution = []
        for row in range(N):
            numerator = right[row] - sum(
                lower[row][j] * solution[j] for j in range(row)
            )
            solution.append(numerator / lower[row][row])
        matrix_diagonal = sum(lower[column][j] ** 2 for j in range(column + 1))
        quadratic = sum(value**2 for value in solution)
        coefficients.append(
            Fraction(1, 2) * (1 - tau / box.upper[column])
            + Fraction(1, 4) * (matrix_diagonal + quadratic)
        )

    bound = 3 * tau + affine_max(coefficients, box)
    assert bound == claimed
    assert bound < TARGET
    return bound


def main() -> None:
    encoded = CERTIFICATE_PATH.read_bytes()
    digest = hashlib.sha256(encoded).hexdigest().upper()
    payload = json.loads(encoded)
    assert payload["format_version"] == 1
    assert payload["mask"] == f"{MASK:04x}"
    assert payload["dimension"] == N
    assert Fraction(payload["core_lower_bound"]) == Fraction(1, 100)
    assert Fraction(payload["target"]) == TARGET
    nodes = payload["nodes"]
    assert payload["node_count"] == len(nodes)

    template = matrix_from_mask(MASK, Fraction)
    root = tighten(
        Box(tuple([Fraction(1, 100)] * N), tuple([Fraction(19, 20)] * N))
    )
    assert root is not None
    stack = [(0, root)]
    visited: set[int] = set()
    leaf_count = 0
    maximum_depth = 0
    maximum_bound = Fraction(0)

    while stack:
        node_index, box = stack.pop()
        assert 0 <= node_index < len(nodes) and node_index not in visited
        visited.add(node_index)
        node = nodes[node_index]
        assert isinstance(node, list) and node
        if node[0] == "c":
            bound = leaf_bound(template, box, node)
            maximum_bound = max(maximum_bound, bound)
            maximum_depth = max(maximum_depth, box.depth)
            leaf_count += 1
            continue

        assert len(node) == 4 and node[0] == "s"
        children = split(box, int(node[1]))
        for child_index, child_box in zip((int(node[2]), int(node[3])), children):
            if child_index == -1:
                assert child_box is None
            else:
                assert child_box is not None
                stack.append((child_index, child_box))

    assert len(visited) == len(nodes)
    assert leaf_count == payload["leaf_count"]
    assert maximum_depth == payload["maximum_depth"]
    assert maximum_bound == Fraction(payload["maximum_certified_bound"])

    # Rational lower bounds prove 2563/2000 < c_star.
    assert 559**2 < 5 * 250**2
    assert 2958**2 < 35 * 500**2
    c_star_lower = (
        Fraction(9) + Fraction(559, 250) + 2 * Fraction(2958, 500)
    ) / 18
    assert TARGET < c_star_lower

    print("03bc exact local Ky Fan box certificate passed")
    print(f"leaf_count={leaf_count} node_count={len(nodes)} max_depth={maximum_depth}")
    print(f"maximum_certified_bound={maximum_bound}")
    print(f"sha256={digest}")


if __name__ == "__main__":
    main()
