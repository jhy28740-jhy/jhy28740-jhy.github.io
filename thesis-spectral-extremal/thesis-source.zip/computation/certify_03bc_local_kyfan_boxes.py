"""Build an exact local Ky Fan--fidelity box certificate for mask 03bc.

Floating-point eigensolvers only propose a threshold and Cholesky factor for
each box.  A leaf is accepted only after exact Fraction arithmetic proves its
affine upper bound is below 2563/2000.  The binary split tree records a cover
of the full simplex core d_i >= 1/100.
"""

from __future__ import annotations

import hashlib
import heapq
import json
import math
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path

import numpy as np

from certify_six_block_low_inertia import fraction_text, matrix_from_mask


MASK = 0x03BC
N = 6
TARGET = Fraction(2563, 2000)
OUTPUT_PATH = (
    Path(__file__).resolve().parent
    / "certificates"
    / "six_block_03bc_local_kyfan_boxes.json"
)


@dataclass(order=True)
class QueueItem:
    priority: float
    serial: int
    node: int = field(compare=False)
    box: "Box" = field(compare=False)


@dataclass(frozen=True)
class Box:
    lower: tuple[Fraction, ...]
    upper: tuple[Fraction, ...]
    depth: int = 0


def tighten(box: Box) -> Box | None:
    lower = list(box.lower)
    upper = list(box.upper)
    for _ in range(2 * N):
        old = (tuple(lower), tuple(upper))
        for i in range(N):
            lower[i] = max(lower[i], 1 - (sum(upper) - upper[i]))
            upper[i] = min(upper[i], 1 - (sum(lower) - lower[i]))
        if sum(lower) > 1 or sum(upper) < 1:
            return None
        if old == (tuple(lower), tuple(upper)):
            break
    return Box(tuple(lower), tuple(upper), box.depth)


def feasible_center(box: Box) -> np.ndarray:
    lower = np.asarray([float(value) for value in box.lower])
    upper = np.asarray([float(value) for value in box.upper])
    point = (lower + upper) / 2.0
    delta = 1.0 - float(np.sum(point))
    slack = upper - point if delta >= 0.0 else point - lower
    point += math.copysign(1.0, delta) * abs(delta) * slack / np.sum(slack)
    return point


def positive_sqrt(matrix: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh((matrix + matrix.T) / 2.0)
    if values[0] <= 0.0:
        raise RuntimeError(f"expected positive definite matrix, got {values[0]}")
    return (vectors * np.sqrt(values)) @ vectors.T


def numerical_candidate(
    template: np.ndarray, box: Box
) -> tuple[float, np.ndarray]:
    center = feasible_center(box)
    upper = np.asarray([float(value) for value in box.upper])
    root = np.sqrt(center)
    quotient = root[:, None] * template * root[None, :]
    eigenvalues = np.linalg.eigvalsh(quotient)
    tau = max(0.0, 0.5 * (eigenvalues[-3] + eigenvalues[-4]))
    shifted = template - np.diag(tau / upper)
    moment = shifted @ np.diag(center) @ shifted
    middle = root[:, None] * moment * root[None, :]
    matrix_x = (positive_sqrt(middle) / root[:, None]) / root[None, :]
    return tau, np.linalg.cholesky((matrix_x + matrix_x.T) / 2.0)


def affine_max(coefficients: list[Fraction], box: Box) -> Fraction:
    point = list(box.lower)
    remaining = 1 - sum(point)
    for index in sorted(range(N), key=lambda i: coefficients[i], reverse=True):
        amount = min(remaining, box.upper[index] - point[index])
        point[index] += amount
        remaining -= amount
        if remaining == 0:
            break
    if remaining:
        raise RuntimeError("infeasible tightened box")
    return sum(coefficients[i] * point[i] for i in range(N))


def affine_max_float(coefficients: np.ndarray, box: Box) -> float:
    lower = np.asarray([float(value) for value in box.lower])
    upper = np.asarray([float(value) for value in box.upper])
    point = lower.copy()
    remaining = 1.0 - float(np.sum(point))
    for index in np.argsort(-coefficients):
        amount = min(remaining, upper[index] - point[index])
        point[index] += amount
        remaining -= amount
        if remaining <= 2e-14:
            break
    return float(coefficients @ point)


def exact_bound(
    template: list[list[Fraction]],
    box: Box,
    tau: Fraction,
    lower: list[list[Fraction]],
) -> Fraction:
    shifted = [row[:] for row in template]
    for i in range(N):
        shifted[i][i] -= tau / box.upper[i]

    coefficients = []
    for column in range(N):
        right = [shifted[row][column] for row in range(N)]
        solution = []
        for row in range(N):
            numerator = right[row] - sum(
                lower[row][j] * solution[j] for j in range(row)
            )
            solution.append(numerator / lower[row][row])
        matrix_diagonal = sum(lower[column][j] ** 2 for j in range(column + 1))
        quadratic = sum(value**2 for value in solution)
        coefficients.append(
            Fraction(1, 2) * (1 - tau / box.upper[column])
            + Fraction(1, 4) * (matrix_diagonal + quadratic)
        )
    return 3 * tau + affine_max(coefficients, box)


def rational_leaf(
    template: list[list[Fraction]], box: Box, tau_float: float, lower_float: np.ndarray
) -> list | None:
    for digits in (6, 7, 8, 9):
        scale = 10**digits
        tau_numerator = int(round(tau_float * scale))
        entries = [
            int(round(lower_float[i, j] * scale))
            for i in range(N)
            for j in range(i + 1)
        ]
        lower = [[Fraction(0) for _ in range(N)] for _ in range(N)]
        cursor = 0
        for i in range(N):
            for j in range(i + 1):
                lower[i][j] = Fraction(entries[cursor], scale)
                cursor += 1
            if lower[i][i] <= 0:
                break
        else:
            tau = Fraction(tau_numerator, scale)
            bound = exact_bound(template, box, tau, lower)
            if bound < TARGET:
                return ["c", scale, tau_numerator, entries, fraction_text(bound)]
    return None


def split(box: Box) -> tuple[int, Box, Box]:
    widths = [box.upper[i] - box.lower[i] for i in range(N)]
    index = max(range(N), key=lambda i: (widths[i], -i))
    midpoint = (box.lower[index] + box.upper[index]) / 2
    upper_left = list(box.upper)
    upper_left[index] = midpoint
    lower_right = list(box.lower)
    lower_right[index] = midpoint
    return (
        index,
        Box(box.lower, tuple(upper_left), box.depth + 1),
        Box(tuple(lower_right), box.upper, box.depth + 1),
    )


def numerical_bound(template: np.ndarray, box: Box) -> float:
    """Cheap priority only; exact acceptance is performed in rational_leaf."""
    tau, lower = numerical_candidate(template, box)
    shifted = template - np.diag(tau / np.asarray([float(v) for v in box.upper]))
    inverse_columns = np.linalg.solve(lower @ lower.T, shifted)
    center = feasible_center(box)
    coeff = 0.5 * (1.0 - tau / np.asarray([float(v) for v in box.upper]))
    coeff += 0.25 * (np.diag(lower @ lower.T) + np.sum(shifted * inverse_columns, axis=0))
    return 3.0 * tau + affine_max_float(coeff, box)


def build_certificate() -> dict:
    template_float = np.asarray(matrix_from_mask(MASK, float))
    template_fraction = matrix_from_mask(MASK, Fraction)
    initial = tighten(
        Box(tuple([Fraction(1, 100)] * N), tuple([Fraction(19, 20)] * N))
    )
    assert initial is not None

    nodes: list[list | None] = [None]
    boxes: dict[int, Box] = {0: initial}
    queue: list[QueueItem] = [QueueItem(-float(TARGET), 0, 0, initial)]
    serial = 0
    leaf_count = 0
    maximum_bound = Fraction(0)
    maximum_depth = 0

    while queue:
        item = heapq.heappop(queue)
        node = item.node
        box = item.box
        quick_bound = numerical_bound(template_float, box)
        leaf = None
        if quick_bound < float(TARGET) - 2e-7:
            tau_float, lower_float = numerical_candidate(template_float, box)
            leaf = rational_leaf(
                template_fraction, box, tau_float, lower_float
            )
        if leaf is not None:
            nodes[node] = leaf
            leaf_count += 1
            maximum_bound = max(maximum_bound, Fraction(leaf[-1]))
            maximum_depth = max(maximum_depth, box.depth)
            if leaf_count % 2000 == 0:
                print(
                    f"leaves={leaf_count} queue={len(queue)} nodes={len(nodes)} "
                    f"max_bound={float(maximum_bound):.12f}"
                )
            continue

        split_index, left_box, right_box = split(box)
        child_ids = []
        for child_box in (left_box, right_box):
            child_box = tighten(child_box)
            if child_box is None:
                child_ids.append(-1)
                continue
            child = len(nodes)
            nodes.append(None)
            boxes[child] = child_box
            serial += 1
            priority = -numerical_bound(template_float, child_box)
            heapq.heappush(queue, QueueItem(priority, serial, child, child_box))
            child_ids.append(child)
        nodes[node] = ["s", split_index, child_ids[0], child_ids[1]]
        boxes.pop(node, None)

    assert all(node is not None for node in nodes)
    return {
        "format_version": 1,
        "statement": (
            "The mask 03bc satisfies Psi_T(d) < 2563/2000 for every "
            "probability vector with d_i >= 1/100."
        ),
        "mask": f"{MASK:04x}",
        "dimension": N,
        "core_lower_bound": "1/100",
        "target": fraction_text(TARGET),
        "leaf_count": leaf_count,
        "node_count": len(nodes),
        "maximum_depth": maximum_depth,
        "maximum_certified_bound": fraction_text(maximum_bound),
        "nodes": nodes,
    }


def main() -> None:
    payload = build_certificate()
    encoded = (json.dumps(payload, separators=(",", ":")) + "\n").encode("ascii")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_bytes(encoded)
    digest = hashlib.sha256(encoded).hexdigest().upper()
    print(
        f"wrote={OUTPUT_PATH} leaves={payload['leaf_count']} "
        f"nodes={payload['node_count']} max_depth={payload['maximum_depth']}"
    )
    print(f"maximum_certified_bound={payload['maximum_certified_bound']}")
    print(f"sha256={digest}")


if __name__ == "__main__":
    main()
