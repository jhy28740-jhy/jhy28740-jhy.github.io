"""Explore full positive-semidefinite shifts in the fidelity dual.

This is floating-point reconnaissance only.  Unlike the existing diagonal
shift, the variable Gamma here is a full positive-definite matrix.  A strict
theorem would require rationalizing both X and Gamma and checking them with
exact congruence elimination.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
from scipy.optimize import check_grad, minimize
from scipy.special import logsumexp

from certify_six_block_low_inertia import N, matrix_from_mask


MASKS = (
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
)
C_STAR = (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "full_psd_shifted_dual_search.txt"
LOWER_SIZE = N * (N + 1) // 2


def matrix_from_parameters(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lower = np.zeros((N, N))
    cursor = 0
    for i in range(N):
        for j in range(i + 1):
            value = parameters[cursor]
            lower[i, j] = math.exp(value) if i == j else value
            cursor += 1
    return lower @ lower.T, lower


def parameters_from_matrix(matrix: np.ndarray) -> np.ndarray:
    lower = np.linalg.cholesky(matrix)
    result = []
    for i in range(N):
        for j in range(i + 1):
            result.append(math.log(lower[i, i]) if i == j else lower[i, j])
    return np.asarray(result)


def pack(matrix: np.ndarray, gamma: np.ndarray) -> np.ndarray:
    return np.r_[parameters_from_matrix(matrix), parameters_from_matrix(gamma)]


def unpack(
    parameters: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    matrix, lower_matrix = matrix_from_parameters(parameters[:LOWER_SIZE])
    gamma, lower_gamma = matrix_from_parameters(parameters[LOWER_SIZE:])
    return matrix, lower_matrix, gamma, lower_gamma


def coefficients(
    matrix: np.ndarray, gamma: np.ndarray, template: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    shifted = template - gamma
    inverse_columns = np.linalg.solve(matrix, shifted)
    values = 2.0 * np.diag(gamma) + np.diag(matrix) + np.sum(
        shifted * inverse_columns, axis=0
    )
    return values, inverse_columns


def lower_gradient(gradient: np.ndarray, lower: np.ndarray) -> np.ndarray:
    raw = 2.0 * gradient @ lower
    result = []
    for i in range(N):
        for j in range(i + 1):
            entry = raw[i, j]
            result.append(entry * lower[i, i] if i == j else entry)
    return np.asarray(result)


def smooth_objective(
    parameters: np.ndarray, template: np.ndarray, sharpness: float
) -> tuple[float, np.ndarray]:
    matrix, lower_matrix, gamma, lower_gamma = unpack(parameters)
    values, inverse_columns = coefficients(matrix, gamma, template)
    scaled = sharpness * values
    weights = np.exp(scaled - logsumexp(scaled))

    gradient_matrix = np.diag(weights)
    for i in range(N):
        vector = inverse_columns[:, i]
        gradient_matrix -= weights[i] * np.outer(vector, vector)

    weighted = np.diag(weights)
    gradient_gamma = 2.0 * weighted - (
        inverse_columns @ weighted + weighted @ inverse_columns.T
    )
    gradient = np.r_[
        lower_gradient(gradient_matrix, lower_matrix),
        lower_gradient(gradient_gamma, lower_gamma),
    ]
    return float(logsumexp(scaled) / sharpness), gradient


def initial_points(template: np.ndarray) -> list[tuple[np.ndarray, np.ndarray]]:
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    fourth_vector = eigenvectors[:, -4]
    fourth_value = max(0.0, eigenvalues[-4])
    rank_one_shift = fourth_value * np.outer(fourth_vector, fourth_vector)
    shifted = template - rank_one_shift
    shifted_values, shifted_vectors = np.linalg.eigh(shifted)
    shifted_absolute = (
        shifted_vectors * np.abs(shifted_values)
    ) @ shifted_vectors.T
    epsilon = 1e-3
    return [
        (absolute + 0.05 * np.eye(N), epsilon * np.eye(N)),
        (shifted_absolute + 0.05 * np.eye(N), rank_one_shift + epsilon * np.eye(N)),
        (np.eye(N), 0.10 * np.eye(N)),
    ]


def optimize(template: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    bounds = []
    for _ in range(2):
        for i in range(N):
            for j in range(i + 1):
                bounds.append((-7.0, 5.0) if i == j else (-10.0, 10.0))
    best_matrix = np.eye(N)
    best_gamma = np.eye(N)
    best = math.inf
    for start_matrix, start_gamma in initial_points(template):
        parameters = pack(start_matrix, start_gamma)
        for sharpness in (20.0, 100.0, 500.0, 2000.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 3000, "ftol": 1e-14, "gtol": 1e-11},
            )
            parameters = result.x
        matrix, _, gamma, _ = unpack(parameters)
        value = float(np.max(coefficients(matrix, gamma, template)[0]))
        if np.isfinite(value) and value < best:
            best_matrix, best_gamma, best = matrix, gamma, value
    return best_matrix, best_gamma, best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gradient-check", action="store_true")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    if args.gradient_check:
        template = np.asarray(matrix_from_mask(MASKS[0], float))
        matrix, gamma = initial_points(template)[1]
        point = pack(matrix, gamma)
        sharpness = 11.0
        error = check_grad(
            lambda x: smooth_objective(x, template, sharpness)[0],
            lambda x: smooth_objective(x, template, sharpness)[1],
            point,
        )
        print(f"gradient_check_error={error:.6e}")

    lines = [
        "Exploratory full-PSD shifted-dual search only; no exact certificate.",
        f"c_star={C_STAR:.12f} coefficient_target={4.0 * C_STAR - 2.0:.12f}",
    ]
    for mask in MASKS:
        template = np.asarray(matrix_from_mask(mask, float))
        matrix, gamma, value = optimize(template)
        bound = 0.5 + 0.25 * value
        line = (
            f"mask={mask:04x} coefficient={value:.12f} bound={bound:.12f} "
            f"below_c_star={bound < C_STAR} "
            f"min_eig_X={np.min(np.linalg.eigvalsh(matrix)):.3e} "
            f"min_eig_Gamma={np.min(np.linalg.eigvalsh(gamma)):.3e}"
        )
        print(line)
        lines.append(line)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"results_file={args.output.resolve()}")


if __name__ == "__main__":
    main()
