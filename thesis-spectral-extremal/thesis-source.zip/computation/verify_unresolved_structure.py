"""Verify exact structural data used for the unresolved six-block templates.

This script checks finite combinatorial identities and the rank-one/matching
decomposition for mask 3dfe.  It does not optimize sigma_3 and does not prove
the remaining global inequality.
"""

from __future__ import annotations

import itertools
from fractions import Fraction

import networkx as nx
import numpy as np

from certify_six_block_low_inertia import EDGES, edge_list, matrix_from_mask


MASKS = [
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
    0x3DFE,
]


def complement_edges(mask: int) -> list[str]:
    present = set(edge_list(mask).split())
    return [f"{i + 1}{j + 1}" for i, j in EDGES if f"{i + 1}{j + 1}" not in present]


def automorphism_orbits(mask: int) -> list[list[int]]:
    graph = nx.Graph()
    graph.add_nodes_from(range(6))
    graph.add_edges_from(
        (i, j)
        for i, j in EDGES
        if mask & (1 << EDGES.index((i, j)))
    )
    matcher = nx.algorithms.isomorphism.GraphMatcher(graph, graph)
    automorphisms = list(matcher.isomorphisms_iter())
    unseen = set(range(6))
    orbits = []
    while unseen:
        vertex = min(unseen)
        orbit = sorted({permutation[vertex] for permutation in automorphisms})
        orbits.append([x + 1 for x in orbit])
        unseen.difference_update(orbit)
    return orbits


def check_3dfe_decomposition() -> None:
    rng = np.random.default_rng(20260903)
    template = np.asarray(matrix_from_mask(0x3DFE, float))
    for _ in range(8):
        weights = rng.random(6)
        weights /= weights.sum()
        s = np.sqrt(weights)
        pairs = [(0, 1), (2, 3), (4, 5)]
        p = np.array([(s[i] + s[j]) / np.sqrt(2.0) for i, j in pairs])
        q = np.array([(s[i] - s[j]) / np.sqrt(2.0) for i, j in pairs])
        rho = np.array([s[i] * s[j] for i, j in pairs])

        basis = []
        for i, j in pairs:
            basis.append(np.eye(6)[i] / np.sqrt(2.0) + np.eye(6)[j] / np.sqrt(2.0))
            basis.append(np.eye(6)[i] / np.sqrt(2.0) - np.eye(6)[j] / np.sqrt(2.0))
        # Reorder from pairwise (symmetric, antisymmetric) to all symmetric,
        # then all antisymmetric directions.
        U = np.column_stack(basis)
        U = U[:, [0, 2, 4, 1, 3, 5]]
        root = s[:, None] * template * s[None, :]
        upper = np.outer(p, p) - np.diag(rho)
        lower = np.outer(q, q) + np.diag(rho)
        expected = np.block(
            [[upper, np.outer(p, q)], [np.outer(q, p), lower]]
        )
        assert np.max(np.abs(U.T @ root @ U - expected)) < 2e-12

        # The secular equation is checked away from the six poles.
        eigenvalues = np.linalg.eigvalsh(root)
        for value in eigenvalues:
            if np.min(np.abs(value - np.r_[rho, -rho])) < 1e-7:
                continue
            lhs = 1.0 - np.sum(p * p / (value + rho)) - np.sum(
                q * q / (value - rho)
            )
            assert abs(lhs) < 2e-7


def main() -> None:
    expected_complements = {
        0x03BC: "12 13 24 35 36 45 46 56",
        0x03BD: "13 24 35 36 45 46 56",
        0x03BE: "12 24 35 36 45 46 56",
        0x06DF: "23 26 36 45 46 56",
        0x077C: "12 13 25 36 45 46 56",
        0x077D: "13 25 36 45 46 56",
        0x07DE: "12 23 36 45 46 56",
        0x07FE: "12 36 45 46 56",
        0x0FDF: "23 45 46 56",
        0x1BBC: "12 13 24 35 46 56",
        0x1BBD: "13 24 35 46 56",
        0x1BFE: "12 35 46 56",
        0x3DFE: "12 34 56",
    }
    for mask in MASKS:
        actual = " ".join(complement_edges(mask))
        assert actual == expected_complements[mask], (f"{mask:04x}", actual)
        print(f"mask={mask:04x} complement=[{actual}] orbits={automorphism_orbits(mask)}")
    check_3dfe_decomposition()
    print("3dfe decomposition and secular checks passed")
    print("Structural verification only; no global sigma_3 bound is claimed.")


if __name__ == "__main__":
    main()
