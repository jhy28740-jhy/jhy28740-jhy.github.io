"""Verify exact structural data used for the unresolved six-block templates.

This script checks finite combinatorial identities, the rank-one/matching
decomposition for mask 3dfe, and the pair-balanced 3dfe reduction.  It does
not optimize general sigma_3 and does not prove the remaining global
inequality.
"""

from __future__ import annotations

import itertools
import math
from fractions import Fraction

import networkx as nx
import numpy as np

from certify_six_block_low_inertia import EDGES, edge_list, matrix_from_mask


MASKS = [
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
    0x3DFE,
]


def complement_edges(mask: int) -> list[str]:
    present = set(edge_list(mask).split())
    return [f"{i + 1}{j + 1}" for i, j in EDGES if f"{i + 1}{j + 1}" not in present]


def automorphism_orbits(mask: int) -> list[list[int]]:
    graph = nx.Graph()
    graph.add_nodes_from(range(6))
    graph.add_edges_from(
        (i, j)
        for i, j in EDGES
        if mask & (1 << EDGES.index((i, j)))
    )
    matcher = nx.algorithms.isomorphism.GraphMatcher(graph, graph)
    automorphisms = list(matcher.isomorphisms_iter())
    unseen = set(range(6))
    orbits = []
    while unseen:
        vertex = min(unseen)
        orbit = sorted({permutation[vertex] for permutation in automorphisms})
        orbits.append([x + 1 for x in orbit])
        unseen.difference_update(orbit)
    return orbits


def check_3dfe_decomposition() -> None:
    rng = np.random.default_rng(20260903)
    template = np.asarray(matrix_from_mask(0x3DFE, float))
    for _ in range(8):
        weights = rng.random(6)
        weights /= weights.sum()
        s = np.sqrt(weights)
        pairs = [(0, 1), (2, 3), (4, 5)]
        p = np.array([(s[i] + s[j]) / np.sqrt(2.0) for i, j in pairs])
        q = np.array([(s[i] - s[j]) / np.sqrt(2.0) for i, j in pairs])
        rho = np.array([s[i] * s[j] for i, j in pairs])

        basis = []
        for i, j in pairs:
            basis.append(np.eye(6)[i] / np.sqrt(2.0) + np.eye(6)[j] / np.sqrt(2.0))
            basis.append(np.eye(6)[i] / np.sqrt(2.0) - np.eye(6)[j] / np.sqrt(2.0))
        # Reorder from pairwise (symmetric, antisymmetric) to all symmetric,
        # then all antisymmetric directions.
        U = np.column_stack(basis)
        U = U[:, [0, 2, 4, 1, 3, 5]]
        root = s[:, None] * template * s[None, :]
        upper = np.outer(p, p) - np.diag(rho)
        lower = np.outer(q, q) + np.diag(rho)
        expected = np.block(
            [[upper, np.outer(p, q)], [np.outer(q, p), lower]]
        )
        assert np.max(np.abs(U.T @ root @ U - expected)) < 2e-12

        # The secular equation is checked away from the six poles.
        eigenvalues = np.linalg.eigvalsh(root)
        for value in eigenvalues:
            if np.min(np.abs(value - np.r_[rho, -rho])) < 1e-7:
                continue
            lhs = 1.0 - np.sum(p * p / (value + rho)) - np.sum(
                q * q / (value - rho)
            )
            assert abs(lhs) < 2e-7


def check_3dfe_symmetric_slice() -> None:
    template = np.asarray(matrix_from_mask(0x3DFE, float))
    for r in np.linspace(0.0, 1.0 / 3.0, 31):
        weights = np.array(
            [(1.0 - r) / 4.0] * 4 + [r / 2.0] * 2,
            dtype=float,
        )
        root = np.sqrt(weights)
        eigenvalues = np.linalg.eigvalsh(root[:, None] * template * root[None, :])
        observed = float(eigenvalues[-3:].sum())
        formula = (7.0 - 5.0 * r + math.sqrt(9.0 + 34.0 * r - 39.0 * r * r)) / 8.0
        assert abs(observed - formula) < 2e-12
    r_star = (17.0 - 5.0 * math.sqrt(10.0)) / 39.0
    value = 47.0 / 78.0 + 8.0 * math.sqrt(10.0) / 39.0
    c4 = (9.0 + 4.0 * math.sqrt(6.0)) / 15.0
    assert 0.0 < r_star < 1.0 / 3.0
    assert value < c4


def check_3dfe_pair_balancing() -> None:
    template = np.asarray(matrix_from_mask(0x3DFE, float))
    rng = np.random.default_rng(20260904)
    for _ in range(200):
        pair_masses = rng.random(3)
        pair_masses /= pair_masses.sum()
        weights = np.repeat(pair_masses / 2.0, 2)
        root = np.sqrt(weights)
        eigenvalues = np.linalg.eigvalsh(root[:, None] * template * root[None, :])
        observed = float(eigenvalues[-3:].sum())

        r = float(np.min(pair_masses))
        balanced_upper = (
            7.0
            - 5.0 * r
            + math.sqrt(9.0 + 34.0 * r - 39.0 * r * r)
        ) / 8.0
        assert observed <= balanced_upper + 3e-12

    r_star = (17.0 - 5.0 * math.sqrt(10.0)) / 39.0
    pair_masses = np.array([(1.0 - r_star) / 2.0] * 2 + [r_star])
    weights = np.repeat(pair_masses / 2.0, 2)
    root = np.sqrt(weights)
    eigenvalues = np.linalg.eigvalsh(root[:, None] * template * root[None, :])
    observed = float(eigenvalues[-3:].sum())
    exact_value = 47.0 / 78.0 + 8.0 * math.sqrt(10.0) / 39.0
    assert abs(observed - exact_value) < 3e-12


def check_3dfe_two_balanced_one_split() -> None:
    template = np.asarray(matrix_from_mask(0x3DFE, float))
    c4 = (9.0 + 4.0 * math.sqrt(6.0)) / 15.0
    for r in np.linspace(0.0, 1.0, 51):
        a = (1.0 - r) / 4.0
        endpoint = np.array([a, a, r, 0.0, a, a])
        endpoint_root = np.sqrt(endpoint)
        endpoint_eigenvalues = np.linalg.eigvalsh(
            endpoint_root[:, None] * template * endpoint_root[None, :]
        )
        endpoint_value = float(endpoint_eigenvalues[-3:].sum())
        assert endpoint_value <= c4 + 3e-12
        for t in np.linspace(0.0, 1.0, 41):
            x, y = r * t, r * (1.0 - t)
            weights = np.array([a, a, x, y, a, a])
            root = np.sqrt(weights)
            eigenvalues = np.linalg.eigvalsh(
                root[:, None] * template * root[None, :]
            )
            observed = float(eigenvalues[-3:].sum())
            assert observed <= c4 + 4e-12

            quotient = np.array(
                [
                    [3.0 * a, 2.0 * math.sqrt(a * x), 2.0 * math.sqrt(a * y)],
                    [2.0 * math.sqrt(a * x), x, 0.0],
                    [2.0 * math.sqrt(a * y), 0.0, y],
                ]
            )
            decomposed = np.sort(np.r_[np.linalg.eigvalsh(quotient), a, a, -a])
            assert np.max(np.abs(eigenvalues - decomposed)) < 3e-12
            assert np.linalg.eigvalsh(quotient + np.eye(3) / 4.0)[0] > -3e-13


def check_3dfe_imbalance_collar() -> None:
    assert 2449**2 < 6 * 1000**2
    assert 3163**2 > 10 * 1000**2
    gap_lower = (
        104 * Fraction(2449, 1000)
        - 80 * Fraction(3163, 1000)
        - 1
    ) / 390
    assert gap_lower > Fraction(7, 5000)
    assert 48 < 49

    template = np.asarray(matrix_from_mask(0x3DFE, float))
    rng = np.random.default_rng(20260907)
    for _ in range(100):
        weights = rng.random(6)
        weights /= weights.sum()
        root = np.sqrt(weights)
        projected_root = root.copy()
        q = []
        for i, j in ((0, 1), (2, 3), (4, 5)):
            p = (root[i] + root[j]) / math.sqrt(2.0)
            q.append((root[i] - root[j]) / math.sqrt(2.0))
            projected_root[i] = projected_root[j] = p / math.sqrt(2.0)
        observed = np.linalg.norm(
            root[:, None] * template * root[None, :]
            - projected_root[:, None] * template * projected_root[None, :],
            ord="fro",
        )
        assert observed <= 2.0 * np.linalg.norm(q) + 3e-15


def check_1bbc_prism_blocks() -> None:
    template = np.asarray(matrix_from_mask(0x1BBC, float))
    order = [0, 3, 4, 5, 2, 1]  # (1,4,5 | 6,3,2)
    permuted = template[np.ix_(order, order)]
    expected_template = np.block(
        [[np.ones((3, 3)), np.eye(3)], [np.eye(3), np.ones((3, 3))]]
    )
    assert np.max(np.abs(permuted - expected_template)) < 1e-12
    rng = np.random.default_rng(20260903)
    for _ in range(8):
        weights = rng.random(6)
        weights /= weights.sum()
        reordered = weights[order]
        a, b = reordered[:3], reordered[3:]
        root = np.sqrt(reordered)
        observed = root[:, None] * permuted * root[None, :]
        x, y = np.sqrt(a), np.sqrt(b)
        diagonal = np.diag(np.sqrt(a * b))
        expected = np.block(
            [[np.outer(x, x), diagonal], [diagonal, np.outer(y, y)]]
        )
        assert np.max(np.abs(observed - expected)) < 2e-12
    a = np.array([0.07, 0.19, 0.24])
    root = np.sqrt(np.r_[a, a])
    balanced = root[:, None] * expected_template * root[None, :]
    hadamard = np.block(
        [[np.eye(3) / np.sqrt(2), np.eye(3) / np.sqrt(2)],
         [np.eye(3) / np.sqrt(2), -np.eye(3) / np.sqrt(2)]]
    )
    D = np.diag(a)
    expected_balanced = np.block(
        [[D + np.outer(np.sqrt(a), np.sqrt(a)), np.zeros((3, 3))],
         [np.zeros((3, 3)), np.outer(np.sqrt(a), np.sqrt(a)) - D]]
    )
    assert np.max(np.abs(hadamard.T @ balanced @ hadamard - expected_balanced)) < 2e-12


def main() -> None:
    expected_complements = {
        0x03BC: "12 13 24 35 36 45 46 56",
        0x03BD: "13 24 35 36 45 46 56",
        0x03BE: "12 24 35 36 45 46 56",
        0x06DF: "23 26 36 45 46 56",
        0x077C: "12 13 25 36 45 46 56",
        0x077D: "13 25 36 45 46 56",
        0x07DE: "12 23 36 45 46 56",
        0x07FE: "12 36 45 46 56",
        0x0FDF: "23 45 46 56",
        0x1BBC: "12 13 24 35 46 56",
        0x1BBD: "13 24 35 46 56",
        0x1BFE: "12 35 46 56",
        0x3DFE: "12 34 56",
    }
    for mask in MASKS:
        actual = " ".join(complement_edges(mask))
        assert actual == expected_complements[mask], (f"{mask:04x}", actual)
        print(f"mask={mask:04x} complement=[{actual}] orbits={automorphism_orbits(mask)}")
    check_3dfe_decomposition()
    check_3dfe_symmetric_slice()
    check_3dfe_pair_balancing()
    check_3dfe_imbalance_collar()
    check_3dfe_two_balanced_one_split()
    check_1bbc_prism_blocks()
    print("3dfe and 1bbc structural/pair-balanced checks passed")
    print("Restricted-subclass verification only; no general sigma_3 bound is claimed.")


if __name__ == "__main__":
    main()
