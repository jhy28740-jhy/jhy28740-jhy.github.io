"""Independent checks for the one-parameter 1bbc symmetric slice.

The script checks the block-spectrum formula, isolates the only admissible
critical point of the unsquared derivative, and verifies the strict gap to c4
with rational square-root bounds.  It is a slice certificate only; it does not treat general 1bbc
weights or the other unresolved templates.
"""

from __future__ import annotations

import math
from fractions import Fraction

import numpy as np
import sympy as sp

from certify_six_block_low_inertia import matrix_from_mask


def slice_value(u: float) -> float:
    if u <= 1.0 / 6.0:
        return 1.0 - 0.5 * u + 0.5 * math.sqrt(4.0 * u - 15.0 * u * u)
    return (
        1.0
        + 2.0 * u
        + math.sqrt(33.0 * u * u - 10.0 * u + 1.0)
        + math.sqrt(4.0 * u - 15.0 * u * u)
    ) / 2.0


def sqrt_bounds(value: Fraction, denominator: int = 10**12) -> tuple[Fraction, Fraction]:
    """Return rational lower/upper bounds for sqrt(value).

    The bounds are obtained with integer square roots, so all comparisons made
    from them are exact.  The input is assumed to be nonnegative.
    """
    if value < 0:
        raise ValueError("sqrt_bounds received a negative rational")
    scaled = (value.numerator * denominator * denominator) // value.denominator
    lower_integer = math.isqrt(scaled)
    lower = Fraction(lower_integer, denominator)
    upper = Fraction(lower_integer + 1, denominator)
    while upper * upper < value:
        lower_integer += 1
        lower = Fraction(lower_integer, denominator)
        upper = Fraction(lower_integer + 1, denominator)
    while lower * lower > value:
        lower_integer -= 1
        lower = Fraction(lower_integer, denominator)
        upper = Fraction(lower_integer + 1, denominator)
    return lower, upper


def A_exact(u: Fraction) -> Fraction:
    return 33 * u * u - 10 * u + 1


def B_exact(u: Fraction) -> Fraction:
    return 4 * u - 15 * u * u


def derivative_sign_certificate(u: Fraction, positive: bool) -> bool:
    """Certify the sign of the high-branch derivative using rational bounds."""
    a = 66 * u - 10
    b = 30 * u - 4
    if not (a > 0 and b > 0):
        raise ValueError("the endpoint is outside the sign regime")
    la, ua = sqrt_bounds(A_exact(u))
    lb, ub = sqrt_bounds(B_exact(u))
    # The derivative has the sign of
    # E(u)=4*sqrt(A)*sqrt(B)+a*sqrt(B)-b*sqrt(A).
    if positive:
        lower_e = 4 * la * lb + a * lb - b * ua
        return lower_e > 0
    upper_e = 4 * ua * ub + a * ub - b * la
    return upper_e < 0


def strict_value_upper_bound(low: Fraction, high: Fraction, bound: Fraction) -> bool:
    """Use monotonicity on the isolating interval and exact sqrt bounds."""
    # On [low, high], A is increasing and B is decreasing.
    if not (66 * low - 10 > 0 and 4 - 30 * high < 0):
        raise ValueError("the isolating interval is not in the required regime")
    _, upper_a = sqrt_bounds(A_exact(high))
    _, upper_b = sqrt_bounds(B_exact(low))
    upper_value = (1 + 2 * high + upper_a + upper_b) / 2
    return upper_value < bound


def check_spectrum_formula() -> None:
    template = np.asarray(matrix_from_mask(0x1BBC, float))
    order = [0, 3, 4, 5, 2, 1]
    template = template[np.ix_(order, order)]
    for u in np.linspace(1.0e-5, 0.25, 101):
        weights = np.array([u, u, 0.5 - 2.0 * u] * 2)
        root = np.sqrt(weights)
        eigenvalues = np.linalg.eigvalsh(root[:, None] * template * root[None, :])
        observed = float(eigenvalues[-3:].sum())
        assert abs(observed - slice_value(float(u))) < 3.0e-12


def check_critical_point() -> None:
    u = sp.symbols("u")
    polynomial = (
        5553900 * u**7
        - 5402430 * u**6
        + 2152674 * u**5
        - 450337 * u**4
        + 52556 * u**3
        - 3340 * u**2
        + 102 * u
        - 1
    )
    assert sp.polys.polytools.count_roots(polynomial, sp.Rational(1, 6), sp.Rational(1, 4)) == 1
    low = sp.Rational(2467722, 10**7)
    high = sp.Rational(2467723, 10**7)
    assert sp.polys.polytools.count_roots(polynomial, low, high) == 1

    # The unsquared derivative keeps only this root.  The endpoint signs,
    # together with the Sturm count, certify the orientation of the maximum
    # on [1/6, 1/4].  The signs below use only rational arithmetic and integer
    # square-root bounds, not floating-point comparisons.
    assert derivative_sign_certificate(low, positive=True)
    assert derivative_sign_certificate(high, positive=False)
    # On the low branch, squaring the derivative equation leaves the only
    # admissible critical point u=1/10, where the value is 6/5.
    assert abs(slice_value(0.1) - 1.2) < 1.0e-14
    assert strict_value_upper_bound(low, high, Fraction(625257, 500000))
    sqrt6_lower, _ = sqrt_bounds(Fraction(6))
    assert Fraction(9, 15) + Fraction(4, 15) * sqrt6_lower > Fraction(1253197, 10**6)


def main() -> None:
    check_spectrum_formula()
    check_critical_point()
    print("1bbc symmetric triple slice checks passed")
    print("Slice certificate only; no general 1bbc or global sigma_3 bound is claimed.")


if __name__ == "__main__":
    main()
