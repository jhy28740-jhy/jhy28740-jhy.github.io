"""Exact diagonal-shifted dual certificates for the remaining six-block templates.

For a looped template T, a nonnegative diagonal shift Gamma and X positive
definite give the uniform bound

  sigma_3(W_{T,d}) <= max_i 1/2 + gamma_i/2
      + (X_ii + ((T-Gamma) X^-1 (T-Gamma))_ii)/4.

The floating-point stage searches for X and Gamma.  The final checker rounds
both to rational numbers and verifies positive definiteness, nonnegative
shifts, the exact inverse, and the strict rational target 1563/500.  Since
1563/500 < 4*c_star-2, a successful certificate proves sigma_3 < c_star.
"""

from __future__ import annotations

import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

from certify_six_block_low_inertia import (
    N,
    canonical_masks,
    edge_list,
    exact_inertia,
    fraction_text,
    inverse_fraction,
    matrix_from_mask,
)


TARGET = Fraction(1563, 500)
OUTPUT_PATH = Path(__file__).resolve().parent / "certificates" / "six_block_shifted_dual_certificates.json"


def unpack(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    lower = np.zeros((N, N))
    cursor = 0
    for i in range(N):
        for j in range(i + 1):
            value = parameters[cursor]
            lower[i, j] = math.exp(value) if i == j else value
            cursor += 1
    gamma = parameters[cursor : cursor + N]
    return lower @ lower.T, lower, gamma


def pack(matrix: np.ndarray, gamma: np.ndarray) -> np.ndarray:
    lower = np.linalg.cholesky(matrix)
    values = []
    for i in range(N):
        for j in range(i + 1):
            values.append(math.log(lower[i, i]) if i == j else lower[i, j])
    values.extend(gamma)
    return np.array(values)


def shifted_values(
    matrix: np.ndarray, gamma: np.ndarray, template: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    shifted = template - np.diag(gamma)
    inverse_columns = np.linalg.solve(matrix, shifted)
    values = 2.0 * gamma + np.diag(matrix) + np.sum(
        shifted * inverse_columns, axis=0
    )
    return values, inverse_columns


def smooth_objective(
    parameters: np.ndarray, template: np.ndarray, sharpness: float
) -> tuple[float, np.ndarray]:
    matrix, lower, gamma = unpack(parameters)
    values, inverse_columns = shifted_values(matrix, gamma, template)
    scaled = sharpness * values
    weights = np.exp(scaled - logsumexp(scaled))

    gradient_matrix = np.diag(weights)
    for i in range(N):
        vector = inverse_columns[:, i]
        gradient_matrix -= weights[i] * np.outer(vector, vector)
    gradient_lower = 2.0 * gradient_matrix @ lower
    gradient = []
    for i in range(N):
        for j in range(i + 1):
            entry = gradient_lower[i, j]
            gradient.append(entry * lower[i, i] if i == j else entry)
    gradient.extend(weights * (2.0 - 2.0 * np.diag(inverse_columns)))
    return float(logsumexp(scaled) / sharpness), np.array(gradient)


def numerical_certificate(template: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    starts = [
        (absolute + shift * np.eye(N), np.zeros(N)) for shift in (0.03, 0.15, 0.6)
    ]
    starts.extend((np.eye(N), value * np.ones(N)) for value in (0.0, 0.1, 0.3))
    cholesky_bounds = []
    for i in range(N):
        for j in range(i + 1):
            cholesky_bounds.append((-5.0, 5.0) if i == j else (-8.0, 8.0))
    bounds = cholesky_bounds + [(0.0, 4.0)] * N

    best_matrix = np.eye(N)
    best_gamma = np.zeros(N)
    best_value = math.inf
    for start_matrix, start_gamma in starts:
        parameters = pack(start_matrix, start_gamma)
        for sharpness in (20.0, 100.0, 500.0, 2000.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 2500, "ftol": 1e-14, "gtol": 1e-11},
            )
            parameters = result.x
        matrix, _, gamma = unpack(parameters)
        value = float(np.max(shifted_values(matrix, gamma, template)[0]))
        if value < best_value:
            best_matrix = matrix
            best_gamma = gamma
            best_value = value
    return best_matrix, best_gamma, best_value


def rational_certificate(
    numerical_matrix: np.ndarray,
    numerical_gamma: np.ndarray,
    template: list[list[Fraction]],
) -> tuple[list[list[Fraction]], list[Fraction], list[Fraction]]:
    for digits in (5, 6, 7, 8, 9, 10):
        scale = 10**digits
        base_matrix = [
            [
                Fraction(int(round(numerical_matrix[i, j] * scale)), scale)
                for j in range(N)
            ]
            for i in range(N)
        ]
        base_gamma = [
            Fraction(max(0, int(round(value * scale))), scale)
            for value in numerical_gamma
        ]
        for bump_units in (0, 1, 2, 5, 10, 20, 50, 100):
            matrix = [row[:] for row in base_matrix]
            for i in range(N):
                matrix[i][i] += Fraction(bump_units, scale)
            if exact_inertia(matrix) != (N, 0, 0):
                continue
            inverse = inverse_fraction(matrix)
            values = []
            for i in range(N):
                column = [
                    template[j][i] - (base_gamma[i] if j == i else 0)
                    for j in range(N)
                ]
                quadratic = sum(
                    column[j] * inverse[j][k] * column[k]
                    for j in range(N)
                    for k in range(N)
                )
                values.append(2 * base_gamma[i] + matrix[i][i] + quadratic)
            if max(values) < TARGET:
                return matrix, base_gamma, values
    raise RuntimeError("failed to rationalize a shifted dual certificate")


def target_masks() -> list[int]:
    masks = []
    for mask in canonical_masks():
        inertia = exact_inertia(matrix_from_mask(mask, Fraction))
        if inertia == (4, 2, 0):
            masks.append(mask)
    assert len(masks) == 48
    return masks


def write_certificates(records: list[dict], failures: list[dict]) -> str:
    payload = {
        "format_version": 1,
        "statement": "Certified full-rank inertia-(4,2) templates satisfy the diagonal-shifted dual bound below 1563/500 < 4*c_star-2.",
        "dimension": N,
        "full_rank_inertia_4_2_template_count": 48,
        "certificate_count": len(records),
        "unresolved_count": len(failures),
        "unresolved_templates": failures,
        "records": records,
    }
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("ascii")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_bytes(encoded)
    return hashlib.sha256(encoded).hexdigest().upper()


def main() -> None:
    # sqrt(5) > 559/250 and sqrt(35) > 2958/500 imply
    # (2*sqrt(5) + 4*sqrt(35))/9 > 1563/500 = TARGET.
    assert 559**2 < 5 * 250**2
    assert 2958**2 < 35 * 500**2
    assert Fraction(2 * 559, 250) + Fraction(4 * 2958, 500) > 9 * TARGET
    all_masks = canonical_masks()
    assert len(all_masks) == 156
    records = []
    failures = []
    for mask in target_masks():
        template_fraction = matrix_from_mask(mask, Fraction)
        template_float = np.array(matrix_from_mask(mask, float))
        matrix_float, gamma_float, numerical_value = numerical_certificate(template_float)
        try:
            matrix, gamma, values = rational_certificate(
                matrix_float, gamma_float, template_fraction
            )
        except RuntimeError:
            failures.append(
                {
                    "mask": f"{mask:04x}",
                    "edges": edge_list(mask).split(),
                    "numerical_shifted_dual": f"{numerical_value:.12f}",
                }
            )
            print(
                f"FAILED mask={mask:04x} edges=[{edge_list(mask)}] "
                f"numerical={numerical_value:.12f}"
            )
            continue
        maximum = max(values)
        assert maximum < TARGET
        records.append(
            {
                "mask": f"{mask:04x}",
                "edges": edge_list(mask).split(),
                "inertia": [4, 2, 0],
                "matrix": [[fraction_text(value) for value in row] for row in matrix],
                "gamma": [fraction_text(value) for value in gamma],
                "shifted_dual_values": [fraction_text(value) for value in values],
                "maximum_shifted_dual_value": fraction_text(maximum),
            }
        )
        print(
            f"mask={mask:04x} edges=[{edge_list(mask)}] "
            f"max_shifted_dual={float(maximum):.12f}"
        )

    assert len(records) == 35
    assert len(failures) == 13
    assert len(records) + len(failures) == 48
    digest = write_certificates(records, failures)
    if failures:
        print(
            f"PARTIAL EXACT CERTIFICATE: {len(records)} inertia-(4,2) templates "
            f"certified; {len(failures)} remain unresolved by this shifted-dual certificate."
        )
    else:
        print(
            "EXACT CERTIFICATE PASSED: all 48 full-rank inertia-(4,2) "
            "six-vertex templates have strict shifted dual certificates."
        )
    print(f"certificate_file={OUTPUT_PATH} sha256={digest}")


if __name__ == "__main__":
    main()
