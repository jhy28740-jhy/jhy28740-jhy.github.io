"""Explore smooth interior KKT points in the twelve open six-block cells.

This is numerical reconnaissance, not a completeness or interval proof.  It
solves the five independent simplex-gradient equations from deterministic
random starts, rejects third/fourth eigenvalue collisions, and clusters roots
under each template's exact automorphism group.  The output is intended to
prioritize later symbolic elimination and rigorous interval boxes.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

from certify_six_block_low_inertia import EDGES, matrix_from_mask


MASKS = (
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
)
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "remaining_stationary_search.txt"


def weights_from_coordinates(coordinates: np.ndarray) -> np.ndarray:
    logits = np.r_[coordinates, 0.0]
    logits = np.clip(logits - np.max(logits), -700.0, 0.0)
    weights = np.exp(logits)
    return weights / np.sum(weights)


def value_gradient(
    template: np.ndarray, weights: np.ndarray
) -> tuple[float, np.ndarray, np.ndarray]:
    root = np.sqrt(weights)
    quotient = root[:, None] * template * root[None, :]
    eigenvalues, eigenvectors = np.linalg.eigh(quotient)
    projector = eigenvectors[:, -3:] @ eigenvectors[:, -3:].T
    gradient = ((template * projector) @ root) / root
    return float(np.sum(eigenvalues[-3:])), gradient, eigenvalues


def residual(template: np.ndarray, coordinates: np.ndarray) -> np.ndarray:
    weights = weights_from_coordinates(coordinates)
    _, gradient, eigenvalues = value_gradient(template, weights)
    gap = eigenvalues[-3] - eigenvalues[-4]
    if not np.all(np.isfinite(gradient)) or gap <= 1e-9:
        return np.full(5, 1.0 + max(0.0, 1e-9 - gap) * 1e8)
    return gradient[:5] - gradient[5]


def automorphisms(template: np.ndarray) -> tuple[tuple[int, ...], ...]:
    result = []
    for permutation in itertools.permutations(range(6)):
        if np.array_equal(template, template[np.ix_(permutation, permutation)]):
            result.append(permutation)
    return tuple(result)


def canonical_weights(
    weights: np.ndarray, permutations: tuple[tuple[int, ...], ...]
) -> np.ndarray:
    candidates = [weights[np.asarray(permutation)] for permutation in permutations]
    return max(candidates, key=lambda vector: tuple(np.round(vector, 11)))


def numerical_hessian(
    template: np.ndarray, coordinates: np.ndarray, step: float = 2e-5
) -> np.ndarray:
    dimension = len(coordinates)
    hessian = np.zeros((dimension, dimension))

    def objective(point: np.ndarray) -> float:
        return value_gradient(template, weights_from_coordinates(point))[0]

    center = objective(coordinates)
    for i in range(dimension):
        ei = np.zeros(dimension)
        ei[i] = step
        hessian[i, i] = (
            objective(coordinates + ei)
            - 2.0 * center
            + objective(coordinates - ei)
        ) / step**2
        for j in range(i):
            ej = np.zeros(dimension)
            ej[j] = step
            mixed = (
                objective(coordinates + ei + ej)
                - objective(coordinates + ei - ej)
                - objective(coordinates - ei + ej)
                + objective(coordinates - ei - ej)
            ) / (4.0 * step**2)
            hessian[i, j] = hessian[j, i] = mixed
    return hessian


def edge_text(mask: int) -> str:
    return " ".join(
        f"{i + 1}{j + 1}" for bit, (i, j) in enumerate(EDGES) if mask & (1 << bit)
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--starts", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20260907)
    parser.add_argument("--scale", type=float, default=2.5)
    parser.add_argument("--max-nfev", type=int, default=2500)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    lines = [
        "Exploratory smooth-KKT search only; no completeness or interval proof.",
        f"templates={len(MASKS)} starts_per_template={args.starts} seed={args.seed}",
    ]
    for mask in MASKS:
        template = np.asarray(matrix_from_mask(mask, float))
        permutations = automorphisms(template)
        starts = [np.zeros(5)]
        starts.extend(
            args.scale * rng.normal(size=5) for _ in range(args.starts - 1)
        )
        records: list[tuple[np.ndarray, float, float, float, np.ndarray]] = []
        for start in starts:
            result = least_squares(
                lambda point: residual(template, point),
                start,
                method="trf",
                max_nfev=args.max_nfev,
                ftol=1e-12,
                xtol=1e-12,
                gtol=1e-12,
            )
            weights = weights_from_coordinates(result.x)
            value, gradient, eigenvalues = value_gradient(template, weights)
            kkt = float(np.ptp(gradient))
            gap = float(eigenvalues[-3] - eigenvalues[-4])
            if (
                result.success
                and kkt < 2e-7
                and gap > 1e-7
                and np.min(weights) > 1e-7
            ):
                canonical = canonical_weights(weights, permutations)
                if not any(
                    np.max(np.abs(canonical - old[0])) < 3e-6 for old in records
                ):
                    hessian = np.linalg.eigvalsh(
                        numerical_hessian(template, result.x)
                    )
                    records.append((canonical, value, kkt, gap, hessian))

        records.sort(key=lambda item: item[1], reverse=True)
        lines.append(
            f"mask={mask:04x} automorphisms={len(permutations)} "
            f"stationary_orbits={len(records)} edges=[{edge_text(mask)}]"
        )
        for index, (weights, value, kkt, gap, hessian) in enumerate(records, 1):
            negative = int(np.count_nonzero(hessian < -2e-5))
            zero = int(np.count_nonzero(np.abs(hessian) <= 2e-5))
            positive = int(np.count_nonzero(hessian > 2e-5))
            lines.extend(
                [
                    f"  orbit={index:02d} value={value:.12f} "
                    f"min_weight={np.min(weights):.3e} kkt={kkt:.3e} "
                    f"gap34={gap:.3e} hessian_inertia=({negative},{zero},{positive})",
                    "    weights="
                    + np.array2string(weights, precision=10, suppress_small=True),
                    "    hessian_eigenvalues="
                    + np.array2string(hessian, precision=8, suppress_small=True),
                ]
            )

    report = "\n".join(lines) + "\n"
    args.output.write_text(report, encoding="utf-8")
    print(report, end="")
    print(f"results_file={args.output.resolve()}")


if __name__ == "__main__":
    main()
