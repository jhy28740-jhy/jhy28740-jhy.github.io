"""Explore smooth interior KKT points for the ``3dfe`` six-block template.

This is a numerical reconnaissance tool, not an exhaustive certificate.  It
solves the five independent simplex-gradient equations from many deterministic
starts, rejects points without a positive third/fourth spectral gap, and
clusters the resulting stationary points modulo the automorphism group
``S_2 wr S_3``.  The output is intended to identify branches for subsequent
symbolic elimination or interval certification.
"""

from __future__ import annotations

import argparse
import itertools
import math

import numpy as np
from scipy.optimize import least_squares

from certify_six_block_low_inertia import matrix_from_mask


TEMPLATE = np.asarray(matrix_from_mask(0x3DFE, float))
PAIR_PERMUTATIONS = tuple(itertools.permutations(range(3)))


def weights_from_coordinates(coordinates: np.ndarray) -> np.ndarray:
    """Use a five-dimensional log-ratio chart of the open simplex."""

    logits = np.r_[coordinates, 0.0]
    logits = np.clip(logits - np.max(logits), -700.0, 0.0)
    weights = np.exp(logits)
    return weights / np.sum(weights)


def value_gradient(weights: np.ndarray) -> tuple[float, np.ndarray, np.ndarray]:
    root = np.sqrt(weights)
    quotient = root[:, None] * TEMPLATE * root[None, :]
    eigenvalues, eigenvectors = np.linalg.eigh(quotient)
    projector = eigenvectors[:, -3:] @ eigenvectors[:, -3:].T
    gradient = ((TEMPLATE * projector) @ root) / root
    return float(np.sum(eigenvalues[-3:])), gradient, eigenvalues


def residual(coordinates: np.ndarray) -> np.ndarray:
    weights = weights_from_coordinates(coordinates)
    _, gradient, eigenvalues = value_gradient(weights)
    gap = eigenvalues[-3] - eigenvalues[-4]
    if not np.all(np.isfinite(gradient)) or gap <= 1e-9:
        # A smooth KKT equation is invalid at a third/fourth eigenvalue tie.
        return np.full(5, 1.0 + max(0.0, 1e-9 - gap) * 1e8)
    return gradient[:5] - gradient[5]


def canonical_weights(weights: np.ndarray) -> np.ndarray:
    """Canonicalize under swaps inside pairs and permutations of pairs."""

    pairs = [tuple(sorted(weights[2 * k : 2 * k + 2], reverse=True)) for k in range(3)]
    candidates = []
    for permutation in PAIR_PERMUTATIONS:
        candidates.append(np.array([x for k in permutation for x in pairs[k]]))
    return max(candidates, key=lambda vector: tuple(np.round(vector, 12)))


def numerical_hessian(coordinates: np.ndarray, step: float = 2e-5) -> np.ndarray:
    """Central-difference Hessian of the objective in log-ratio coordinates."""

    dimension = len(coordinates)
    hessian = np.zeros((dimension, dimension))

    def objective(point: np.ndarray) -> float:
        return value_gradient(weights_from_coordinates(point))[0]

    center = objective(coordinates)
    for i in range(dimension):
        ei = np.zeros(dimension)
        ei[i] = step
        hessian[i, i] = (objective(coordinates + ei) - 2 * center + objective(coordinates - ei)) / step**2
        for j in range(i):
            ej = np.zeros(dimension)
            ej[j] = step
            mixed = (
                objective(coordinates + ei + ej)
                - objective(coordinates + ei - ej)
                - objective(coordinates - ei + ej)
                + objective(coordinates - ei - ej)
            ) / (4 * step**2)
            hessian[i, j] = hessian[j, i] = mixed
    return hessian


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--starts", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20260907)
    parser.add_argument("--scale", type=float, default=2.5)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    starts = [np.zeros(5)]
    starts.extend(args.scale * rng.normal(size=5) for _ in range(args.starts - 1))
    records: list[tuple[np.ndarray, float, float, float, np.ndarray]] = []
    for start in starts:
        result = least_squares(
            residual,
            start,
            method="trf",
            max_nfev=3000,
            ftol=1e-13,
            xtol=1e-13,
            gtol=1e-13,
        )
        weights = weights_from_coordinates(result.x)
        value, gradient, eigenvalues = value_gradient(weights)
        kkt = float(np.ptp(gradient))
        gap = float(eigenvalues[-3] - eigenvalues[-4])
        if (
            result.success
            and kkt < 2e-7
            and gap > 1e-7
            and np.min(weights) > 1e-7
        ):
            canonical = canonical_weights(weights)
            if not any(np.max(np.abs(canonical - old[0])) < 2e-6 for old in records):
                hessian_eigenvalues = np.linalg.eigvalsh(numerical_hessian(result.x))
                records.append((canonical, value, kkt, gap, hessian_eigenvalues))

    records.sort(key=lambda item: item[1], reverse=True)
    print("Exploratory smooth-KKT search only; no completeness proof.")
    print(f"starts={args.starts} seed={args.seed} stationary_orbits={len(records)}")
    for index, (weights, value, kkt, gap, hessian_eigenvalues) in enumerate(records, 1):
        pair_masses = weights.reshape(3, 2).sum(axis=1)
        pair_products = np.prod(weights.reshape(3, 2), axis=1)
        print(
            f"orbit={index:02d} value={value:.12f} kkt={kkt:.3e} gap34={gap:.3e}\n"
            f"  weights={np.array2string(weights, precision=10, suppress_small=True)}\n"
            f"  pair_masses={np.array2string(pair_masses, precision=10)} "
            f"pair_products={np.array2string(pair_products, precision=10)}\n"
            f"  hessian_eigenvalues={np.array2string(hessian_eigenvalues, precision=8)}"
        )


if __name__ == "__main__":
    main()
