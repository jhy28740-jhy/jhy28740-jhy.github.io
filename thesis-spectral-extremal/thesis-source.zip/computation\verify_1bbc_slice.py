"""Independent checks for the one-parameter 1bbc symmetric slice.

The script checks the block-spectrum formula, isolates the only admissible
critical point of the unsquared derivative, and verifies the strict numerical
gap to c4.  It is a slice certificate only; it does not treat general 1bbc
weights or the other unresolved templates.
"""

from __future__ import annotations

import math

import numpy as np
import sympy as sp

from certify_six_block_low_inertia import matrix_from_mask


def slice_value(u: float) -> float:
    if u <= 1.0 / 6.0:
        return 1.0 - 0.5 * u + 0.5 * math.sqrt(4.0 * u - 15.0 * u * u)
    return (
        1.0
        + 2.0 * u
        + math.sqrt(33.0 * u * u - 10.0 * u + 1.0)
        + math.sqrt(4.0 * u - 15.0 * u * u)
    ) / 2.0


def slice_derivative(u: float) -> float:
    a = 33.0 * u * u - 10.0 * u + 1.0
    b = 4.0 * u - 15.0 * u * u
    return 1.0 + (66.0 * u - 10.0) / (4.0 * math.sqrt(a)) + (
        4.0 - 30.0 * u
    ) / (4.0 * math.sqrt(b))


def check_spectrum_formula() -> None:
    template = np.asarray(matrix_from_mask(0x1BBC, float))
    order = [0, 3, 4, 5, 2, 1]
    template = template[np.ix_(order, order)]
    for u in np.linspace(1.0e-5, 0.25, 101):
        weights = np.array([u, u, 0.5 - 2.0 * u] * 2)
        root = np.sqrt(weights)
        eigenvalues = np.linalg.eigvalsh(root[:, None] * template * root[None, :])
        observed = float(eigenvalues[-3:].sum())
        assert abs(observed - slice_value(float(u))) < 3.0e-12


def check_critical_point() -> None:
    u = sp.symbols("u")
    polynomial = (
        5553900 * u**7
        - 5402430 * u**6
        + 2152674 * u**5
        - 450337 * u**4
        + 52556 * u**3
        - 3340 * u**2
        + 102 * u
        - 1
    )
    assert sp.polys.polytools.count_roots(polynomial, sp.Rational(1, 6), sp.Rational(1, 4)) == 1
    low = sp.Rational(2467722, 10**7)
    high = sp.Rational(2467723, 10**7)
    assert sp.polys.polytools.count_roots(polynomial, low, high) == 1

    # The unsquared derivative keeps only this root.  The endpoint signs,
    # together with the Sturm count, certify the orientation of the maximum
    # on [1/6, 1/4].
    assert slice_derivative(float(low)) > 0.0
    assert slice_derivative(float(high)) < 0.0
    # On the low branch, squaring the derivative equation leaves the only
    # admissible critical point u=1/10, where the value is 6/5.
    assert abs(slice_value(0.1) - 1.2) < 1.0e-14
    c4 = (9.0 + 4.0 * math.sqrt(6.0)) / 15.0
    assert slice_value(float(low)) < 1.250514
    assert slice_value(float(high)) < 1.250514
    assert slice_value(float(low)) < c4


def main() -> None:
    check_spectrum_formula()
    check_critical_point()
    print("1bbc symmetric triple slice checks passed")
    print("Slice certificate only; no general 1bbc or global sigma_3 bound is claimed.")


if __name__ == "__main__":
    main()
