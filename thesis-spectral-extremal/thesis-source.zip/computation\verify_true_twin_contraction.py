"""Exact audit for the true-twin contraction lemma.

The script has two purposes:

1. verify that the thirteen unresolved six-vertex masks contain no adjacent
   (true) twin pair; and
2. verify, on an exact rational test instance, that contracting a true-twin
   pair preserves the characteristic polynomial up to one zero factor.

This is an algebraic consistency check, not a certificate for the unresolved
templates.  In particular, non-adjacent twins are intentionally not contracted.
"""

from __future__ import annotations

import itertools
from fractions import Fraction

import sympy as sp

from certify_six_block_low_inertia import EDGES, matrix_from_mask


UNRESOLVED = [
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
    0x3DFE,
]


def simple_matrix(mask: int) -> list[list[int]]:
    matrix = [[int(i != j) * 0 for j in range(6)] for i in range(6)]
    for bit, (i, j) in enumerate(EDGES):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = 1
    return matrix


def twin_pairs(mask: int) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
    graph = simple_matrix(mask)
    true: list[tuple[int, int]] = []
    false: list[tuple[int, int]] = []
    for i, j in itertools.combinations(range(6), 2):
        outside = [k for k in range(6) if k not in (i, j)]
        if all(graph[i][k] == graph[j][k] for k in outside):
            (true if graph[i][j] else false).append((i + 1, j + 1))
    return true, false


def contraction_matrix(
    mask: int, pair: tuple[int, int], weights: list[Fraction]
) -> tuple[sp.Matrix, sp.Matrix]:
    """Return exact B and its true-twin contraction for a test mask."""
    i, j = pair
    template = matrix_from_mask(mask, Fraction)
    b = sp.Matrix(
        [
            [
                sp.sqrt(weights[r] * weights[c]) * template[r][c]
                for c in range(len(weights))
            ]
            for r in range(len(weights))
        ]
    )
    keep = [k for k in range(len(weights)) if k != j]
    merged_weights = [weights[k] for k in keep]
    merged_weights[keep.index(i)] = weights[i] + weights[j]
    merged_template = [
        [template[r][c] for c in keep]
        for r in keep
    ]
    contracted = sp.Matrix(
        [
            [
                sp.sqrt(merged_weights[r] * merged_weights[c])
                * merged_template[r][c]
                for c in range(len(keep))
            ]
            for r in range(len(keep))
        ]
    )
    return b, contracted


def exact_test() -> None:
    # Vertices 0 and 1 are adjacent true twins; the other four vertices form
    # a small asymmetric test environment.
    mask = 0
    for edge in ((0, 1), (0, 2), (1, 2), (0, 3), (1, 3), (2, 4), (3, 5)):
        mask |= 1 << EDGES.index(tuple(sorted(edge)))
    true, false = twin_pairs(mask)
    assert (1, 2) in true
    assert not false
    b, contracted = contraction_matrix(mask, (0, 1), [Fraction(1), Fraction(2), Fraction(3), Fraction(5), Fraction(7), Fraction(11)])
    lam = sp.symbols("lambda")
    char_b = sp.factor(b.charpoly(lam).as_expr())
    char_contracted = sp.factor(contracted.charpoly(lam).as_expr())
    assert sp.simplify(char_b - lam * char_contracted) == 0


def main() -> None:
    for mask in UNRESOLVED:
        true, false = twin_pairs(mask)
        assert not true, f"unexpected true twins in {mask:04x}: {true}"
        print(f"mask={mask:04x} true_twins=[] false_twins={false}")
    exact_test()
    print("exact true-twin contraction test passed")


if __name__ == "__main__":
    main()
