"""High-precision independent audit of the Chapter 5 Hessian formulas."""

from __future__ import annotations

import mpmath as mp


mp.mp.dps = 100
SQRT5 = mp.sqrt(5)
SQRT7 = mp.sqrt(7)
SQRT35 = mp.sqrt(35)
ALPHA = (91 - 25 * SQRT7) / 126
BETA = (1 - ALPHA) / 5
MEASURES = [ALPHA] + [BETA] * 5

TEMPLATE = mp.matrix(6)
for i in range(6):
    TEMPLATE[i, i] = 1
for i in range(1, 6):
    TEMPLATE[0, i] = TEMPLATE[i, 0] = 1
    j = 1 + (i % 5)
    TEMPLATE[i, j] = TEMPLATE[j, i] = 1


def spectral_sum(measures: list[mp.mpf]) -> mp.mpf:
    roots = [mp.sqrt(value) for value in measures]
    matrix = mp.matrix(
        [
            [roots[i] * TEMPLATE[i, j] * roots[j] for j in range(6)]
            for i in range(6)
        ]
    )
    eigenvalues, _ = mp.eigsy(matrix)
    return sum(eigenvalues[i] for i in range(3, 6))


def second_difference(direction: list[mp.mpf], step: mp.mpf) -> mp.mpf:
    plus = [MEASURES[i] + step * direction[i] for i in range(6)]
    minus = [MEASURES[i] - step * direction[i] for i in range(6)]
    return (
        spectral_sum(plus) - 2 * spectral_sum(MEASURES) + spectral_sum(minus)
    ) / step**2


def main() -> None:
    u0 = [mp.sqrt(mp.mpf(5) / 6)] + [-1 / mp.sqrt(30)] * 5
    cosine_1 = [
        1,
        (SQRT5 - 1) / 4,
        -(SQRT5 + 1) / 4,
        -(SQRT5 + 1) / 4,
        (SQRT5 - 1) / 4,
    ]
    cosine_2 = [
        1,
        -(SQRT5 + 1) / 4,
        (SQRT5 - 1) / 4,
        (SQRT5 - 1) / 4,
        -(SQRT5 + 1) / 4,
    ]
    u1 = [mp.mpf(0)] + [mp.sqrt(mp.mpf(2) / 5) * x for x in cosine_1]
    u2 = [mp.mpf(0)] + [mp.sqrt(mp.mpf(2) / 5) * x for x in cosine_2]

    expected = [
        -14 * SQRT35 / 75,
        -mp.mpf(287) / 95
        + (-311 * SQRT35 + 455 * SQRT5 + 595 * SQRT7) / 475,
        mp.mpf(287) / 95
        + (-311 * SQRT35 - 595 * SQRT7 + 455 * SQRT5) / 475,
    ]
    step = mp.mpf("1e-20")
    for index, (direction, claimed) in enumerate(zip((u0, u1, u2), expected)):
        error = abs(second_difference(direction, step) - claimed)
        if error > mp.mpf("1e-30"):
            raise AssertionError(f"theta_{index} audit failed: error={error}")
        print(f"theta_{index}: error = {mp.nstr(error, 8)}")


if __name__ == "__main__":
    main()
