# 毕业论文增强版工程

论文题目：**图的前三大邻接特征值和的变分结构及谱极值**。

## 文件结构

- `main.tex`：通用 `ctexrep` 入口、摘要及排版设置；学校模板确定后主要替换这里。
- `chapters/`：八章正文，每章均可独立修订。
- `computation/`：非平衡 clique-`C5` blow-up 的可复现实验代码、Hessian 精确符号证书及高精度审计。
- `figures/`：由 `computation/generate_figures_and_evidence.py` 生成的结构、目标函数和有限阶收敛图。
- `references.tex`：当前已核实的参考文献。
- `文本原创性与AI风格自检报告.md`：本地表层重合与模板化表达筛查；不等同于学校正式查重或 AI 检测百分比。
- `build/`：编译产物。

## 编译

工程内已放置经过 MD5 校验的 Tectonic 0.15.0 Windows 可执行文件。在工程目录运行：

```powershell
./tools/tectonic/tectonic.exe main.tex --outdir build
```

或使用完整 TeX Live：

```powershell
xelatex -output-directory=build main.tex
xelatex -output-directory=build main.tex
```

至少编译两遍才能稳定生成目录和交叉引用。当前版本故意不绑定任何学校的
封面与页眉规范；拿到学校模板后，保留 `chapters/` 内容并调整 `main.tex`
即可。

本次已验证的 PDF 位于 `build/main.pdf`。除原有六分块模型结果外，
第 4 章给出全局极限存在定理，并把全局 graphon 极值严格等价约化为三维
各向同性随机向量的正内积矩问题和有限原子 Stiefel--Perron 问题，建立光滑
不可约有限驻点的矩阵 KKT 方程，同时写出达到
候选值的六原子分布。正文还精确求解至多四原子的情形，证明任意全局极值分布
必有自支撑椭球，并用严格区间算术证明候选 zonotope 的椭球包含、交叉能量
上界、唯一等号分布及定量交叉近等号刚性；还给出自能量缺口的精确极化分解，并以
显式各向同性分布排除全局条件负性的直接证明路线。该证书不控制任意分布的自能量。第 5 章
给出平衡环族完整谱与环长度选择定理，并新增
非平衡六分块的迹范数表示、全局凹性、边界排除、内部 KKT 完备性、类内唯一
全局极大点、径向平衡化不等式及全局二次稳定性。这些结论严格限定在固定的
clique-`C5` 六分块拓扑内，没有被外推为全体 graphon 的全局最优性。第 8 章
明确提出各向同性匹配不等式及等号刚性猜想，并严格证明“该猜想若成立，则全局
常数等于候选值；等号若唯一，则极值 graphon 必为六分块且满足定性 cut 稳定性”
的条件约化。实验结果文件为
`computation/enumeration_results.csv`，新增数值证据位于
`computation/numerical_evidence.txt`。

当前没有被解决的核心是：全体各向同性分布的匹配自能量上界、自能量等号分布
在正交变换下的唯一性，以及无条件的六分块 cut 稳定性。第三项的定性版本会由
前两项和 graphon 紧致性自动推出；显式稳定速率仍需要定量近等号刚性。

当前已经严格补充：至多四原子各向同性分布的上界 $5/4$ 及等号投影刻画；
任意全局极值分布的自支撑椭球和二阶条件负性；候选六原子分布的交叉能量
唯一等号与定量交叉近等号刚性；自能量缺口的精确极化恒等式，以及全局条件负性
不成立的显式反例。这些结果均不等同于全局自能量上界。

## 结论等级

- `theorem/proposition/lemma/corollary`：正文已给出证明的结论。
- `conditional proposition` 或正文明确列出附加假设：目前只在这些假设下成立。
- `conjecture`：计算或结构证据支持，但未给出完整证明。

不得把第 5 章的六分块受限最优值改写成全体 graphon 的全局最优值。
