# 毕业论文增强版工程

论文题目：**图的前三大邻接特征值和的变分结构及谱极值**。

## 文件结构

- `main.tex`：通用 `ctexrep` 入口、摘要及排版设置；学校模板确定后主要替换这里。
- `chapters/`：八章正文，每章均可独立修订。
- `computation/`：非平衡 clique-`C5` blow-up 的可复现实验代码、Hessian 精确符号证书、严格区间证书及高精度审计。
- `computation/verify_true_twin_contraction.py`：真孪生合并引理的精确代数核验，以及十三个统一对偶残余六阶掩码的孪生对审计。
- `computation/audit_six_remaining_templates.py`：十三个统一对偶残余六阶模板的固定种子 KKT
  数值审计；输出仅为探索证据，不构成区间或全局证明。
- computation/verify_unresolved_structure.py：逐项核验十三个统一对偶残余类的补图边集、自同构轨道，
  以及 3dfe 模板的秩一--匹配分块恒等式和 secular 方程；该脚本只验证结构，
  不声称完成剩余模板的全局上界。
- `computation/verify_1bbc_slice.py`：核验 1bbc 对称三元一参数切片的分段谱公式、
  高段临界点的 Sturm 隔离，以及用有理平方根界证明的严格 $c_4$ 间隙；该脚本
  只验证受限切片。
- `computation/verify_3dfe_global_bound.py`：用精确有理三角 Bernstein 系数核验
  `3dfe` 一般六维严格界 `Psi_3dfe < 32/25 < c_*`；这是定理级证书，不是浮点搜索。
- `computation/explore_3dfe_stationary.py`：`3dfe` 光滑内点 KKT 的数值侦察；输出
  仅用于寻找后续区间盒，不构成驻点完备性证明。
- `computation/explore_remaining_stationary.py`：对十二个未决模板求解光滑内点
  KKT 方程并按自同构轨道聚类；这只是数值侦察，未证明驻点完备性。
- `computation/remaining_stationary_search.txt`：上述光滑 KKT 数值侦察的完整固定种子
  输出；轨道计数和 Hessian 惯性仅用于设计后续区间盒，不能当作完备性定理。
- `computation/certify_boundary_dual_collars.py`：搜索十二个未决模板的逐面
  shifted-dual 证书，并将成功的 68 个候选有理化。
- `computation/verify_boundary_dual_collars.py`：不运行浮点优化，独立精确验证
  68 份有理证书的正定性、逆矩阵与全部截断单纯形顶点。
- `computation/certify_exception_boundary_collars.py`：为四个原例外面生成二分证书：
  20 份扩展到 $1/60$ 的辅助坐标领证书，以及四份控制总正谱和的零移位证书。
- `computation/verify_exception_boundary_collars.py`：仅使用精确分数运算，核对
  两组证书、模板惯性、诱导 `07e=I+A(K_{2,3})` 结构及全部截断单纯形顶点。
- `computation/kkt_audit_results.txt`：种子 `20260907`、每类 300 次重启和 3500
  步迭代的可复核摘要，包含最小块测度、第三谱隙和简单谱 KKT 残差；结果仍是
  数值线索，不构成内点完备性证书。
- `computation/certificates/`：五阶、六阶低惯性和六阶对角移位对偶的逐模板有理证书，可直接核对矩阵、逆矩阵与严格界。
- `figures/`：由 `computation/generate_figures_and_evidence.py` 生成的结构、目标函数和有限阶收敛图。
- `references.tex`：当前已核实的参考文献。
- `文本原创性与AI风格自检报告.md`：本地表层重合与模板化表达筛查；不等同于学校正式查重或 AI 检测百分比。
- `build/`：编译产物。

## 证书校验

当前正文对应的逐模板证书 SHA256 如下（Windows PowerShell 可用
`Get-FileHash -Algorithm SHA256 <文件>` 复核）：

| 文件 | SHA256 |
| --- | --- |
| `computation/certificates/five_block_dual_certificates.json` | `8F3A93B0E3DA4A4A932ED05B0FCDCF11361DA413709418569F83572334E6E98C` |
| `computation/certificates/six_block_low_inertia_dual_certificates.json` | `5EA61DEF3E9DBFE2FDB5773396C38113ECF6238994393B1AE5AE81F4A6575539` |
| `computation/certificates/six_block_shifted_dual_certificates.json` | `2ED71CC3CF6147EA50AE1C26BF90086C62751F0BF9BAEC759BBC46F7044CA5E5` |
| `computation/certificates/six_block_boundary_dual_collar_certificates.json` | `2D9577E2908974208FED54C2F35CEBC76B4BD940D5DAFB76B53FEEFC26BC873C` |
| `computation/certificates/six_block_exception_boundary_collar_certificates.json` | `F8C75D4106E3A32CC6B460EBE2B17D054CEF937B369C2F1D40D7714178659400` |

六原子 156 个同构类中，统一证书直接闭合 143 类；剩余 13 类的固定掩码为
`03bc, 03bd, 03be, 06df, 077c, 077d, 07de, 07fe, 0fdf, 1bbc, 1bbd, 1bfe, 3dfe`。
其中 `3dfe` 已由专用秩一--Perron--Bernstein 证书严格排除；当前真正未解的
六原子类为其余 12 类以及 `N=7,\ldots,48`，不能按已排除处理。
对这 12 类的 72 个坐标面，精确有理证书已完整排除全部
$d_k\leq1/100$ 的边界领。前 68 个由逐面 shifted-dual 证书直接处理。原四个
例外面 `(03be,4), (07de,3), (07fe,3), (0fdf,1)` 删去所列坐标后均为
`07e=I+A(K_{2,3})`；新的二分证明先用 20 份辅助证书处理另一坐标
$d_i\leq1/60$ 的情形，再在其余五坐标均大于 $1/60$ 时，从总正谱上界中扣除
严格大于 $1/60$ 的第四正特征值。边界领完整闭合仍不得宣称已排除这 12 个模板
的内点。

新增的真孪生核验脚本确认，13 个统一对偶残余掩码均没有相邻真孪生对；`06df` 和
`3dfe` 中出现的是非相邻假孪生。真孪生可按正文引理无损合并，假孪生则会
引入额外正特征值或半密度合并块，因此不能据此进行模板合并；当前未解类数由
`3dfe` 的独立证书降为 12 类。

当前 `build/main.pdf`（134 页）SHA256 为
`F60D02FD78D7D889C05AA0C9CFFC4ABEF79521985A23BDA22C144C08C23B327C`。
本轮新增 `3dfe` 一般六维严格界 `Psi_3dfe < 32/25 < c_*` 的纯有理 Bernstein
证书，并保留其双平衡对--单分裂对的更尖锐 $c_4$ 上界与平方根不平衡邻域排除。
对实际未解十二模板的全部 $72$ 个坐标面，现均有精确证书把边界领加强到
$d_k\leq1/100$；四个原例外面使用上述“辅助领或第四正特征值扣除”二分。

## 编译

工程内已放置经过 MD5 校验的 Tectonic 0.15.0 Windows 可执行文件；主稿使用
`fontset=windows` 以嵌入 SimSun、SimHei 和 KaiTi 等 CJK 字体。在工程目录运行：

```powershell
./tools/tectonic/tectonic.exe main.tex --outdir build
```

或使用完整 TeX Live：

```powershell
xelatex -output-directory=build main.tex
xelatex -output-directory=build main.tex
```

至少编译两遍才能稳定生成目录和交叉引用。当前版本故意不绑定任何学校的
封面与页眉规范；拿到学校模板后，保留 `chapters/` 内容并调整 `main.tex`
即可。

本次已验证的 PDF 位于 `build/main.pdf`。除原有六分块模型结果外，
第 4 章给出全局极限存在定理，并把全局 graphon 极值严格等价约化为三维
各向同性随机向量的正内积矩问题和有限原子 Stiefel--Perron 问题；团块克隆与
Carathéodory 压缩进一步证明存在至多 $48$ 原子的全局极大元，从而全局常数等于
单个紧的 $48$ 阶 Stiefel 最大值。正文建立光滑不可约有限驻点的矩阵 KKT 方程，同时写出达到
候选值的六原子分布。正文还精确求解至多四原子的情形，并以正惯性筛选、
矩阵保真度对偶式和完整有理证书证明全部五原子情形的精确最大值为
$c_4=(9+4\sqrt6)/15<c_*$，由 $K_1\vee C_4$ 模板达到。随后以谱矩估计和
对角移位有理保真度证书证明六阶 $156$ 个符号同构类中的 $143$ 类满足候选上界；
再以 `3dfe` 的专用秩一--Perron--Bernstein 证书排除一个模板，故六原子潜在反例
严格缩减为 $12$ 个正文显式列出的完整惯性 $(4,2,0)$ 模板；这不是对六原子
问题的全部闭合。另以有向舍入区间算术证明候选投影在固定六原子完整九维
Grassmann 方向上为非退化严格局部极大点；
同时证明任意全局极值分布
必有自支撑椭球，并用严格区间算术证明候选 zonotope 的椭球包含、交叉能量
上界、唯一等号分布及定量交叉近等号刚性；同时完全求解支撑在候选六条接触
正射线上的各向同性分布，得到类内自能量上界、唯一等号与定量耦合稳定性；
并进一步证明：只要任意支撑数的各向同性分布的内积正负关系可按候选
clique-`C5` 六类模板分拆，就有匹配自能量上界、正交意义下的唯一等号和
符号 graphon 的定量 cut 稳定性。还给出自能量缺口的精确极化分解，并以
显式各向同性分布排除全局条件负性的直接证明路线；并证明固定方向的候选交叉
亏损不能参数化自能量稳定性，进而定义对 $O(3)$ 轨道最优对齐的交叉亏损，
建立对应的精确极化恒等式和轨道化交叉刚性。轨道化二次项的全局桥接不等式
仍未证明，因此该证书不控制任意分布的自能量。第 5 章
给出平衡环族完整谱与环长度选择定理，并新增
非平衡六分块的迹范数表示、全局凹性、边界排除、内部 KKT 完备性、类内唯一
全局极大点、径向平衡化不等式及全局二次稳定性。这些结论严格限定在固定的
clique-`C5` 六分块拓扑内，没有被外推为全体 graphon 的全局最优性。第 8 章
明确提出各向同性匹配不等式及等号刚性猜想，并严格证明“该猜想若成立，则全局
常数等于候选值；等号若唯一，则极值 graphon 必为六分块且满足定性 cut 稳定性”
的条件约化。实验结果文件为
`computation/enumeration_results.csv`，新增数值证据位于
`computation/numerical_evidence.txt`。

当前没有被解决的核心是：全体各向同性分布的匹配自能量上界（等价地，$48$ 阶
Stiefel 紧问题的严格全局上界）、全体各向同性分布的自能量等号分布
在正交变换下的唯一性，以及无条件的六分块 cut 稳定性。第三项的定性版本会由
前两项和 graphon 紧致性自动推出；显式稳定速率仍需要定量近等号刚性。

需要特别区分的是：第五章的六类符号模板定理已经给出一个严格更大的受限类，
但它以符号分拆存在为假设；“任意极值或近极值分布都具有该分拆”本身仍未证明。

当前已经严格补充：至多四原子各向同性分布的上界 $5/4$ 及等号投影刻画；
全部五原子情形的精确最大值 $c_4=(9+4\sqrt6)/15<c_*$ 及其完整有理对偶证书；
六阶全部 $156$ 个模板中统一证书 $143$ 类的严格处理（其中 $142$ 类严格低于候选值），
以及 `3dfe` 专用证书；当前剩余清单含 $12$ 个同构类；
候组六原子投影在完整九维 Grassmann 图表中的非退化严格局部极大性；
任意全局极值分布的自支撑椭球和二阶条件负性；候选六原子分布的交叉能量
唯一等号与定量交叉近等号刚性；候选六条接触正射线类内的自能量上界、唯一
等号与定量稳定性；候选六类符号模板下的匹配上界、等号刚性与符号 graphon
定量 cut 稳定性；自能量缺口的精确极化恒等式，以及全局条件负性
不成立的显式反例；固定方向交叉亏损的旋转障碍、正交轨道化亏损的精确恒等式与
定量交叉刚性；粗渐近上界 $(1+\sqrt3)/2$ 的严格不可达性；以及高能量分布
的重心定位
$\|\mathbb EX\|_2^2\geq2c_*-\sqrt3\approx0.831086$。
这些结果均不等同于全局自能量匹配上界；严格不可达性目前也没有给出显式正间隙。

## 结论等级

- `theorem/proposition/lemma/corollary`：正文已给出证明的结论。
- `conditional proposition` 或正文明确列出附加假设：目前只在这些假设下成立。
- `conjecture`：计算或结构证据支持，但未给出完整证明。

不得把第 5 章的六分块受限最优值改写成全体 graphon 的全局最优值。

本次增补还给出一般六模板的 Ky Fan 内点 KKT 必要条件，使用活动最大化矩阵集合覆盖第三
特征值重根；并把十三个统一对偶残余模板按支持面、谱隙分支和重根碰撞分层，明确严格
区间证书必须覆盖的三类输出。完整边界领排除已由精确分数证书通过，因而十二个
未决模板中任何达到或超过候选值的点都位于 \(d_i>1/100\) 的内点区域。统一对偶残余十三类的数值审计
最高观测值约为 \(1.25309<c_4\)；其中 `3dfe` 已有独立定理证书，其余十二类仍因
最优运行常把某个块测度推向零而不能据此排除未发现的内点驻点，完整区间覆盖尚未完成。
