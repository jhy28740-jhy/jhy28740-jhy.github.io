# 编译说明

本目录是《图的前三大邻接特征值和：图极限方法与有限维约化》的独立重写版源码。

## 编译

需要 XeLaTeX、CTeX 宏包以及 Windows 中文字体。连续编译两次以更新目录和交叉引用：

```powershell
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

若系统中同时安装了多个 MiKTeX 版本，应选择当前版本的 `xelatex.exe`，避免旧版
配置中的内存参数与新格式文件冲突。

## 目录

- `main.tex`：版式、摘要、目录和章节入口；
- `chapters/`：七章正文及一个技术附录；
- `references.tex`：参考文献。

当前正文的严格结论与开放问题已经分层书写。候选等式
\(\mathfrak c_3=c_*\)、全局等号唯一性和无条件 cut 稳定性仍未证明，修改模板时
不应删除这些范围声明。
