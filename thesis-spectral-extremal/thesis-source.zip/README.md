# 毕业论文增强版工程

论文题目：**图的前三大邻接特征值和的变分结构及谱极值**。

## 文件结构

- `main.tex`：通用 `ctexrep` 入口、摘要及排版设置；学校模板确定后主要替换这里。
- `chapters/`：八章正文，每章均可独立修订。
- `computation/`：非平衡 clique-`C5` blow-up 的可复现实验代码、Hessian 精确符号证书、严格区间证书及高精度审计。
- `computation/certificates/`：五阶、六阶低惯性和六阶对角移位对偶的逐模板有理证书，可直接核对矩阵、逆矩阵与严格界。
- `figures/`：由 `computation/generate_figures_and_evidence.py` 生成的结构、目标函数和有限阶收敛图。
- `references.tex`：当前已核实的参考文献。
- `文本原创性与AI风格自检报告.md`：本地表层重合与模板化表达筛查；不等同于学校正式查重或 AI 检测百分比。
- `build/`：编译产物。

## 证书校验

当前正文对应的逐模板证书 SHA256 如下（Windows PowerShell 可用
`Get-FileHash -Algorithm SHA256 <文件>` 复核）：

| 文件 | SHA256 |
| --- | --- |
| `computation/certificates/five_block_dual_certificates.json` | `8F3A93B0E3DA4A4A932ED05B0FCDCF11361DA413709418569F83572334E6E98C` |
| `computation/certificates/six_block_low_inertia_dual_certificates.json` | `5EA61DEF3E9DBFE2FDB5773396C38113ECF6238994393B1AE5AE81F4A6575539` |
| `computation/certificates/six_block_shifted_dual_certificates.json` | `2ED71CC3CF6147EA50AE1C26BF90086C62751F0BF9BAEC759BBC46F7044CA5E5` |

六原子 156 个同构类中，143 类已有严格证书或谱矩证明；剩余 13 类的固定掩码为
`03bc, 03bd, 03be, 06df, 077c, 077d, 07de, 07fe, 0fdf, 1bbc, 1bbd, 1bfe, 3dfe`。
这 13 类及 `N=7,\ldots,48` 仍属于未完成分类，不能按已排除处理。

当前 `build/main.pdf`（108 页）SHA256 为
`A7568CBC8A2B1A1A19FD1408FB9A1F67F0DB87EC4F235243E3868098A5B530E9`。

## 编译

工程内已放置经过 MD5 校验的 Tectonic 0.15.0 Windows 可执行文件；主稿使用
`fontset=windows` 以嵌入 SimSun、SimHei 和 KaiTi 等 CJK 字体。在工程目录运行：

```powershell
./tools/tectonic/tectonic.exe main.tex --outdir build
```

或使用完整 TeX Live：

```powershell
xelatex -output-directory=build main.tex
xelatex -output-directory=build main.tex
```

至少编译两遍才能稳定生成目录和交叉引用。当前版本故意不绑定任何学校的
封面与页眉规范；拿到学校模板后，保留 `chapters/` 内容并调整 `main.tex`
即可。

本次已验证的 PDF 位于 `build/main.pdf`。除原有六分块模型结果外，
第 4 章给出全局极限存在定理，并把全局 graphon 极值严格等价约化为三维
各向同性随机向量的正内积矩问题和有限原子 Stiefel--Perron 问题；团块克隆与
Carathéodory 压缩进一步证明存在至多 $48$ 原子的全局极大元，从而全局常数等于
单个紧的 $48$ 阶 Stiefel 最大值。正文建立光滑不可约有限驻点的矩阵 KKT 方程，同时写出达到
候选值的六原子分布。正文还精确求解至多四原子的情形，并以正惯性筛选、
矩阵保真度对偶式和完整有理证书证明全部五原子情形的精确最大值为
$c_4=(9+4\sqrt6)/15<c_*$，由 $K_1\vee C_4$ 模板达到。随后以谱矩估计和
对角移位有理保真度证书证明六阶 $156$ 个符号同构类中的 $143$ 类满足候选上界，并把六原子潜在反例
严格缩减为 $13$ 个正文显式列出的完整惯性 $(4,2,0)$ 模板；这不是对六原子
问题的全部闭合。另以有向舍入区间算术证明候选投影在固定六原子完整九维
Grassmann 方向上为非退化严格局部极大点；
同时证明任意全局极值分布
必有自支撑椭球，并用严格区间算术证明候选 zonotope 的椭球包含、交叉能量
上界、唯一等号分布及定量交叉近等号刚性；同时完全求解支撑在候选六条接触
正射线上的各向同性分布，得到类内自能量上界、唯一等号与定量耦合稳定性；
并进一步证明：只要任意支撑数的各向同性分布的内积正负关系可按候选
clique-`C5` 六类模板分拆，就有匹配自能量上界、正交意义下的唯一等号和
符号 graphon 的定量 cut 稳定性。还给出自能量缺口的精确极化分解，并以
显式各向同性分布排除全局条件负性的直接证明路线。该证书不控制任意分布的自能量。第 5 章
给出平衡环族完整谱与环长度选择定理，并新增
非平衡六分块的迹范数表示、全局凹性、边界排除、内部 KKT 完备性、类内唯一
全局极大点、径向平衡化不等式及全局二次稳定性。这些结论严格限定在固定的
clique-`C5` 六分块拓扑内，没有被外推为全体 graphon 的全局最优性。第 8 章
明确提出各向同性匹配不等式及等号刚性猜想，并严格证明“该猜想若成立，则全局
常数等于候选值；等号若唯一，则极值 graphon 必为六分块且满足定性 cut 稳定性”
的条件约化。实验结果文件为
`computation/enumeration_results.csv`，新增数值证据位于
`computation/numerical_evidence.txt`。

当前没有被解决的核心是：全体各向同性分布的匹配自能量上界（等价地，$48$ 阶
Stiefel 紧问题的严格全局上界）、全体各向同性分布的自能量等号分布
在正交变换下的唯一性，以及无条件的六分块 cut 稳定性。第三项的定性版本会由
前两项和 graphon 紧致性自动推出；显式稳定速率仍需要定量近等号刚性。

需要特别区分的是：第五章的六类符号模板定理已经给出一个严格更大的受限类，
但它以符号分拆存在为假设；“任意极值或近极值分布都具有该分拆”本身仍未证明。

当前已经严格补充：至多四原子各向同性分布的上界 $5/4$ 及等号投影刻画；
全部五原子情形的精确最大值 $c_4=(9+4\sqrt6)/15<c_*$ 及其完整有理对偶证书；
六阶全部 $156$ 个模板中 $143$ 类的严格处理（其中 $142$ 类严格低于候选值），
以及只含 $13$ 个同构类的剩余清单；
候组六原子投影在完整九维 Grassmann 图表中的非退化严格局部极大性；
任意全局极值分布的自支撑椭球和二阶条件负性；候选六原子分布的交叉能量
唯一等号与定量交叉近等号刚性；候选六条接触正射线类内的自能量上界、唯一
等号与定量稳定性；候选六类符号模板下的匹配上界、等号刚性与符号 graphon
定量 cut 稳定性；自能量缺口的精确极化恒等式，以及全局条件负性
不成立的显式反例；粗渐近上界 $(1+\sqrt3)/2$ 的严格不可达性；以及高能量分布
的重心定位
$\|\mathbb EX\|_2^2\geq2c_*-\sqrt3\approx0.831086$。
这些结果均不等同于全局自能量匹配上界；严格不可达性目前也没有给出显式正间隙。

## 结论等级

- `theorem/proposition/lemma/corollary`：正文已给出证明的结论。
- `conditional proposition` 或正文明确列出附加假设：目前只在这些假设下成立。
- `conjecture`：计算或结构证据支持，但未给出完整证明。

不得把第 5 章的六分块受限最优值改写成全体 graphon 的全局最优值。
