"""Search local shifted-dual collars around the open six-block faces.

For a fixed template T and a deleted coordinate k, the shifted fidelity dual
gives

    Psi_T(d) <= 1/2 + (a dot d)/4.

On the collar d_k <= delta, the linear maximum is attained at one of the ten
points e_i or (1-delta)e_i + delta e_k, i != k.  This script minimizes the
maximum over those points.  It is floating-point reconnaissance only; a
theorem requires rationalizing X and Gamma and checking every inequality with
exact arithmetic.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import math
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

from certify_six_block_low_inertia import matrix_from_mask
from certify_six_block_shifted_dual import N, pack, shifted_values, unpack


MASKS = (
    0x03BC,
    0x03BD,
    0x03BE,
    0x06DF,
    0x077C,
    0x077D,
    0x07DE,
    0x07FE,
    0x0FDF,
    0x1BBC,
    0x1BBD,
    0x1BFE,
)
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "boundary_dual_collar_search.txt"
C_STAR = (9.0 + math.sqrt(5.0) + 2.0 * math.sqrt(35.0)) / 18.0


def collar_coefficients(face: int, delta: float) -> np.ndarray:
    rows = []
    for index in range(N):
        if index == face:
            continue
        endpoint = np.zeros(N)
        endpoint[index] = 1.0
        rows.append(endpoint)
        collar = np.zeros(N)
        collar[index] = 1.0 - delta
        collar[face] = delta
        rows.append(collar)
    return np.asarray(rows)


def smooth_objective(
    parameters: np.ndarray,
    template: np.ndarray,
    extremes: np.ndarray,
    sharpness: float,
) -> tuple[float, np.ndarray]:
    matrix, lower, gamma = unpack(parameters)
    values, inverse_columns = shifted_values(matrix, gamma, template)
    extreme_values = extremes @ values
    scaled = sharpness * extreme_values
    extreme_weights = np.exp(scaled - logsumexp(scaled))
    weights = extreme_weights @ extremes

    gradient_matrix = np.diag(weights)
    for index in range(N):
        vector = inverse_columns[:, index]
        gradient_matrix -= weights[index] * np.outer(vector, vector)
    gradient_lower = 2.0 * gradient_matrix @ lower
    gradient = []
    for i in range(N):
        for j in range(i + 1):
            entry = gradient_lower[i, j]
            gradient.append(entry * lower[i, i] if i == j else entry)
    gradient.extend(weights * (2.0 - 2.0 * np.diag(inverse_columns)))
    return float(logsumexp(scaled) / sharpness), np.asarray(gradient)


def optimize_face(task: tuple[int, int, float, int]) -> tuple[int, int, float]:
    mask, face, delta, starts = task
    template = np.asarray(matrix_from_mask(mask, float))
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    initial = [
        (absolute + 0.03 * np.eye(N), np.zeros(N)),
        (absolute + 0.20 * np.eye(N), 0.10 * np.ones(N)),
        (np.eye(N), np.zeros(N)),
    ][:starts]
    extremes = collar_coefficients(face, delta)
    bounds = []
    for i in range(N):
        for j in range(i + 1):
            bounds.append((-5.0, 5.0) if i == j else (-8.0, 8.0))
    bounds.extend([(0.0, 6.0)] * N)

    best = math.inf
    for matrix, gamma in initial:
        parameters = pack(matrix, gamma)
        for sharpness in (30.0, 150.0, 800.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, extremes, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 1400, "ftol": 1e-13, "gtol": 1e-10},
            )
            parameters = result.x
        matrix, _, gamma = unpack(parameters)
        if np.min(np.linalg.eigvalsh(matrix)) <= 1e-9:
            continue
        values, _ = shifted_values(matrix, gamma, template)
        objective = float(np.max(extremes @ values))
        if np.isfinite(objective):
            best = min(best, objective)
    return mask, face, 0.5 + 0.25 * best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--delta", type=float, default=1.0 / 200.0)
    parser.add_argument("--starts", type=int, choices=(1, 2, 3), default=3)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    if not 0.0 <= args.delta <= 1.0:
        raise ValueError("delta must belong to [0,1]")

    tasks = [
        (mask, face, args.delta, args.starts)
        for mask in MASKS
        for face in range(N)
    ]
    if args.workers == 1:
        results = map(optimize_face, tasks)
    else:
        executor = concurrent.futures.ProcessPoolExecutor(max_workers=args.workers)
        results = executor.map(optimize_face, tasks)

    grouped: dict[int, list[tuple[int, float]]] = {mask: [] for mask in MASKS}
    for mask, face, bound in results:
        grouped[mask].append((face, bound))
    if args.workers != 1:
        executor.shutdown()

    lines = [
        "Exploratory shifted-dual collar search only; no exact certificate.",
        f"delta={args.delta:.12g} starts={args.starts} c_star={C_STAR:.12f}",
    ]
    for mask in MASKS:
        face_bounds = sorted(grouped[mask])
        maximum = max(bound for _, bound in face_bounds)
        text = " ".join(f"d{face + 1}<={bound:.9f}" for face, bound in face_bounds)
        lines.append(
            f"mask={mask:04x} worst_bound={maximum:.9f} "
            f"certifies_all_faces={maximum < C_STAR} {text}"
        )
    report = "\n".join(lines) + "\n"
    args.output.write_text(report, encoding="utf-8")
    print(report, end="")
    print(f"results_file={args.output.resolve()}")


if __name__ == "__main__":
    main()
