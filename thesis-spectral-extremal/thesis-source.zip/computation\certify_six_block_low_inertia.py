"""Exact dual certificates for low-inertia six-block templates.

All 2^15 labelled off-diagonal patterns are reduced under the 720 vertex
permutations.  Exact congruence elimination selects templates with at most
three positive eigenvalues.  Apart from K1 join C5, a floating-point search
finds rational positive-definite matrices X whose final verification uses only
Fraction arithmetic and proves

    max_i (X_ii + (T X^{-1} T)_ii) < 31/10.

The matrix-fidelity dual bound then gives sigma_3 < 51/40 < c_star.  The
floating-point stage proposes certificates but is not trusted by the checker.
"""

from __future__ import annotations

import itertools
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp


N = 6
EDGES = list(itertools.combinations(range(N), 2))
PERMUTATIONS = list(itertools.permutations(range(N)))
DUAL_TARGET = Fraction(31, 10)
OUTPUT_PATH = Path(__file__).resolve().parent / "certificates" / "six_block_low_inertia_dual_certificates.json"


def permutation_bit_maps() -> list[list[int]]:
    edge_to_bit = {edge: bit for bit, edge in enumerate(EDGES)}
    maps = []
    for permutation in PERMUTATIONS:
        maps.append(
            [
                1
                << edge_to_bit[
                    tuple(sorted((permutation[i], permutation[j])))
                ]
                for i, j in EDGES
            ]
        )
    return maps


BIT_MAPS = permutation_bit_maps()


def mask_lookup(bit_map: list[int], offset: int, size: int) -> list[int]:
    table = [0] * (1 << size)
    for mask in range(1, 1 << size):
        least_bit = mask & -mask
        bit = least_bit.bit_length() - 1
        table[mask] = table[mask ^ least_bit] | bit_map[offset + bit]
    return table


MASK_TABLES = [
    (mask_lookup(bit_map, 0, 8), mask_lookup(bit_map, 8, 7))
    for bit_map in BIT_MAPS
]


def canonical_mask(mask: int) -> int:
    low = mask & 0xFF
    high = mask >> 8
    return min(low_table[low] | high_table[high] for low_table, high_table in MASK_TABLES)


def canonical_masks() -> list[int]:
    masks = {canonical_mask(mask) for mask in range(1 << len(EDGES))}
    assert len(masks) == 156
    return sorted(masks)


def matrix_from_mask(mask: int, cls: type = float) -> list[list]:
    matrix = [[cls(i == j) for j in range(N)] for i in range(N)]
    for bit, (i, j) in enumerate(EDGES):
        if mask & (1 << bit):
            matrix[i][j] = matrix[j][i] = cls(1)
    return matrix


def swap_symmetric(matrix: list[list[Fraction]], i: int, j: int) -> None:
    matrix[i], matrix[j] = matrix[j], matrix[i]
    for row in matrix:
        row[i], row[j] = row[j], row[i]


def exact_inertia(matrix: list[list[Fraction]]) -> tuple[int, int, int]:
    work = [row[:] for row in matrix]
    positive = negative = zero = 0
    while work:
        size = len(work)
        diagonal_pivot = next((i for i in range(size) if work[i][i]), None)
        if diagonal_pivot is not None:
            swap_symmetric(work, 0, diagonal_pivot)
            pivot = work[0][0]
            positive += int(pivot > 0)
            negative += int(pivot < 0)
            work = [
                [work[i][j] - work[i][0] * work[0][j] / pivot for j in range(1, size)]
                for i in range(1, size)
            ]
            continue

        off_diagonal = next(
            ((i, j) for i in range(size) for j in range(i + 1, size) if work[i][j]),
            None,
        )
        if off_diagonal is None:
            zero += size
            break
        i, j = off_diagonal
        swap_symmetric(work, 0, i)
        swap_symmetric(work, 1, j)
        pivot = work[0][1]
        positive += 1
        negative += 1
        inverse_block = [[Fraction(0), 1 / pivot], [1 / pivot, Fraction(0)]]
        work = [
            [
                work[row][column]
                - sum(
                    work[row][a]
                    * inverse_block[a][b]
                    * work[b][column]
                    for a in range(2)
                    for b in range(2)
                )
                for column in range(2, size)
            ]
            for row in range(2, size)
        ]
    return positive, negative, zero


def unpack(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lower = np.zeros((N, N))
    cursor = 0
    for i in range(N):
        for j in range(i + 1):
            value = parameters[cursor]
            lower[i, j] = math.exp(value) if i == j else value
            cursor += 1
    return lower @ lower.T, lower


def pack_cholesky(matrix: np.ndarray) -> np.ndarray:
    lower = np.linalg.cholesky(matrix)
    values = []
    for i in range(N):
        for j in range(i + 1):
            values.append(math.log(lower[i, i]) if i == j else lower[i, j])
    return np.array(values)


def dual_values(matrix: np.ndarray, template: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    inverse_template_columns = np.linalg.solve(matrix, template)
    values = np.diag(matrix) + np.sum(template * inverse_template_columns, axis=0)
    return values, inverse_template_columns


def smooth_objective(
    parameters: np.ndarray, template: np.ndarray, sharpness: float
) -> tuple[float, np.ndarray]:
    matrix, lower = unpack(parameters)
    values, inverse_template_columns = dual_values(matrix, template)
    scaled = sharpness * values
    weights = np.exp(scaled - logsumexp(scaled))
    gradient_matrix = np.diag(weights)
    for i in range(N):
        vector = inverse_template_columns[:, i]
        gradient_matrix -= weights[i] * np.outer(vector, vector)
    gradient_lower = 2.0 * gradient_matrix @ lower
    gradient = []
    for i in range(N):
        for j in range(i + 1):
            entry = gradient_lower[i, j]
            gradient.append(entry * lower[i, i] if i == j else entry)
    return float(logsumexp(scaled) / sharpness), np.array(gradient)


def numerical_certificate(template: np.ndarray) -> np.ndarray:
    eigenvalues, eigenvectors = np.linalg.eigh(template)
    absolute = (eigenvectors * np.abs(eigenvalues)) @ eigenvectors.T
    starts = [absolute + 0.1 * np.eye(N)]
    bounds = []
    for i in range(N):
        for j in range(i + 1):
            bounds.append((-5.0, 5.0) if i == j else (-8.0, 8.0))
    best_matrix = np.eye(N)
    best_value = math.inf
    for start in starts:
        parameters = pack_cholesky(start)
        for sharpness in (50.0, 250.0, 1000.0):
            result = minimize(
                smooth_objective,
                parameters,
                args=(template, sharpness),
                jac=True,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 1500, "ftol": 1e-13, "gtol": 1e-10},
            )
            parameters = result.x
        matrix, _ = unpack(parameters)
        value = float(np.max(dual_values(matrix, template)[0]))
        if value < best_value:
            best_value = value
            best_matrix = matrix
    return best_matrix


def inverse_fraction(matrix: list[list[Fraction]]) -> list[list[Fraction]]:
    size = len(matrix)
    augmented = [
        matrix[i][:] + [Fraction(i == j) for j in range(size)] for i in range(size)
    ]
    for column in range(size):
        pivot = next(row for row in range(column, size) if augmented[row][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [entry / scale for entry in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                augmented[row][j] - factor * augmented[column][j]
                for j in range(2 * size)
            ]
    return [row[size:] for row in augmented]


def rational_certificate(
    numerical: np.ndarray,
    template: list[list[Fraction]],
    target: Fraction = DUAL_TARGET,
) -> tuple[list[list[Fraction]], list[Fraction]]:
    for digits in (5, 6, 7, 8, 9, 10):
        scale = 10**digits
        base = [
            [Fraction(int(round(numerical[i, j] * scale)), scale) for j in range(N)]
            for i in range(N)
        ]
        for bump_units in (0, 1, 2, 5, 10, 20, 50, 100):
            matrix = [row[:] for row in base]
            for i in range(N):
                matrix[i][i] += Fraction(bump_units, scale)
            if exact_inertia(matrix) != (N, 0, 0):
                continue
            inverse = inverse_fraction(matrix)
            values = []
            for i in range(N):
                column = [template[j][i] for j in range(N)]
                quadratic = sum(
                    column[j] * inverse[j][k] * column[k]
                    for j in range(N)
                    for k in range(N)
                )
                values.append(matrix[i][i] + quadratic)
            if max(values) < target:
                return matrix, values
    raise RuntimeError("failed to rationalize a strict six-block certificate")


def edge_list(mask: int) -> str:
    return " ".join(
        f"{i + 1}{j + 1}" for bit, (i, j) in enumerate(EDGES) if mask & (1 << bit)
    )


def fraction_text(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def write_certificates(records: list[dict]) -> str:
    payload = {
        "format_version": 1,
        "statement": "All non-K1-join-C5 six-vertex templates of positive inertia at most three satisfy max_i(X_ii + (T X^-1 T)_ii) < 31/10.",
        "dimension": N,
        "unlabelled_template_count": 156,
        "low_positive_inertia_count": 59,
        "analytic_exception": "K1 join C5",
        "certificate_count": len(records),
        "records": records,
    }
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("ascii")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_bytes(encoded)
    return hashlib.sha256(encoded).hexdigest().upper()


def main() -> None:
    candidate_edges = {
        (0, 1),
        (0, 2),
        (0, 3),
        (0, 4),
        (0, 5),
        (1, 2),
        (2, 3),
        (3, 4),
        (4, 5),
        (1, 5),
    }
    candidate_mask = sum(1 << EDGES.index(edge) for edge in candidate_edges)
    candidate_mask = canonical_mask(candidate_mask)

    masks = canonical_masks()
    low_inertia = []
    certified = []
    for mask in masks:
        template_fraction = matrix_from_mask(mask, Fraction)
        inertia = exact_inertia(template_fraction)
        if inertia[0] > 3:
            continue
        low_inertia.append(mask)
        if mask == candidate_mask:
            assert inertia[0] == 3
            continue
        template_float = np.array(matrix_from_mask(mask, float))
        numerical = numerical_certificate(template_float)
        rational, values = rational_certificate(numerical, template_fraction)
        maximum = max(values)
        assert maximum < DUAL_TARGET
        certified.append(
            {
                "mask": f"{mask:04x}",
                "edges": edge_list(mask).split(),
                "inertia": list(inertia),
                "matrix": [[fraction_text(value) for value in row] for row in rational],
                "dual_values": [fraction_text(value) for value in values],
                "maximum_dual_value": fraction_text(maximum),
            }
        )
        print(
            f"mask={mask:04x} inertia={inertia} edges=[{edge_list(mask)}] "
            f"max_dual={float(maximum):.12f}"
        )

    assert len(masks) == 156
    assert len(low_inertia) == 59
    assert len(certified) == 58
    assert Fraction(51, 40) < Fraction(128, 100)
    # 1.28 < c_star follows from sqrt(5)>2.23 and sqrt(35)>5.91.
    assert 223**2 < 5 * 100**2
    assert 591**2 < 35 * 100**2
    assert Fraction(9, 1) + Fraction(223, 100) + 2 * Fraction(591, 100) > Fraction(18 * 128, 100)
    digest = write_certificates(certified)
    print(
        "EXACT CERTIFICATE PASSED: 156 unlabelled six-vertex templates, "
        "59 with positive inertia at most three, 58 strict rational dual "
        "certificates, and one analytic K1 join C5 equality template."
    )
    print(f"certificate_file={OUTPUT_PATH} sha256={digest}")


if __name__ == "__main__":
    main()
