"""Numerically inspect the best five-atom Stiefel competitor.

This script is exploratory evidence only.  It records the projection, sign
graph, Perron weights, and recovered isotropic atoms for the best seeded run.
"""

from __future__ import annotations

import argparse

import numpy as np

from search_isotropic_atomic import C_STAR, optimize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--restarts", type=int, default=200)
    parser.add_argument("--iterations", type=int, default=3000)
    parser.add_argument("--seed", type=int, default=20260907)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    best_value = -np.inf
    best_q = np.empty((5, 3))
    best_weights = np.empty(5)
    for _ in range(args.restarts):
        value, q, weights = optimize(rng.normal(size=(5, 3)), args.iterations)
        if value > best_value:
            best_value, best_q, best_weights = value, q, weights

    gram = best_q @ best_q.T
    atoms = best_q / np.sqrt(best_weights[:, None])
    np.set_printoptions(precision=12, suppress=True, linewidth=160)
    print(f"value={best_value:.12f} gap_to_c_star={C_STAR-best_value:+.12f}")
    print("weights=")
    print(best_weights)
    print("projection=")
    print(gram)
    print("positive_off_diagonal=")
    print(((gram > 1e-8) & ~np.eye(5, dtype=bool)).astype(int))
    print("atoms=")
    print(atoms)


if __name__ == "__main__":
    main()
