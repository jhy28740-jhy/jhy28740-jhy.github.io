"""Local self-overlap and formulaic-style checks for the thesis PDF.

This tool does not estimate an official plagiarism or AI-generation score. It
compares the thesis with the author's source paper and reports reproducible
surface-text evidence that can guide manual revision.
"""

from __future__ import annotations

import argparse
import re
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path

from pypdf import PdfReader


TRANSITIONS = [
    "本文",
    "因此",
    "这说明",
    "首先",
    "其次",
    "最后",
    "由此",
    "进一步",
    "需要指出的是",
    "值得注意的是",
    "综上所述",
    "不难发现",
    "可以看出",
    "显然",
    "当前",
]


def extract_pages(path: Path) -> list[str]:
    reader = PdfReader(path)
    return [(page.extract_text() or "") for page in reader.pages]


def compact_text(text: str) -> str:
    return "".join(re.findall(r"[\u3400-\u9fffA-Za-z0-9]+", text.lower()))


def english_words(text: str) -> list[str]:
    words = re.findall(r"[a-z]+(?:'[a-z]+)?", text.lower())
    return [word for word in words if len(word) >= 2]


def latex_style_text(root: Path) -> str:
    files = [root / "main.tex", *sorted((root / "chapters").glob("*.tex"))]
    text = "\n".join(path.read_text(encoding="utf-8") for path in files)
    text = re.sub(r"(?m)(?<!\\)%.*$", " ", text)
    text = re.sub(r"\\(?:begin|end)\{[^}]+\}", " ", text)
    text = re.sub(r"\\[A-Za-z@]+\*?(?:\[[^\]]*\])?", " ", text)
    return text.replace("{", " ").replace("}", " ")


def ngram_set(sequence: list[str] | str, size: int) -> set:
    if len(sequence) < size:
        return set()
    if isinstance(sequence, str):
        return {sequence[i : i + size] for i in range(len(sequence) - size + 1)}
    return {tuple(sequence[i : i + size]) for i in range(len(sequence) - size + 1)}


def sentence_list(text: str) -> list[str]:
    raw = re.split(r"(?<=[。！？!?])|(?<=[.!?])\s+|\n{2,}", text)
    return [re.sub(r"\s+", " ", item).strip() for item in raw if len(compact_text(item)) >= 25]


def english_sentence_matches(thesis: str, source: str) -> list[tuple[float, str, str]]:
    thesis_sentences = sentence_list(thesis)
    source_sentences = sentence_list(source)
    source_data = [(sentence, set(english_words(sentence))) for sentence in source_sentences]
    matches: list[tuple[float, str, str]] = []

    for thesis_sentence in thesis_sentences:
        thesis_tokens = set(english_words(thesis_sentence))
        if len(thesis_tokens) < 8:
            continue
        best: tuple[float, str] | None = None
        for source_sentence, source_tokens in source_data:
            if len(source_tokens) < 8:
                continue
            overlap = thesis_tokens & source_tokens
            if len(overlap) < 6:
                continue
            union = thesis_tokens | source_tokens
            if len(overlap) / len(union) < 0.30:
                continue
            ratio = SequenceMatcher(
                None,
                " ".join(english_words(thesis_sentence)),
                " ".join(english_words(source_sentence)),
                autojunk=False,
            ).ratio()
            if best is None or ratio > best[0]:
                best = (ratio, source_sentence)
        if best and best[0] >= 0.62:
            matches.append((best[0], thesis_sentence, best[1]))
    return sorted(matches, reverse=True)[:8]


def duplicate_sentences(text: str) -> list[tuple[int, str]]:
    buckets: dict[str, list[str]] = defaultdict(list)
    for sentence in sentence_list(text):
        normalized = compact_text(sentence)
        if len(normalized) >= 35:
            buckets[normalized].append(sentence)
    duplicates = [(len(values), values[0]) for values in buckets.values() if len(values) > 1]
    return sorted(duplicates, key=lambda item: (-item[0], -len(item[1])))[:10]


def matching_word_phrases(thesis: str, source: str, size: int = 10) -> list[str]:
    thesis_words = english_words(thesis)
    source_ngrams = ngram_set(english_words(source), size)
    counts: Counter[tuple[str, ...]] = Counter()
    for i in range(len(thesis_words) - size + 1):
        gram = tuple(thesis_words[i : i + size])
        if gram in source_ngrams:
            counts[gram] += 1
    return [" ".join(gram) for gram, _ in counts.most_common(8)]


def markdown_escape(text: str, limit: int = 220) -> str:
    shortened = re.sub(r"\s+", " ", text).strip()
    if len(shortened) > limit:
        shortened = shortened[: limit - 3] + "..."
    return shortened.replace("|", "\\|")


def make_report(thesis_path: Path, source_path: Path, tex_root: Path) -> str:
    thesis_pages = extract_pages(thesis_path)
    source_pages = extract_pages(source_path)
    thesis = "\n".join(thesis_pages)
    source = "\n".join(source_pages)
    thesis_compact = compact_text(thesis)
    source_compact = compact_text(source)
    thesis_words = english_words(thesis)
    source_words = english_words(source)

    char_rows = []
    for size in (40, 60, 80):
        thesis_grams = ngram_set(thesis_compact, size)
        source_grams = ngram_set(source_compact, size)
        common = thesis_grams & source_grams
        coverage = len(common) / max(1, len(thesis_grams))
        char_rows.append((size, len(common), coverage))

    word_rows = []
    for size in (8, 10, 12):
        thesis_grams = ngram_set(thesis_words, size)
        source_grams = ngram_set(source_words, size)
        common = thesis_grams & source_grams
        coverage = len(common) / max(1, len(thesis_grams))
        word_rows.append((size, len(common), coverage))

    style_text = latex_style_text(tex_root)
    transitions = [(term, style_text.count(term)) for term in TRANSITIONS]
    transitions = sorted(transitions, key=lambda item: (-item[1], item[0]))
    duplicates = duplicate_sentences(style_text)
    sentence_matches = english_sentence_matches(thesis, source)
    exact_phrases = matching_word_phrases(thesis, source)

    lines = [
        "# 文本原创性与 AI 风格自检报告",
        "",
        "## 结论与边界",
        "",
        "本报告是本地、可复现的表层文本筛查，不输出也不推测所谓“AI 率”或学校正式查重率。AI 文本检测器的结果受模型、语种、公式密度和版本影响很大；正式重复率只能以学校指定的知网、维普或万方系统及其收录库为准。未经作者许可，本次检查没有把未发表论文上传到任何第三方检测网站。",
        "",
        "本次比较对象是毕业论文增强版与作者已有小论文，因此检测到的重合首先属于同一研究项目内部的自重合风险。引用、公式、术语和参考文献造成的机械重合，应由学校规则决定是否排除。",
        "",
        "## 样本信息",
        "",
        "| 项目 | 毕业论文 | 原小论文 |",
        "|---|---:|---:|",
        f"| PDF 页数 | {len(thesis_pages)} | {len(source_pages)} |",
        f"| 归一化字符数 | {len(thesis_compact):,} | {len(source_compact):,} |",
        f"| 英文词数 | {len(thesis_words):,} | {len(source_words):,} |",
        "",
        "## 长片段精确重合",
        "",
        "下表把空白、标点和大小写归一化后比较连续字符 n-gram。覆盖率分母为毕业论文自身的不同 n-gram 数量。",
        "",
        "| 片段长度 | 共同片段数 | 毕业论文集合覆盖率 |",
        "|---:|---:|---:|",
    ]
    lines.extend(f"| {size} 字符 | {count:,} | {coverage:.4%} |" for size, count, coverage in char_rows)
    lines.extend(
        [
            "",
            "英文词组另按连续单词比较：",
            "",
            "| 片段长度 | 共同片段数 | 毕业论文集合覆盖率 |",
            "|---:|---:|---:|",
        ]
    )
    lines.extend(f"| {size} 词 | {count:,} | {coverage:.4%} |" for size, count, coverage in word_rows)

    lines.extend(["", "最长风险词组样例："])
    if exact_phrases:
        lines.extend(f"- `{phrase}`" for phrase in exact_phrases)
    else:
        lines.append("- 未发现 10 个英文词以上的连续精确重合。")

    lines.extend(["", "## 句子级近似重合", ""])
    if sentence_matches:
        lines.extend(
            [
                "以下仅列英文词汇充分重合且字符序列相似度不低于 0.62 的候选，需人工判断是否属于研究对象、标题或方法描述的合理重合：",
                "",
                "| 相似度 | 毕业论文句子 | 原小论文句子 |",
                "|---:|---|---|",
            ]
        )
        lines.extend(
            f"| {ratio:.3f} | {markdown_escape(left)} | {markdown_escape(right)} |"
            for ratio, left, right in sentence_matches
        )
    else:
        lines.append("在当前阈值和英文文本子集内，未发现英文句子级近似重合。")

    lines.extend(
        [
            "",
            "本地比较仅覆盖同语种归一化字符 n-gram、英文连续词组和表层句子相似度；未进行中英文翻译对齐、跨语言语义嵌入、公式语义等价性或参考文献数据库比对。因此，‘未发现近似重合’不能解释为跨语言零相似，也不能换算为学校系统的正式查重率或 AI 率。",
        ]
    )

    lines.extend(
        [
            "",
            "## 内部重复与模板化表达",
            "",
            f"UTF-8 LaTeX 正文中共统计到 {sum(count for _, count in transitions):,} 次指定连接词命中。高频项如下：",
            "",
            "| 表达 | 次数 |",
            "|---|---:|",
        ]
    )
    lines.extend(f"| {term} | {count} |" for term, count in transitions if count)

    lines.extend(["", "完全重复的长句候选："])
    if duplicates:
        lines.extend(f"- {count} 次：{markdown_escape(sentence)}" for count, sentence in duplicates)
    else:
        lines.append("- 未发现归一化后完全相同且长度不少于 35 字符的长句。")

    lines.extend(
        [
            "",
            "## 已执行的风格优化",
            "",
            "- 删除“原手稿”“旧数值主张”“否定”等修订历史式措辞，改为直接陈述数学事实与适用范围。",
            "- 将严格定理、带附加假设的命题、有限样本计算证据和 conjecture 分层书写，避免确定性口吻超过证据强度。",
            "- 为新增结论补入推导、误差常数、随机种子、样本数和可复现脚本，减少泛化总结句所占比例。",
            "- 保留必要的“本文”用于范围声明，但不使用“显而易见”“众所周知”“综上所述”等空泛套语替代证明。",
            "",
            "## 提交前建议",
            "",
            "1. 用学校指定系统检测最终模板版，并勾选学校允许的本人已发表成果排除规则；若系统不支持排除，应准备小论文与毕业论文关系说明。",
            "2. 优先核查英文摘要、研究背景和第七章小阶构造描述，因为这些位置最容易与既有小论文形成连续英文词组或事实性复述。",
            "3. 不要为了压低检测指标改写定理名称、标准术语、公式或规范参考文献；应只改写叙述性句子，并保留准确引用。",
            "4. 学校系统每次版本与阈值可能不同，任何本地指标都不能换算为正式“查重率”或“AI 率”。",
            "",
            "---",
            "",
            f"毕业论文文件：`{thesis_path.resolve()}`  ",
            f"比较源文件：`{source_path.resolve()}`",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--thesis", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--tex-root", type=Path, required=True)
    args = parser.parse_args()
    report = make_report(args.thesis, args.source, args.tex_root)
    args.report.write_text(report, encoding="utf-8")
    print(f"wrote {args.report}")


if __name__ == "__main__":
    main()
